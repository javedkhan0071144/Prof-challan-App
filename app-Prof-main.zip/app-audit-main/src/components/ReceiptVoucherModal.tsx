import React, { useState, useEffect } from 'react';
import { AuditRecord } from '../types';
import { formatCurrency } from '../utils/formatters';
import { generateQRCode, getVerificationUrl } from '../utils/qrCode';
import { X, Printer, CheckCircle2, Clock, QrCode } from 'lucide-react';

interface ReceiptVoucherModalProps {
  isOpen: boolean;
  onClose: () => void;
  record: AuditRecord | null;
  onToggleVerified: (record: AuditRecord) => void;
}

export const ReceiptVoucherModal: React.FC<ReceiptVoucherModalProps> = ({
  isOpen,
  onClose,
  record,
  onToggleVerified,
}) => {
  const [qrDataUrl, setQrDataUrl] = useState<string>('');

  useEffect(() => {
    if (record && isOpen) {
      const url = getVerificationUrl(record);
      generateQRCode(url, 160).then(setQrDataUrl).catch(() => {});
    }
  }, [record, isOpen]);

  if (!isOpen || !record) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-slate-200">
        {/* Controls bar */}
        <div className="no-print p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50 shrink-0">
          <div className="text-xs font-bold text-slate-700">
            Audit Recovery Voucher · Record #{record.id}
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Voucher</span>
            </button>
            <button
              onClick={onClose}
              className="p-1 text-slate-400 hover:text-slate-600 rounded-lg transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Voucher Document */}
        <div className="p-6 sm:p-8 space-y-5 text-slate-800 bg-white flex-1 overflow-y-auto">
          {/* Header */}
          <div className="text-center border-b pb-4 border-slate-300">
            <div className="text-[11px] font-bold text-slate-500 uppercase tracking-widest">
              Government of the Punjab · Excise & Taxation
            </div>
            <h3 className="text-lg font-black text-slate-900 mt-1 uppercase">
              Property Tax Recovery Challan / Audit Slip
            </h3>
            <p className="text-xs text-slate-500 font-mono mt-0.5">
              Ref: {record.challanNo || `CH-2026-${String(record.id).padStart(3, '0')}`} · Form 32-A
            </p>
          </div>

          {/* Verification Badge */}
          <div className="p-3 rounded-lg border bg-slate-50 border-slate-200 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs">
                {record.verificationStage === '3rd' || record.verified ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span className="font-bold text-emerald-800">Status: 3rd Verification (Fully Endorsed OK)</span>
                  </>
                ) : record.verificationStage === '2nd' ? (
                  <>
                    <span className="w-2.5 h-2.5 rounded-full bg-indigo-600" />
                    <span className="font-bold text-indigo-800">Status: 2nd Verification (Revenue Officer Re-check)</span>
                  </>
                ) : record.verificationStage === '1st' ? (
                  <>
                    <span className="w-2.5 h-2.5 rounded-full bg-blue-600" />
                    <span className="font-bold text-blue-800">Status: 1st Verification (Field Inspection)</span>
                  </>
                ) : (
                  <>
                    <Clock className="w-4 h-4 text-amber-600" />
                    <span className="font-semibold text-amber-800">Status: Pending Verification</span>
                  </>
                )}
              </div>
              <button
                onClick={() => onToggleVerified(record)}
                className="no-print text-xs text-indigo-600 hover:underline font-semibold cursor-pointer"
              >
                Advance Stage
              </button>
            </div>

            {/* Verification Stage Dates Ribbon */}
            <div className="grid grid-cols-3 gap-2 pt-1 border-t border-slate-200 text-[11px] font-mono">
              <div className="bg-white p-1.5 rounded border border-slate-200 text-center">
                <span className="text-[10px] text-slate-400 block font-sans">1st Ver Dated</span>
                <span className={record.firstVerDate ? 'font-bold text-blue-700' : 'text-slate-400'}>
                  {record.firstVerDate || 'Pending'}
                </span>
              </div>
              <div className="bg-white p-1.5 rounded border border-slate-200 text-center">
                <span className="text-[10px] text-slate-400 block font-sans">2nd Ver Dated</span>
                <span className={record.secondVerDate ? 'font-bold text-indigo-700' : 'text-slate-400'}>
                  {record.secondVerDate || 'Pending'}
                </span>
              </div>
              <div className="bg-white p-1.5 rounded border border-slate-200 text-center">
                <span className="text-[10px] text-slate-400 block font-sans">3rd Ver Dated</span>
                <span className={record.thirdVerDate ? 'font-bold text-emerald-700' : 'text-slate-400'}>
                  {record.thirdVerDate || 'Pending'}
                </span>
              </div>
            </div>
          </div>

          {/* Key Details Grid */}
          <div className="grid grid-cols-2 gap-3 text-xs border border-slate-200 rounded-lg p-4">
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-semibold">Property No</span>
              <span className="font-mono font-bold text-slate-900 text-sm">{record.propertyNo}</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-semibold">Assessed Taxpayer / Owner</span>
              <span className="font-bold text-slate-900">{record.owner}</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-semibold">Jurisdiction</span>
              <span>{record.tehsil} / {record.circle} ({record.district})</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-semibold">Para Details</span>
              <span>{record.details} ({record.paraNo})</span>
            </div>
          </div>

          {/* Financial Assessment Table */}
          <div className="border border-slate-200 rounded-lg overflow-hidden text-xs">
            <div className="bg-slate-50 px-3 py-2 font-bold text-slate-700 border-b border-slate-200 uppercase text-[10px]">
              Financial Assessment Breakdown
            </div>
            <div className="divide-y divide-slate-100 font-mono">
              <div className="px-3 py-2 flex justify-between">
                <span className="text-slate-600 font-sans">Audit Assessment Amount:</span>
                <span className="font-bold text-slate-900">{formatCurrency(record.auditAmt)}</span>
              </div>
              <div className="px-3 py-2 flex justify-between bg-emerald-50/50">
                <span className="text-slate-700 font-sans">Less: Recovered Amount:</span>
                <span className="font-bold text-emerald-700">-{formatCurrency(record.recovered)}</span>
              </div>
              {(record.priorAudit > 0 || record.notDue > 0) && (
                <>
                  <div className="px-3 py-2 flex justify-between">
                    <span className="text-slate-600 font-sans">Less: Prior Audit Deduction:</span>
                    <span className="text-slate-700">-{formatCurrency(record.priorAudit)}</span>
                  </div>
                  <div className="px-3 py-2 flex justify-between">
                    <span className="text-slate-600 font-sans">Less: Not Due Exemption:</span>
                    <span className="text-slate-700">-{formatCurrency(record.notDue)}</span>
                  </div>
                </>
              )}
              <div className="px-3 py-2 flex justify-between">
                <span className="text-slate-600 font-sans">Receipt Amount Credited:</span>
                <span className="text-indigo-700">{formatCurrency(record.receiptAmt)}</span>
              </div>
              <div className="px-3 py-2.5 flex justify-between bg-slate-100 text-sm font-bold">
                <span className="font-sans">Net Balance Outstanding:</span>
                <span className={record.balance > 0 ? 'text-rose-600' : 'text-slate-800'}>
                  {formatCurrency(record.balance)}
                </span>
              </div>
            </div>
          </div>

          {/* QR Verification Seal Box */}
          <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-200">
            <div className="space-y-0.5">
              <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block">
                Official Verification QR Code
              </span>
              <p className="text-xs font-semibold text-slate-800">
                Scan to verify this challan in public audit portal
              </p>
              <p className="text-[10px] text-slate-500 font-mono">
                Property #{record.propertyNo} · Challan Ref: {record.challanNo || `CH-${record.id}`}
              </p>
            </div>
            {qrDataUrl && (
              <img
                src={qrDataUrl}
                alt="QR Stamp"
                className="w-16 h-16 object-contain rounded bg-white p-1 border border-slate-200"
              />
            )}
          </div>

          {/* Notes */}
          {record.remarks && (
            <div className="text-xs bg-slate-50 p-3 rounded-lg border border-slate-200">
              <span className="font-semibold text-slate-700 block text-[11px] mb-0.5">Auditor Remarks:</span>
              <span className="text-slate-600">{record.remarks}</span>
            </div>
          )}

          {/* Signatures */}
          <div className="pt-6 grid grid-cols-2 gap-8 text-center text-xs text-slate-500">
            <div>
              <div className="border-t border-slate-300 pt-1 font-semibold text-slate-700">Bank Cashier / Scroll Stamp</div>
              <div className="text-[10px]">National Bank of Pakistan</div>
            </div>
            <div>
              <div className="border-t border-slate-300 pt-1 font-semibold text-slate-700">Assessing Authority</div>
              <div className="text-[10px]">Excise & Taxation Officer</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
