import React, { useState } from 'react';
import { AuditParaInfo } from '../types';
import { X, Plus, Layers, Check } from 'lucide-react';

interface AddParaModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddPara: (para: AuditParaInfo) => void;
  existingParas: AuditParaInfo[];
}

export const AddParaModal: React.FC<AddParaModalProps> = ({
  isOpen,
  onClose,
  onAddPara,
  existingParas,
}) => {
  // Suggest next para number based on existing
  const defaultParaNum = `Para-${existingParas.length + 1}`;

  const [paraNo, setParaNo] = useState(defaultParaNum);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<AuditParaInfo['category']>('Commercial');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!paraNo.trim() || !title.trim()) return;

    onAddPara({
      paraNo: paraNo.trim(),
      title: title.trim(),
      description: description.trim() || `Audit paragraph inspection and verification for ${paraNo.trim()}.`,
      category,
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="p-5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center">
              <Layers className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Register New Audit Paragraph
              </h3>
              <p className="text-xs text-slate-500">
                Define a new audit para subject, category, and audit scope
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-600 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Para Reference (e.g. Para-8) *
              </label>
              <input
                type="text"
                required
                value={paraNo}
                onChange={(e) => setParaNo(e.target.value)}
                placeholder="e.g. Para-8"
                className="w-full text-xs border border-slate-300 rounded-lg px-3 py-2 font-mono font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="w-full text-xs border border-slate-300 rounded-lg px-3 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="Commercial">Commercial</option>
                <option value="Residential">Residential</option>
                <option value="Institutional">Institutional</option>
                <option value="Financial">Financial</option>
                <option value="Industrial">Industrial</option>
                <option value="Special">Special</option>
                <option value="Other">Other</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Para Title / Subject *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Advertising Hoardings & Rooftop Billboards"
              className="w-full text-xs border border-slate-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Audit Scope & Description
            </label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. Non-realization of commercial assessment from advertising displays, hoardings, and highway signboards..."
              className="w-full text-xs border border-slate-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-slate-300 rounded-lg text-xs font-medium text-slate-700 hover:bg-slate-50 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs transition"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Register Audit Para</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
