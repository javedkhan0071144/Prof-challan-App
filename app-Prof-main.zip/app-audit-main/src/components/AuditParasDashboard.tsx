import React, { useState, useMemo } from 'react';
import { AuditRecord, AuditParaInfo, VerificationStage } from '../types';
import { formatCurrency } from '../utils/formatters';
import {
  Layers,
  FolderOpen,
  ArrowRight,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Printer,
  Download,
  Plus,
  Search,
  Filter,
  BarChart3,
  Building,
  ShieldCheck,
  Scale,
  Sparkles,
  ChevronRight,
  FileSpreadsheet
} from 'lucide-react';

interface AuditParasDashboardProps {
  records: AuditRecord[];
  paras: AuditParaInfo[];
  onSelectParaForLedger: (paraNo: string) => void;
  onOpenAddParaModal: () => void;
  onOpenAddRecordModalForPara?: (paraNo: string, details: string) => void;
  onOpenReportModalForPara: (paraNo: string) => void;
  onOpenAccountsOfficeModal: () => void;
  onExportCSV: () => void;
}

export const AuditParasDashboard: React.FC<AuditParasDashboardProps> = ({
  records,
  paras,
  onSelectParaForLedger,
  onOpenAddParaModal,
  onOpenAddRecordModalForPara,
  onOpenReportModalForPara,
  onOpenAccountsOfficeModal,
  onExportCSV,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'settled' | 'high_recovery' | 'in_progress' | 'has_balance'>('all');
  const [sortField, setSortField] = useState<'paraNo' | 'auditAmt' | 'balance' | 'recoveryRate' | 'count'>('paraNo');
  const [viewMode, setViewMode] = useState<'both' | 'cards' | 'table'>('both');

  // Compute stats for each known and discovered Para
  const paraStats = useMemo(() => {
    // Collect all unique para numbers from both `paras` list and existing `records`
    const allParaNos = Array.from(
      new Set([
        ...paras.map((p) => p.paraNo),
        ...records.map((r) => r.paraNo || 'Para-General'),
      ])
    ).sort();

    return allParaNos.map((paraNo) => {
      const paraRecords = records.filter((r) => (r.paraNo || 'Para-General') === paraNo);
      const paraMeta = paras.find((p) => p.paraNo === paraNo) || {
        paraNo,
        title: paraRecords[0]?.details || `Audit Paragraph ${paraNo}`,
        description: `Audit inspection findings and recovery reconciliation for ${paraNo}.`,
        category: 'Commercial' as const,
      };

      const auditAmt = paraRecords.reduce((sum, r) => sum + (r.auditAmt || 0), 0);
      const recovered = paraRecords.reduce((sum, r) => sum + (r.recovered || 0), 0);
      const receiptAmt = paraRecords.reduce((sum, r) => sum + (r.receiptAmt || 0), 0);
      const priorAudit = paraRecords.reduce((sum, r) => sum + (r.priorAudit || 0), 0);
      const notDue = paraRecords.reduce((sum, r) => sum + (r.notDue || 0), 0);
      const balance = paraRecords.reduce((sum, r) => sum + (r.balance || 0), 0);

      const recoveryRate = auditAmt > 0 ? Math.min(100, Math.round((recovered / auditAmt) * 100)) : 0;

      const thirdCount = paraRecords.filter((r) => r.verificationStage === '3rd' || r.verified).length;
      const secondCount = paraRecords.filter((r) => r.verificationStage === '2nd').length;
      const firstCount = paraRecords.filter((r) => r.verificationStage === '1st').length;
      const pendingCount = paraRecords.filter(
        (r) => (!r.verificationStage || r.verificationStage === 'pending') && !r.verified
      ).length;

      let settlementStatus: 'settled' | 'high_recovery' | 'in_progress' | 'critical' = 'in_progress';
      if (balance === 0 && auditAmt > 0 && recoveryRate >= 99) {
        settlementStatus = 'settled';
      } else if (recoveryRate >= 75) {
        settlementStatus = 'high_recovery';
      } else if (recoveryRate < 40) {
        settlementStatus = 'critical';
      }

      return {
        paraNo,
        meta: paraMeta,
        records: paraRecords,
        count: paraRecords.length,
        auditAmt,
        recovered,
        receiptAmt,
        priorAudit,
        notDue,
        balance,
        recoveryRate,
        thirdCount,
        secondCount,
        firstCount,
        pendingCount,
        settlementStatus,
      };
    });
  }, [records, paras]);

  // Overall consolidated summary metrics
  const portfolioSummary = useMemo(() => {
    const totalParas = paraStats.length;
    const totalRecords = records.length;
    const totalAudit = records.reduce((s, r) => s + (r.auditAmt || 0), 0);
    const totalRecovered = records.reduce((s, r) => s + (r.recovered || 0), 0);
    const totalReceipts = records.reduce((s, r) => s + (r.receiptAmt || 0), 0);
    const totalPrior = records.reduce((s, r) => s + (r.priorAudit || 0), 0);
    const totalNotDue = records.reduce((s, r) => s + (r.notDue || 0), 0);
    const totalBalance = records.reduce((s, r) => s + (r.balance || 0), 0);
    const overallRate = totalAudit > 0 ? Math.min(100, Math.round((totalRecovered / totalAudit) * 100)) : 0;

    const settledParas = paraStats.filter((p) => p.settlementStatus === 'settled').length;
    const highRecoveryParas = paraStats.filter((p) => p.settlementStatus === 'high_recovery').length;
    const attentionParas = paraStats.filter((p) => p.balance > 0).length;

    return {
      totalParas,
      totalRecords,
      totalAudit,
      totalRecovered,
      totalReceipts,
      totalPrior,
      totalNotDue,
      totalBalance,
      overallRate,
      settledParas,
      highRecoveryParas,
      attentionParas,
    };
  }, [paraStats, records]);

  // Filtered & Sorted Para list
  const filteredParas = useMemo(() => {
    return paraStats
      .filter((p) => {
        // Search query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matches =
            p.paraNo.toLowerCase().includes(q) ||
            p.meta.title.toLowerCase().includes(q) ||
            p.meta.description.toLowerCase().includes(q) ||
            (p.meta.category && p.meta.category.toLowerCase().includes(q));
          if (!matches) return false;
        }

        // Category
        if (selectedCategory !== 'all' && p.meta.category !== selectedCategory) {
          return false;
        }

        // Status
        if (statusFilter === 'settled' && p.settlementStatus !== 'settled') return false;
        if (statusFilter === 'high_recovery' && p.settlementStatus !== 'high_recovery') return false;
        if (statusFilter === 'in_progress' && p.settlementStatus !== 'in_progress' && p.settlementStatus !== 'critical') return false;
        if (statusFilter === 'has_balance' && p.balance <= 0) return false;

        return true;
      })
      .sort((a, b) => {
        if (sortField === 'paraNo') {
          return a.paraNo.localeCompare(b.paraNo, undefined, { numeric: true });
        }
        if (sortField === 'auditAmt') return b.auditAmt - a.auditAmt;
        if (sortField === 'balance') return b.balance - a.balance;
        if (sortField === 'recoveryRate') return b.recoveryRate - a.recoveryRate;
        if (sortField === 'count') return b.count - a.count;
        return 0;
      });
  }, [paraStats, searchQuery, selectedCategory, statusFilter, sortField]);

  // Categories list
  const categories = ['all', 'Commercial', 'Residential', 'Institutional', 'Financial', 'Industrial', 'Special'];

  return (
    <div className="space-y-6">
      {/* 1. Broad Executive Hero Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-2xl p-6 sm:p-8 shadow-md border border-slate-800 relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-96 bg-indigo-500/5 blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 text-xs font-medium">
              <Layers className="w-3.5 h-3.5" />
              <span>Multi-Paragraph Audit Governance & Reconciliation Engine</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
              Audit Paras Broad Dashboard
            </h1>
            <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
              Consolidated audit oversight across all audit paras. Switch effortlessly between individual paragraph details or examine broad cross-departmental recovery reconciliation.
            </p>
          </div>

          {/* Quick Portfolio Action Buttons */}
          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              onClick={onOpenAddParaModal}
              className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl flex items-center gap-2 shadow-sm transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>+ Register New Para</span>
            </button>
            <button
              onClick={onOpenAccountsOfficeModal}
              className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium rounded-xl flex items-center gap-2 transition-colors"
            >
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Accounts Office Attestation</span>
            </button>
            <button
              onClick={onExportCSV}
              className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium rounded-xl flex items-center gap-2 transition-colors"
            >
              <Download className="w-4 h-4 text-indigo-400" />
              <span>Export Consolidated CSV</span>
            </button>
          </div>
        </div>

        {/* 2. Broad Executive KPI Metrics Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 pt-6 mt-6 border-t border-slate-800/80">
          <div className="bg-slate-800/60 backdrop-blur-xs p-3.5 rounded-xl border border-slate-700/60">
            <div className="text-[11px] text-slate-400 uppercase tracking-wider font-medium">Audit Paras</div>
            <div className="text-xl sm:text-2xl font-bold font-mono text-white mt-1">
              {portfolioSummary.totalParas}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              Across {portfolioSummary.totalRecords} properties
            </div>
          </div>

          <div className="bg-slate-800/60 backdrop-blur-xs p-3.5 rounded-xl border border-slate-700/60">
            <div className="text-[11px] text-slate-400 uppercase tracking-wider font-medium">Total Assessed Demand</div>
            <div className="text-xl sm:text-2xl font-bold font-mono text-indigo-200 mt-1">
              {formatCurrency(portfolioSummary.totalAudit)}
            </div>
            <div className="text-[10px] text-indigo-400/80 mt-0.5">All audited paras</div>
          </div>

          <div className="bg-slate-800/60 backdrop-blur-xs p-3.5 rounded-xl border border-slate-700/60">
            <div className="text-[11px] text-emerald-400 uppercase tracking-wider font-medium">Realized Recoveries</div>
            <div className="text-xl sm:text-2xl font-bold font-mono text-emerald-300 mt-1">
              {formatCurrency(portfolioSummary.totalRecovered)}
            </div>
            <div className="text-[10px] text-emerald-400/80 mt-0.5 font-medium">
              Receipts: {formatCurrency(portfolioSummary.totalReceipts)}
            </div>
          </div>

          <div className="bg-slate-800/60 backdrop-blur-xs p-3.5 rounded-xl border border-slate-700/60">
            <div className="text-[11px] text-amber-400 uppercase tracking-wider font-medium">Relief / Prior Audit</div>
            <div className="text-xl sm:text-2xl font-bold font-mono text-amber-200 mt-1">
              {formatCurrency(portfolioSummary.totalPrior + portfolioSummary.totalNotDue)}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">Exempt & Prior audit</div>
          </div>

          <div className="bg-slate-800/60 backdrop-blur-xs p-3.5 rounded-xl border border-slate-700/60">
            <div className="text-[11px] text-rose-400 uppercase tracking-wider font-medium">Outstanding Balance</div>
            <div className="text-xl sm:text-2xl font-bold font-mono text-rose-300 mt-1">
              {formatCurrency(portfolioSummary.totalBalance)}
            </div>
            <div className="text-[10px] text-rose-400/80 mt-0.5">
              {portfolioSummary.attentionParas} paras have dues
            </div>
          </div>

          <div className="bg-slate-800/60 backdrop-blur-xs p-3.5 rounded-xl border border-slate-700/60">
            <div className="text-[11px] text-emerald-400 uppercase tracking-wider font-medium">Settlement Rate</div>
            <div className="text-xl sm:text-2xl font-bold font-mono text-emerald-300 mt-1">
              {portfolioSummary.overallRate}%
            </div>
            <div className="w-full bg-slate-700 h-1.5 rounded-full mt-2 overflow-hidden">
              <div
                className="bg-emerald-400 h-1.5 rounded-full transition-all"
                style={{ width: `${portfolioSummary.overallRate}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* 3. Filter Toolbar & Search Bar for Paras */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          {/* Search box */}
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filter paras by Para No, Title, Subject, or Category..."
              className="w-full pl-9 pr-4 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-white"
            />
          </div>

          {/* Controls: Category, Status, Sort, ViewMode */}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            {/* Status filter */}
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="px-2.5 py-1.5 border border-slate-300 rounded-lg bg-white text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="all">All Statuses</option>
              <option value="settled">100% Settled</option>
              <option value="high_recovery">High Recovery (≥75%)</option>
              <option value="in_progress">In Progress</option>
              <option value="has_balance">Outstanding Balance &gt; 0</option>
            </select>

            {/* Sort field */}
            <select
              value={sortField}
              onChange={(e) => setSortField(e.target.value as any)}
              className="px-2.5 py-1.5 border border-slate-300 rounded-lg bg-white text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="paraNo">Sort by Para Number</option>
              <option value="auditAmt">Sort by Assessed Demand (High to Low)</option>
              <option value="balance">Sort by Outstanding Balance</option>
              <option value="recoveryRate">Sort by Recovery Rate %</option>
              <option value="count">Sort by Properties Count</option>
            </select>

            {/* View switcher */}
            <div className="inline-flex rounded-lg border border-slate-300 p-0.5 bg-slate-50">
              <button
                onClick={() => setViewMode('both')}
                className={`px-2.5 py-1 rounded text-xs font-medium transition ${
                  viewMode === 'both' ? 'bg-white shadow-xs text-indigo-700 font-semibold' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Comprehensive
              </button>
              <button
                onClick={() => setViewMode('cards')}
                className={`px-2.5 py-1 rounded text-xs font-medium transition ${
                  viewMode === 'cards' ? 'bg-white shadow-xs text-indigo-700 font-semibold' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Cards Grid
              </button>
              <button
                onClick={() => setViewMode('table')}
                className={`px-2.5 py-1 rounded text-xs font-medium transition ${
                  viewMode === 'table' ? 'bg-white shadow-xs text-indigo-700 font-semibold' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Broad Table
              </button>
            </div>
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex flex-wrap items-center gap-1.5 pt-2 border-t border-slate-100 text-xs">
          <span className="text-slate-400 font-medium text-[11px] mr-1">Categories:</span>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-2.5 py-1 rounded-full text-xs font-medium transition capitalize ${
                selectedCategory === cat
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {cat === 'all' ? 'All Categories' : cat}
            </button>
          ))}
          <span className="ml-auto text-[11px] text-slate-400 font-mono">
            Showing {filteredParas.length} of {paraStats.length} paras
          </span>
        </div>
      </div>

      {/* 4. Broad Multi-Para Reconciliation Table (When viewMode is 'both' or 'table') */}
      {(viewMode === 'both' || viewMode === 'table') && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileSpreadsheet className="w-4 h-4 text-indigo-600" />
              <h2 className="text-sm font-bold text-slate-900">
                Cross-Paragraph Audit Reconciliation Matrix
              </h2>
              <span className="text-xs text-slate-500 font-mono">
                ({filteredParas.length} Paras loaded)
              </span>
            </div>
            <div className="text-xs text-slate-500 hidden sm:block">
              Click &quot;Open Ledger&quot; on any Para to inspect and edit its specific records
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-100/90 text-slate-700 font-bold border-b border-slate-200 uppercase tracking-wider text-[11px]">
                  <th className="py-3 px-3">Para No</th>
                  <th className="py-3 px-3">Subject & Scope</th>
                  <th className="py-3 px-3 text-center">Cases</th>
                  <th className="py-3 px-3 text-right">Assessed (Rs.)</th>
                  <th className="py-3 px-3 text-right">Recovered (Rs.)</th>
                  <th className="py-3 px-3 text-right">Relief / Prior</th>
                  <th className="py-3 px-3 text-right">Balance Due (Rs.)</th>
                  <th className="py-3 px-3 text-center min-w-[120px]">Settlement %</th>
                  <th className="py-3 px-3 text-center">Stage Distribution</th>
                  <th className="py-3 px-3 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {filteredParas.map((p) => {
                  return (
                    <tr
                      key={p.paraNo}
                      className="hover:bg-indigo-50/40 transition-colors group"
                    >
                      {/* Para No */}
                      <td className="py-3 px-3 font-mono font-bold whitespace-nowrap">
                        <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-indigo-50 text-indigo-700 border border-indigo-200 font-semibold">
                          {p.paraNo}
                        </span>
                      </td>

                      {/* Title & Description */}
                      <td className="py-3 px-3 max-w-xs">
                        <div className="font-bold text-slate-900 line-clamp-1 group-hover:text-indigo-900">
                          {p.meta.title}
                        </div>
                        <div className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                          {p.meta.description}
                        </div>
                      </td>

                      {/* Case Count */}
                      <td className="py-3 px-3 text-center font-mono font-semibold">
                        <span className="px-2 py-0.5 bg-slate-100 rounded-full text-slate-700">
                          {p.count}
                        </span>
                      </td>

                      {/* Assessed */}
                      <td className="py-3 px-3 text-right font-mono font-semibold text-slate-900">
                        {formatCurrency(p.auditAmt)}
                      </td>

                      {/* Recovered */}
                      <td className="py-3 px-3 text-right font-mono font-bold text-emerald-700">
                        {formatCurrency(p.recovered)}
                      </td>

                      {/* Relief / Prior */}
                      <td className="py-3 px-3 text-right font-mono text-slate-600">
                        {formatCurrency(p.priorAudit + p.notDue)}
                      </td>

                      {/* Balance Due */}
                      <td className="py-3 px-3 text-right font-mono font-bold">
                        <span
                          className={
                            p.balance > 0 ? 'text-rose-600 font-black' : 'text-emerald-700 font-semibold'
                          }
                        >
                          {formatCurrency(p.balance)}
                        </span>
                      </td>

                      {/* Settlement Progress */}
                      <td className="py-3 px-3 text-center">
                        <div className="flex items-center justify-center gap-2">
                          <div className="w-16 bg-slate-100 h-2 rounded-full overflow-hidden">
                            <div
                              className={`h-2 rounded-full ${
                                p.recoveryRate === 100
                                  ? 'bg-emerald-500'
                                  : p.recoveryRate >= 70
                                  ? 'bg-indigo-500'
                                  : p.recoveryRate >= 40
                                  ? 'bg-amber-500'
                                  : 'bg-rose-500'
                              }`}
                              style={{ width: `${p.recoveryRate}%` }}
                            />
                          </div>
                          <span className="font-mono font-bold text-[11px] text-slate-800 w-8 text-right">
                            {p.recoveryRate}%
                          </span>
                        </div>
                      </td>

                      {/* Stage Distribution */}
                      <td className="py-3 px-3 text-center whitespace-nowrap">
                        <div className="inline-flex items-center gap-1 text-[10px] font-mono">
                          {p.pendingCount > 0 && (
                            <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-600" title="Pending">
                              P:{p.pendingCount}
                            </span>
                          )}
                          {p.firstCount > 0 && (
                            <span className="px-1.5 py-0.5 rounded bg-blue-100 text-blue-700" title="1st Verification">
                              1v:{p.firstCount}
                            </span>
                          )}
                          {p.secondCount > 0 && (
                            <span className="px-1.5 py-0.5 rounded bg-amber-100 text-amber-800" title="2nd Verification">
                              2v:{p.secondCount}
                            </span>
                          )}
                          {p.thirdCount > 0 && (
                            <span className="px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold" title="3rd Final Verification">
                              3v:{p.thirdCount}
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-3 text-center whitespace-nowrap">
                        <div className="inline-flex items-center gap-1.5">
                          <button
                            onClick={() => onSelectParaForLedger(p.paraNo)}
                            className="px-2.5 py-1 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded text-[11px] flex items-center gap-1 shadow-xs transition"
                            title={`Open ${p.paraNo} Ledger view`}
                          >
                            <span>Open Ledger</span>
                            <ChevronRight className="w-3 h-3" />
                          </button>
                          <button
                            onClick={() => onOpenReportModalForPara(p.paraNo)}
                            className="p-1 hover:bg-slate-100 text-slate-600 hover:text-slate-900 rounded transition"
                            title="Print Para Verification Report"
                          >
                            <Printer className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              {/* Grand Total Footer */}
              <tfoot>
                <tr className="bg-slate-900 text-white font-bold border-t-2 border-slate-700 text-xs">
                  <td className="py-3 px-3">GRAND TOTAL</td>
                  <td className="py-3 px-3 font-normal text-slate-300">
                    Consolidated {portfolioSummary.totalParas} Audit Paras
                  </td>
                  <td className="py-3 px-3 text-center font-mono">{portfolioSummary.totalRecords}</td>
                  <td className="py-3 px-3 text-right font-mono text-indigo-300">
                    {formatCurrency(portfolioSummary.totalAudit)}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-emerald-400">
                    {formatCurrency(portfolioSummary.totalRecovered)}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-slate-300">
                    {formatCurrency(portfolioSummary.totalPrior + portfolioSummary.totalNotDue)}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-rose-300">
                    {formatCurrency(portfolioSummary.totalBalance)}
                  </td>
                  <td className="py-3 px-3 text-center font-mono text-emerald-400">
                    {portfolioSummary.overallRate}% Recovered
                  </td>
                  <td colSpan={2} className="py-3 px-3 text-center text-[11px] text-slate-400 font-normal">
                    Reconciled across all tax circles
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      )}

      {/* 5. Broad Card Grid View (When viewMode is 'both' or 'cards') */}
      {(viewMode === 'both' || viewMode === 'cards') && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Building className="w-4 h-4 text-indigo-600" />
              <span>Audit Paragraphs Broad Card Directory</span>
            </h2>
            <span className="text-xs text-slate-500 font-mono">
              Individual scorecard for each audit paragraph
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {filteredParas.map((p) => {
              return (
                <div
                  key={p.paraNo}
                  className="bg-white rounded-xl border border-slate-200 hover:border-indigo-300 shadow-xs hover:shadow-md transition flex flex-col justify-between overflow-hidden group"
                >
                  {/* Card Top */}
                  <div className="p-5 space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="px-2.5 py-0.5 rounded-md bg-indigo-50 border border-indigo-200 text-indigo-800 font-bold font-mono text-xs">
                            {p.paraNo}
                          </span>
                          {p.meta.category && (
                            <span className="px-2 py-0.5 rounded text-[10px] font-medium bg-slate-100 text-slate-600 uppercase">
                              {p.meta.category}
                            </span>
                          )}
                        </div>
                        <h3 className="text-sm font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                          {p.meta.title}
                        </h3>
                      </div>

                      {/* Status badge */}
                      <div>
                        {p.settlementStatus === 'settled' ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold text-[10px]">
                            <CheckCircle2 className="w-3 h-3" />
                            100% Settled
                          </span>
                        ) : p.settlementStatus === 'high_recovery' ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800 font-semibold text-[10px]">
                            <TrendingUp className="w-3 h-3" />
                            {p.recoveryRate}% Realized
                          </span>
                        ) : p.balance > 0 ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 font-semibold text-[10px]">
                            <Clock className="w-3 h-3" />
                            Rs. {formatCurrency(p.balance)} Due
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 text-[10px]">
                            In Progress
                          </span>
                        )}
                      </div>
                    </div>

                    <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                      {p.meta.description}
                    </p>

                    {/* Progress Bar */}
                    <div className="space-y-1 pt-1">
                      <div className="flex justify-between text-[11px] font-mono">
                        <span className="text-slate-500">Recovery Progress</span>
                        <span className="font-bold text-slate-800">{p.recoveryRate}%</span>
                      </div>
                      <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                        <div
                          className={`h-2 rounded-full transition-all ${
                            p.recoveryRate === 100
                              ? 'bg-emerald-500'
                              : p.recoveryRate >= 70
                              ? 'bg-indigo-500'
                              : p.recoveryRate >= 40
                              ? 'bg-amber-500'
                              : 'bg-rose-500'
                          }`}
                          style={{ width: `${p.recoveryRate}%` }}
                        />
                      </div>
                    </div>

                    {/* 4-Stat Box */}
                    <div className="grid grid-cols-2 gap-2 bg-slate-50 p-2.5 rounded-lg border border-slate-100 text-xs font-mono">
                      <div>
                        <span className="text-[10px] text-slate-400 block uppercase font-sans">Assessed</span>
                        <span className="font-bold text-slate-800">{formatCurrency(p.auditAmt)}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block uppercase font-sans">Recovered</span>
                        <span className="font-bold text-emerald-700">{formatCurrency(p.recovered)}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block uppercase font-sans">Relief / Prior</span>
                        <span className="text-slate-600">{formatCurrency(p.priorAudit + p.notDue)}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block uppercase font-sans">Outstanding</span>
                        <span className={`font-bold ${p.balance > 0 ? 'text-rose-600' : 'text-slate-700'}`}>
                          {formatCurrency(p.balance)}
                        </span>
                      </div>
                    </div>

                    {/* Stage Distribution & Properties snippet */}
                    <div className="pt-1 flex items-center justify-between text-[11px]">
                      <div className="text-slate-500 font-mono">
                        <span className="font-bold text-slate-700">{p.count}</span> Properties
                      </div>
                      <div className="flex items-center gap-1 font-mono text-[10px]">
                        <span className="px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 font-semibold" title="3rd Ver">
                          {p.thirdCount} Verified
                        </span>
                        {p.balance > 0 && (
                          <span className="px-1.5 py-0.5 rounded bg-rose-50 text-rose-700 font-semibold">
                            {p.records.filter((r) => r.balance > 0).length} Unsettled
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Card Actions Footer */}
                  <div className="p-3 bg-slate-50/80 border-t border-slate-100 flex items-center justify-between gap-2">
                    <button
                      onClick={() => onSelectParaForLedger(p.paraNo)}
                      className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs transition"
                    >
                      <FolderOpen className="w-3.5 h-3.5" />
                      <span>View Para Ledger</span>
                    </button>

                    <div className="flex items-center gap-1">
                      {onOpenAddRecordModalForPara && (
                        <button
                          onClick={() => onOpenAddRecordModalForPara(p.paraNo, p.meta.title)}
                          className="p-1.5 hover:bg-slate-200 text-slate-600 hover:text-slate-900 rounded-lg transition"
                          title={`Add property to ${p.paraNo}`}
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      )}
                      <button
                        onClick={() => onOpenReportModalForPara(p.paraNo)}
                        className="p-1.5 hover:bg-slate-200 text-slate-600 hover:text-slate-900 rounded-lg transition"
                        title="Generate Verification Report"
                      >
                        <Printer className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 6. Broad Comparative Visuals & High-Risk Paras Bar Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Comparison Bar Visual */}
        <div className="lg:col-span-2 bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-indigo-600" />
              <span>Cross-Paragraph Demand vs Realization Comparison</span>
            </h3>
            <span className="text-xs text-slate-400 font-mono">Assessed vs Recovered</span>
          </div>

          <div className="space-y-3 pt-2">
            {paraStats.map((p) => {
              const maxAudit = Math.max(...paraStats.map((x) => x.auditAmt), 1);
              const barWidth = Math.round((p.auditAmt / maxAudit) * 100);
              const recoveredWidth = p.auditAmt > 0 ? Math.round((p.recovered / p.auditAmt) * 100) : 0;

              return (
                <div key={p.paraNo} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-slate-900 w-16">{p.paraNo}</span>
                      <span className="text-slate-600 truncate max-w-[180px] sm:max-w-xs">{p.meta.title}</span>
                    </div>
                    <div className="text-right font-mono text-[11px]">
                      <span className="text-emerald-700 font-bold">{formatCurrency(p.recovered)}</span>
                      <span className="text-slate-400"> / {formatCurrency(p.auditAmt)}</span>
                    </div>
                  </div>

                  {/* Relative bar */}
                  <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden flex">
                    <div
                      className="bg-indigo-200 h-3 rounded-full relative overflow-hidden"
                      style={{ width: `${barWidth}%` }}
                    >
                      <div
                        className="bg-emerald-500 h-3 rounded-full transition-all"
                        style={{ width: `${recoveredWidth}%` }}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="flex items-center gap-4 text-[11px] text-slate-500 pt-2 border-t border-slate-100">
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 bg-emerald-500 rounded-sm" />
              <span>Realized Recovery</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 bg-indigo-200 rounded-sm" />
              <span>Assessed Demand</span>
            </div>
            <div className="ml-auto text-slate-400 font-mono">
              Total {paraStats.length} Paras Charted
            </div>
          </div>
        </div>

        {/* Priority Action Card for High-Balance Paras */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center gap-2 text-rose-600 font-bold text-sm">
              <AlertTriangle className="w-4 h-4" />
              <span>Priority Audit Paras Action Matrix</span>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Paragraphs sorted by highest outstanding balance requiring immediate verification notices or accounts reconciliation.
            </p>

            <div className="space-y-2.5 mt-4">
              {paraStats
                .filter((p) => p.balance > 0)
                .sort((a, b) => b.balance - a.balance)
                .slice(0, 4)
                .map((p) => (
                  <div
                    key={p.paraNo}
                    onClick={() => onSelectParaForLedger(p.paraNo)}
                    className="p-2.5 rounded-lg border border-rose-100 bg-rose-50/50 hover:bg-rose-50 cursor-pointer transition flex items-center justify-between"
                  >
                    <div>
                      <div className="font-bold text-xs text-slate-900 flex items-center gap-1.5">
                        <span className="font-mono text-indigo-700">{p.paraNo}</span>
                        <span className="truncate max-w-[140px]">{p.meta.title}</span>
                      </div>
                      <div className="text-[10px] text-slate-500 font-mono mt-0.5">
                        {p.count} properties · {p.recoveryRate}% recovered
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-mono font-bold text-xs text-rose-600">
                        {formatCurrency(p.balance)}
                      </div>
                      <div className="text-[9px] text-slate-400 uppercase">Balance Due</div>
                    </div>
                  </div>
                ))}
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100">
            <button
              onClick={onOpenAccountsOfficeModal}
              className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-lg flex items-center justify-center gap-2 transition"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Accounts Office Settlement Ledger</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
