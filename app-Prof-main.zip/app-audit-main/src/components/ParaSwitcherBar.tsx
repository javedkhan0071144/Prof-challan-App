import React from 'react';
import { AuditRecord, AuditParaInfo } from '../types';
import { formatCurrency } from '../utils/formatters';
import {
  Layers,
  ChevronRight,
  Plus,
  Printer,
  X,
  CheckCircle2,
  AlertTriangle,
  FolderOpen,
  Building
} from 'lucide-react';

interface ParaSwitcherBarProps {
  records: AuditRecord[];
  paras: AuditParaInfo[];
  selectedPara: string; // 'all' or specific e.g. 'Para-1'
  onSelectPara: (paraNo: string) => void;
  onOpenAddParaModal: () => void;
  onOpenAddRecordForPara?: (paraNo: string, details: string) => void;
  onOpenReportForPara?: (paraNo: string) => void;
}

export const ParaSwitcherBar: React.FC<ParaSwitcherBarProps> = ({
  records,
  paras,
  selectedPara,
  onSelectPara,
  onOpenAddParaModal,
  onOpenAddRecordForPara,
  onOpenReportForPara,
}) => {
  // Discover all paras from paras and records
  const allParaNos = Array.from(
    new Set([
      ...paras.map((p) => p.paraNo),
      ...records.map((r) => r.paraNo || 'Para-General'),
    ])
  ).sort();

  // Selected para info
  const currentParaMeta = paras.find((p) => p.paraNo === selectedPara);
  const currentParaRecords = records.filter(
    (r) => selectedPara === 'all' || (r.paraNo || 'Para-General') === selectedPara
  );

  const paraAuditAmt = currentParaRecords.reduce((sum, r) => sum + (r.auditAmt || 0), 0);
  const paraRecovered = currentParaRecords.reduce((sum, r) => sum + (r.recovered || 0), 0);
  const paraBalance = currentParaRecords.reduce((sum, r) => sum + (r.balance || 0), 0);
  const paraRate = paraAuditAmt > 0 ? Math.min(100, Math.round((paraRecovered / paraAuditAmt) * 100)) : 0;

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-3.5 shadow-xs space-y-3">
      {/* Top row: Label & Para horizontal pill tabs */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2 shrink-0">
          <Layers className="w-4 h-4 text-indigo-600" />
          <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
            Audit Paras:
          </span>
        </div>

        {/* Scrollable pill container */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full text-xs scrollbar-thin">
          {/* All Paras option */}
          <button
            onClick={() => onSelectPara('all')}
            className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-all flex items-center gap-1.5 ${
              selectedPara === 'all'
                ? 'bg-slate-900 text-white shadow-xs font-semibold'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <span>All Paras (Consolidated)</span>
            <span
              className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
                selectedPara === 'all' ? 'bg-slate-700 text-white' : 'bg-slate-200 text-slate-600'
              }`}
            >
              {records.length}
            </span>
          </button>

          {/* Individual Para pills */}
          {allParaNos.map((pNo) => {
            const meta = paras.find((p) => p.paraNo === pNo);
            const count = records.filter((r) => (r.paraNo || 'Para-General') === pNo).length;
            const isSelected = selectedPara === pNo;

            return (
              <button
                key={pNo}
                onClick={() => onSelectPara(pNo)}
                className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-all flex items-center gap-1.5 ${
                  isSelected
                    ? 'bg-indigo-600 text-white shadow-xs font-semibold'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200 hover:text-slate-900'
                }`}
                title={meta?.title || pNo}
              >
                <span className="font-mono font-bold">{pNo}</span>
                {meta && (
                  <span className="hidden sm:inline text-[11px] opacity-90 max-w-[130px] truncate">
                    : {meta.title.split('&')[0].trim()}
                  </span>
                )}
                <span
                  className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
                    isSelected ? 'bg-indigo-800 text-white' : 'bg-slate-200 text-slate-600'
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          })}

          {/* Register new Para button */}
          <button
            onClick={onOpenAddParaModal}
            className="px-2.5 py-1.5 rounded-lg border border-dashed border-indigo-300 hover:border-indigo-500 text-indigo-600 hover:bg-indigo-50/50 font-medium whitespace-nowrap transition flex items-center gap-1 shrink-0"
            title="Register a new Audit Paragraph"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Para</span>
          </button>
        </div>
      </div>

      {/* When a specific Para is selected: Contextual Active Para Card */}
      {selectedPara !== 'all' && (
        <div className="bg-indigo-50/70 border border-indigo-100 rounded-lg p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs animate-in fade-in duration-150">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded bg-indigo-600 text-white font-mono font-bold text-xs">
                {selectedPara}
              </span>
              <span className="font-bold text-slate-900">
                {currentParaMeta?.title || `Audit Paragraph ${selectedPara}`}
              </span>
              {currentParaMeta?.category && (
                <span className="px-2 py-0.5 rounded bg-white text-slate-600 text-[10px] border border-indigo-200 uppercase font-medium">
                  {currentParaMeta.category}
                </span>
              )}
            </div>
            {currentParaMeta?.description && (
              <p className="text-slate-600 text-[11px] line-clamp-1 max-w-2xl">
                {currentParaMeta.description}
              </p>
            )}
          </div>

          {/* Right side stats & quick actions */}
          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <div className="flex items-center gap-3 font-mono text-[11px]">
              <div>
                <span className="text-slate-500 block text-[9px] uppercase font-sans">Assessed</span>
                <span className="font-bold text-slate-900">{formatCurrency(paraAuditAmt)}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[9px] uppercase font-sans">Recovered</span>
                <span className="font-bold text-emerald-700">{formatCurrency(paraRecovered)} ({paraRate}%)</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[9px] uppercase font-sans">Balance</span>
                <span className={`font-bold ${paraBalance > 0 ? 'text-rose-600' : 'text-slate-900'}`}>
                  {formatCurrency(paraBalance)}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              {onOpenAddRecordForPara && (
                <button
                  onClick={() =>
                    onOpenAddRecordForPara(selectedPara, currentParaMeta?.title || selectedPara)
                  }
                  className="px-2.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-md font-medium text-[11px] flex items-center gap-1 shadow-xs transition"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Record</span>
                </button>
              )}
              {onOpenReportForPara && (
                <button
                  onClick={() => onOpenReportForPara(selectedPara)}
                  className="px-2.5 py-1.5 bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 rounded-md font-medium text-[11px] flex items-center gap-1 transition"
                  title="Print report for this Para"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Report</span>
                </button>
              )}
              <button
                onClick={() => onSelectPara('all')}
                className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-white rounded-md transition"
                title="Clear Para filter"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
