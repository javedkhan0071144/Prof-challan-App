import React, { useState, useEffect } from 'react';
import { AuditRecord, AuditParaInfo } from '../types';
import { calculateBalance, formatCurrency } from '../utils/formatters';
import { X, Sparkles, Check, Calculator, Info, Layers } from 'lucide-react';

interface RecordModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (record: AuditRecord) => void;
  recordToEdit: AuditRecord | null;
  nextId: number;
  paras?: AuditParaInfo[];
  defaultParaNo?: string;
  defaultDetails?: string;
}

export const RecordModal: React.FC<RecordModalProps> = ({
  isOpen,
  onClose,
  onSave,
  recordToEdit,
  nextId,
  paras = [],
  defaultParaNo,
  defaultDetails,
}) => {
  const isEditing = Boolean(recordToEdit);

  // Form State
  const [id, setId] = useState<number>(nextId);
  const [district, setDistrict] = useState<string>('RWP');
  const [tehsil, setTehsil] = useState<string>('GK');
  const [circle, setCircle] = useState<string>('GKB-II');
  const [propertyNo, setPropertyNo] = useState<string>('');
  const [owner, setOwner] = useState<string>('');
  const [auditAmt, setAuditAmt] = useState<number>(0);
  const [recovered, setRecovered] = useState<number>(0);
  const [priorAudit, setPriorAudit] = useState<number>(0);
  const [notDue, setNotDue] = useState<number>(0);
  const [receiptAmt, setReceiptAmt] = useState<number>(0);
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [verified, setVerified] = useState<boolean>(false);
  const [verificationStage, setVerificationStage] = useState<'pending' | '1st' | '2nd' | '3rd'>('pending');
  const [firstVerDate, setFirstVerDate] = useState<string>('');
  const [secondVerDate, setSecondVerDate] = useState<string>('');
  const [thirdVerDate, setThirdVerDate] = useState<string>('');
  const [details, setDetails] = useState<string>(defaultDetails || '1-Commercial Plaza');
  const [paraNo, setParaNo] = useState<string>(defaultParaNo || 'Para-1');
  const [auditSrNo, setAuditSrNo] = useState<number>(1);
  const [remarks, setRemarks] = useState<string>('');
  const [challanNo, setChallanNo] = useState<string>('');

  // Computed Balance using AppSheet Formula
  const calculatedBalance = calculateBalance(auditAmt, recovered, priorAudit, notDue);

  useEffect(() => {
    if (recordToEdit) {
      setId(recordToEdit.id);
      setDistrict(recordToEdit.district || 'RWP');
      setTehsil(recordToEdit.tehsil || '');
      setCircle(recordToEdit.circle || '');
      setPropertyNo(recordToEdit.propertyNo || '');
      setOwner(recordToEdit.owner || '');
      setAuditAmt(recordToEdit.auditAmt || 0);
      setRecovered(recordToEdit.recovered || 0);
      setPriorAudit(recordToEdit.priorAudit || 0);
      setNotDue(recordToEdit.notDue || 0);
      setReceiptAmt(recordToEdit.receiptAmt || 0);
      setDate(recordToEdit.date || '');
      setVerified(Boolean(recordToEdit.verified));
      setVerificationStage(recordToEdit.verificationStage || (recordToEdit.verified ? '3rd' : 'pending'));
      setFirstVerDate(recordToEdit.firstVerDate || '');
      setSecondVerDate(recordToEdit.secondVerDate || '');
      setThirdVerDate(recordToEdit.thirdVerDate || '');
      setDetails(recordToEdit.details || '1-Commercial Plaza');
      setParaNo(recordToEdit.paraNo || 'Para-1');
      setAuditSrNo(recordToEdit.auditSrNo || recordToEdit.id);
      setRemarks(recordToEdit.remarks || '');
      setChallanNo(recordToEdit.challanNo || '');
    } else {
      setId(nextId);
      setDistrict('RWP');
      setTehsil('GK');
      setCircle('GKB-II');
      setPropertyNo('');
      setOwner('');
      setAuditAmt(0);
      setRecovered(0);
      setPriorAudit(0);
      setNotDue(0);
      setReceiptAmt(0);
      setDate(new Date().toISOString().split('T')[0]);
      setVerified(false);
      setVerificationStage('pending');
      setFirstVerDate('');
      setSecondVerDate('');
      setThirdVerDate('');
      setDetails(defaultDetails || (paras[0]?.title ?? '1-Commercial Plaza'));
      setParaNo(defaultParaNo || (paras[0]?.paraNo ?? 'Para-1'));
      setAuditSrNo(nextId);
      setRemarks('');
      setChallanNo(`CH-${new Date().getFullYear()}-${String(nextId).padStart(3, '0')}`);
    }
  }, [recordToEdit, nextId, isOpen, defaultParaNo, defaultDetails, paras]);

  if (!isOpen) return null;

  const handleSettleFull = () => {
    setRecovered(auditAmt);
    setReceiptAmt(auditAmt);
    setPriorAudit(0);
    setNotDue(0);
    setVerified(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!propertyNo.trim()) {
      return;
    }

    const savedRecord: AuditRecord = {
      id,
      details,
      paraNo,
      district,
      tehsil,
      circle,
      propertyNo: propertyNo.trim(),
      owner: owner.trim() || 'Unassigned',
      auditSrNo: auditSrNo || id,
      auditAmt: Number(auditAmt) || 0,
      recovered: Number(recovered) || 0,
      priorAudit: Number(priorAudit) || 0,
      notDue: Number(notDue) || 0,
      receiptAmt: Number(receiptAmt) || 0,
      balance: calculatedBalance,
      date,
      verified: verificationStage === '3rd',
      verificationStage,
      firstVerDate,
      secondVerDate,
      thirdVerDate,
      remarks: remarks.trim(),
      challanNo: challanNo.trim(),
      updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 16)
    };

    onSave(savedRecord);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-slate-200">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between bg-white shrink-0">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900">
              {isEditing ? `Edit Audit Record #${id}` : 'Add New Property Tax Audit Record'}
            </h2>
            <p className="text-xs text-slate-500">
              AppSheet dynamic evaluation model with instant recovery calculation
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-5">
          {/* Key & Geographical Section */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Sr/No-ID (Key)
              </label>
              <input
                type="number"
                value={id}
                onChange={(e) => setId(parseInt(e.target.value, 10) || 1)}
                readOnly={isEditing}
                className={`w-full border rounded-lg px-3 py-2 text-sm font-mono font-semibold ${
                  isEditing
                    ? 'bg-slate-100 border-slate-200 text-slate-700'
                    : 'border-slate-300 bg-white text-slate-900'
                }`}
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                District
              </label>
              <input
                type="text"
                required
                value={district}
                onChange={(e) => setDistrict(e.target.value)}
                placeholder="e.g. RWP"
                className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-800 focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Tehsil
              </label>
              <input
                type="text"
                required
                value={tehsil}
                onChange={(e) => setTehsil(e.target.value)}
                placeholder="e.g. GK, Taxila"
                className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-800 focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Circle Name
              </label>
              <input
                type="text"
                required
                value={circle}
                onChange={(e) => setCircle(e.target.value)}
                placeholder="e.g. GKB-II, Taxila"
                className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-800 focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          {/* Property & Taxpayer Identification */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Property No <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={propertyNo}
                onChange={(e) => setPropertyNo(e.target.value)}
                placeholder="e.g. 468-A-12/Pump"
                className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm font-semibold text-indigo-900 font-mono focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Owner / Organization Name <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={owner}
                onChange={(e) => setOwner(e.target.value)}
                placeholder="e.g. Al-Madina Petroleum"
                className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-800 focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          {/* Audit Amount & Quick Settle */}
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                <Calculator className="w-4 h-4 text-indigo-600" />
                Audit Assessment & Balance Engine
              </label>
              <button
                type="button"
                onClick={handleSettleFull}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 hover:underline cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5" />
                Auto-Settle Full Recovery
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">
                  Audit Assessment Amount (Rs.) <span className="text-rose-500">*</span>
                </label>
                <input
                  type="number"
                  min="0"
                  step="any"
                  required
                  value={auditAmt || ''}
                  onChange={(e) => setAuditAmt(parseFloat(e.target.value) || 0)}
                  placeholder="0"
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm font-mono font-bold text-slate-900 focus:ring-2 focus:ring-indigo-500 bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">
                  Receipt Amount (Rs.)
                </label>
                <input
                  type="number"
                  min="0"
                  step="any"
                  value={receiptAmt || ''}
                  onChange={(e) => setReceiptAmt(parseFloat(e.target.value) || 0)}
                  placeholder="0"
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm font-mono font-semibold text-emerald-700 focus:ring-2 focus:ring-indigo-500 bg-white"
                />
              </div>
            </div>

            {/* Dynamic Recovery Fields */}
            <div className="pt-2 border-t border-slate-200/80">
              <div className="text-[11px] font-semibold text-slate-500 mb-2 uppercase tracking-wide">
                Deductions & Recoveries
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">
                    Recovered (Rs.)
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    value={recovered || ''}
                    onChange={(e) => setRecovered(parseFloat(e.target.value) || 0)}
                    placeholder="0"
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm font-mono text-emerald-600 focus:ring-2 focus:ring-indigo-500 bg-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">
                    Prior Audit (Rs.)
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    value={priorAudit || ''}
                    onChange={(e) => setPriorAudit(parseFloat(e.target.value) || 0)}
                    placeholder="0"
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm font-mono text-slate-700 focus:ring-2 focus:ring-indigo-500 bg-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">
                    Not Due (Rs.)
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    value={notDue || ''}
                    onChange={(e) => setNotDue(parseFloat(e.target.value) || 0)}
                    placeholder="0"
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm font-mono text-slate-700 focus:ring-2 focus:ring-indigo-500 bg-white"
                  />
                </div>
              </div>
            </div>

            {/* Live Formula Display */}
            <div className="p-3 bg-white rounded-lg border border-slate-200 flex items-center justify-between">
              <div>
                <span className="text-xs font-semibold text-slate-600">Calculated Balance (AppSheet Formula)</span>
                <p className="text-[11px] text-slate-400 font-mono">
                  {formatCurrency(auditAmt)} - {formatCurrency(recovered)} - {formatCurrency(priorAudit)} - {formatCurrency(notDue)}
                </p>
              </div>
              <div className="text-right">
                <span className={`text-lg font-bold font-mono ${calculatedBalance > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
                  {formatCurrency(calculatedBalance)}
                </span>
                <div className="text-[10px] text-slate-400">
                  {calculatedBalance === 0 ? 'Zero Balance / Fully Settled' : calculatedBalance > 0 ? 'Outstanding Due' : 'Surplus / Overpaid'}
                </div>
              </div>
            </div>
          </div>

          {/* Date & Challan */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Assessment / Payment Date
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-800 focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Challan / Receipt Reference
              </label>
              <input
                type="text"
                value={challanNo}
                onChange={(e) => setChallanNo(e.target.value)}
                placeholder="e.g. CH-2026-091"
                className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm font-mono text-slate-800 focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          {/* Audit Verification Multi-Stage Arrangements */}
          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5 text-indigo-600" />
                Audit Verification Stages & Endorsement Dates
              </label>
              <span className="text-[11px] font-mono text-indigo-700 font-semibold">
                Status: {verificationStage === 'pending' ? 'Pending' : `${verificationStage} Verification`}
              </span>
            </div>

            {/* Stage Selector Tabs */}
            <div className="grid grid-cols-4 gap-1.5 p-1 bg-white rounded-lg border border-slate-200 text-xs">
              <button
                type="button"
                onClick={() => setVerificationStage('pending')}
                className={`py-1.5 px-2 rounded-md font-semibold text-center transition ${
                  verificationStage === 'pending'
                    ? 'bg-amber-100 text-amber-900 shadow-xs'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                Pending
              </button>
              <button
                type="button"
                onClick={() => {
                  setVerificationStage('1st');
                  if (!firstVerDate) setFirstVerDate(new Date().toISOString().split('T')[0]);
                }}
                className={`py-1.5 px-2 rounded-md font-semibold text-center transition ${
                  verificationStage === '1st'
                    ? 'bg-blue-100 text-blue-900 shadow-xs'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                1st Ver
              </button>
              <button
                type="button"
                onClick={() => {
                  setVerificationStage('2nd');
                  if (!secondVerDate) setSecondVerDate(new Date().toISOString().split('T')[0]);
                }}
                className={`py-1.5 px-2 rounded-md font-semibold text-center transition ${
                  verificationStage === '2nd'
                    ? 'bg-indigo-100 text-indigo-900 shadow-xs'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                2nd Ver
              </button>
              <button
                type="button"
                onClick={() => {
                  setVerificationStage('3rd');
                  if (!thirdVerDate) setThirdVerDate(new Date().toISOString().split('T')[0]);
                }}
                className={`py-1.5 px-2 rounded-md font-semibold text-center transition ${
                  verificationStage === '3rd'
                    ? 'bg-emerald-100 text-emerald-900 shadow-xs'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                3rd Ver (Final)
              </button>
            </div>

            {/* 3 Verification Dated Inputs */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">
                  1st Ver Dated
                </label>
                <input
                  type="date"
                  value={firstVerDate}
                  onChange={(e) => {
                    setFirstVerDate(e.target.value);
                    if (e.target.value && verificationStage === 'pending') setVerificationStage('1st');
                  }}
                  className="w-full border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 focus:ring-2 focus:ring-indigo-500 bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">
                  2nd Ver Dated
                </label>
                <input
                  type="date"
                  value={secondVerDate}
                  onChange={(e) => {
                    setSecondVerDate(e.target.value);
                    if (e.target.value && (verificationStage === 'pending' || verificationStage === '1st')) {
                      setVerificationStage('2nd');
                    }
                  }}
                  className="w-full border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 focus:ring-2 focus:ring-indigo-500 bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">
                  3rd Ver Dated (Final)
                </label>
                <input
                  type="date"
                  value={thirdVerDate}
                  onChange={(e) => {
                    setThirdVerDate(e.target.value);
                    if (e.target.value) setVerificationStage('3rd');
                  }}
                  className="w-full border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 focus:ring-2 focus:ring-indigo-500 bg-white"
                />
              </div>
            </div>
          </div>

          {/* Audit Para Classification */}
          <div className="p-3.5 bg-indigo-50/50 border border-indigo-100 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-indigo-600" />
                Audit Paragraph Classification
              </label>
              {paras.length > 0 && (
                <span className="text-[11px] text-slate-500">
                  Select existing or type custom
                </span>
              )}
            </div>

            {paras.length > 0 && (
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Quick Select Existing Para:
                </label>
                <select
                  value={paraNo}
                  onChange={(e) => {
                    const selected = paras.find((p) => p.paraNo === e.target.value);
                    if (selected) {
                      setParaNo(selected.paraNo);
                      setDetails(selected.title);
                    } else {
                      setParaNo(e.target.value);
                    }
                  }}
                  className="w-full text-xs border border-indigo-200 bg-white rounded-lg px-3 py-2 text-indigo-900 font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  {paras.map((p) => (
                    <option key={p.paraNo} value={p.paraNo}>
                      {p.paraNo}: {p.title}
                    </option>
                  ))}
                  <option value="__custom__">+ Custom Paragraph</option>
                </select>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">
                  Para No <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={paraNo === '__custom__' ? '' : paraNo}
                  onChange={(e) => setParaNo(e.target.value)}
                  placeholder="e.g. Para-1, Para-6"
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm font-mono font-bold text-slate-800 focus:ring-2 focus:ring-indigo-500 bg-white"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">
                  Para Details / Scope
                </label>
                <input
                  type="text"
                  value={details}
                  onChange={(e) => setDetails(e.target.value)}
                  placeholder="e.g. 1-Commercial Plaza, 6-Petrol Pump"
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-800 focus:ring-2 focus:ring-indigo-500 bg-white"
                />
              </div>
            </div>
          </div>

          {/* Remarks */}
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">
              Remarks & Auditor Notes
            </label>
            <textarea
              rows={2}
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              placeholder="e.g. Verification complete, Challan verified against National Bank of Pakistan scroll..."
              className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-800 focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Footer Actions */}
          <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-3 shrink-0">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-50 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white rounded-lg text-xs font-semibold shadow-xs transition flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>Save & Sync</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
