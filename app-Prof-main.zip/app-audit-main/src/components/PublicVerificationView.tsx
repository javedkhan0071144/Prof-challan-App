import React, { useState, useEffect } from 'react';
import { AuditRecord } from '../types';
import { formatCurrency } from '../utils/formatters';
import { generateQRCode, getVerificationFingerprint } from '../utils/qrCode';
import {
  ShieldCheck,
  CheckCircle2,
  Clock,
  Printer,
  ArrowLeft,
  Building2,
  Receipt,
  Download,
  AlertCircle,
  Copy,
  Check
} from 'lucide-react';

interface PublicVerificationViewProps {
  record: AuditRecord;
  onBack: () => void;
}

export const PublicVerificationView: React.FC<PublicVerificationViewProps> = ({
  record,
  onBack,
}) => {
  const [qrUrl, setQrUrl] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);

  const fingerprint = getVerificationFingerprint(record);
  const stage = record.verificationStage || (record.verified ? '3rd' : 'pending');
  const isSettled = (record.balance || 0) <= 0;

  useEffect(() => {
    // Generate QR code for the current URL
    generateQRCode(window.location.href, 260).then(setQrUrl).catch(() => {});
  }, [record]);

  const handlePrint = () => {
    window.print();
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800 flex flex-col antialiased">
      {/* Top Banner (Hidden in print) */}
      <header className="no-print bg-slate-900 text-white border-b border-slate-800 sticky top-0 z-30 shadow-md">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 px-3 py-1.5 rounded-lg border border-slate-700 transition cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Audit Ledger</span>
          </button>

          <div className="flex items-center gap-2 text-xs">
            <span className="hidden sm:inline text-slate-400 font-mono text-[11px]">
              Secure Public Verification Portal
            </span>
            <button
              onClick={handleCopyLink}
              className="bg-slate-800 hover:bg-slate-700 text-slate-200 px-2.5 py-1.5 rounded-lg border border-slate-700 transition flex items-center gap-1.5 cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Share URL'}</span>
            </button>
            <button
              onClick={handlePrint}
              className="bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-1.5 rounded-lg font-semibold flex items-center gap-1.5 transition cursor-pointer shadow-xs"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Certificate</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Certificate Sheet */}
      <main className="max-w-4xl mx-auto w-full px-4 py-8 flex-1">
        <div className="bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden">
          {/* Official Department Header */}
          <div className="bg-gradient-to-b from-slate-900 to-indigo-950 text-white p-6 sm:p-8 text-center relative">
            <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-indigo-600/30 border border-indigo-400/30 text-indigo-300 mb-3 shadow-inner">
              <Building2 className="w-6 h-6" />
            </div>
            <h2 className="text-xs font-mono uppercase tracking-widest text-indigo-300 font-bold mb-1">
              Government of Punjab · Islamic Republic of Pakistan
            </h2>
            <h1 className="text-lg sm:text-2xl font-black uppercase tracking-wide text-white">
              Excise, Taxation & Narcotics Control Department
            </h1>
            <p className="text-xs sm:text-sm text-indigo-200 font-medium mt-1">
              Official Property Tax Audit Assessment & Recovery Verification Certificate
            </p>

            {/* Official Digital Seal Badge */}
            <div className="mt-4 inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-bold shadow-md bg-emerald-500/20 text-emerald-300 border border-emerald-400/40">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>VERIFIED OFFICIAL RECORD · HEAD C02801</span>
            </div>
          </div>

          {/* Certificate Content */}
          <div className="p-6 sm:p-8 space-y-6">
            {/* Status Highlight Banner */}
            <div className={`p-4 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
              isSettled
                ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                : 'bg-amber-50 border-amber-200 text-amber-900'
            }`}>
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                  isSettled ? 'bg-emerald-600 text-white' : 'bg-amber-500 text-white'
                }`}>
                  {isSettled ? <CheckCircle2 className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
                </div>
                <div>
                  <h3 className="text-sm font-bold">
                    {isSettled
                      ? 'Assessment Cleared — Zero Outstanding Audit Balance'
                      : 'Audit Demand Outstanding — Payment Required'}
                  </h3>
                  <p className="text-xs opacity-80">
                    {isSettled
                      ? 'All audited liabilities have been verified and settled in government treasury.'
                      : `A recoverable balance of ${formatCurrency(record.balance)} remains due on this property.`}
                  </p>
                </div>
              </div>

              <div className="text-right sm:border-l sm:border-current/20 sm:pl-4 shrink-0 font-mono">
                <span className="text-[10px] uppercase font-bold block opacity-70">Audit Assessment Stage</span>
                <span className="text-sm font-black">
                  {stage === '3rd' ? '3rd Ver (Final Approved)' : stage === '2nd' ? '2nd Ver' : stage === '1st' ? '1st Ver' : 'Pending Verification'}
                </span>
              </div>
            </div>

            {/* Grid Layout: Property Details & QR Code Seal */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Left Column: Property & Assessee Details (2 cols) */}
              <div className="md:col-span-2 space-y-6">
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
                    <Receipt className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Property Identification & Ownership</span>
                  </h4>
                  <div className="grid grid-cols-2 gap-3 text-xs bg-slate-50 p-4 rounded-xl border border-slate-200">
                    <div>
                      <span className="text-slate-400 block text-[10px] uppercase font-semibold">Property No</span>
                      <span className="text-sm font-bold font-mono text-indigo-900">{record.propertyNo}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px] uppercase font-semibold">Assessee / Owner</span>
                      <span className="text-sm font-bold text-slate-800">{record.owner}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px] uppercase font-semibold">Tehsil & Circle</span>
                      <span className="font-semibold text-slate-800">{record.tehsil} · {record.circle}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px] uppercase font-semibold">Audit Para Details</span>
                      <span className="font-mono font-semibold text-slate-800">
                        {record.paraNo || 'Para-6'} ({record.details || 'Commercial'})
                      </span>
                    </div>
                  </div>
                </div>

                {/* Financial Audit Ledger */}
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
                    <Receipt className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Audit Financial Reconciliation</span>
                  </h4>
                  <div className="border border-slate-200 rounded-xl overflow-hidden">
                    <table className="w-full text-xs text-left">
                      <thead className="bg-slate-100 text-slate-600 font-bold uppercase text-[10px] border-b border-slate-200">
                        <tr>
                          <th className="py-2.5 px-3">Description</th>
                          <th className="py-2.5 px-3 text-right">Amount (PKR)</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 font-mono">
                        <tr>
                          <td className="py-2.5 px-3 font-sans text-slate-700">Audit Assessed Demand</td>
                          <td className="py-2.5 px-3 text-right font-bold text-slate-900">
                            {formatCurrency(record.auditAmt)}
                          </td>
                        </tr>
                        <tr>
                          <td className="py-2.5 px-3 font-sans text-emerald-800 font-semibold">
                            Total Recovered into Treasury
                          </td>
                          <td className="py-2.5 px-3 text-right font-bold text-emerald-700">
                            − {formatCurrency(record.recovered)}
                          </td>
                        </tr>
                        <tr>
                          <td className="py-2.5 px-3 font-sans text-slate-600">
                            Prior to Audit Deductions
                          </td>
                          <td className="py-2.5 px-3 text-right text-slate-700">
                            {(record.priorAudit || 0) > 0 ? `− ${formatCurrency(record.priorAudit)}` : 'Rs. 0'}
                          </td>
                        </tr>
                        <tr>
                          <td className="py-2.5 px-3 font-sans text-slate-600">
                            Not Due Amount (Statutory Exempt)
                          </td>
                          <td className="py-2.5 px-3 text-right text-slate-700">
                            {(record.notDue || 0) > 0 ? `− ${formatCurrency(record.notDue)}` : 'Rs. 0'}
                          </td>
                        </tr>
                        <tr className="bg-indigo-50/50">
                          <td className="py-2.5 px-3 font-sans text-indigo-900 font-semibold">
                            Receipt Amount Verified
                          </td>
                          <td className="py-2.5 px-3 text-right font-bold text-indigo-900">
                            {formatCurrency(record.receiptAmt)}
                          </td>
                        </tr>
                        <tr className="bg-slate-50 font-bold border-t-2 border-slate-300">
                          <td className="py-3 px-3 font-sans uppercase text-[11px] text-slate-900">
                            Net Outstanding Balance Due
                          </td>
                          <td className={`py-3 px-3 text-right text-sm ${record.balance > 0 ? 'text-rose-600' : 'text-emerald-700'}`}>
                            {formatCurrency(record.balance)}
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Verification Dating Audit Trail */}
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                    Departmental Verification Trail
                  </h4>
                  <div className="grid grid-cols-3 gap-2.5 text-center text-xs">
                    <div className="p-2.5 rounded-lg border border-slate-200 bg-slate-50">
                      <span className="text-[10px] text-slate-400 uppercase block font-semibold">1st Ver Dated</span>
                      <span className="font-mono font-bold text-blue-900">
                        {record.firstVerDate || '—'}
                      </span>
                    </div>
                    <div className="p-2.5 rounded-lg border border-slate-200 bg-slate-50">
                      <span className="text-[10px] text-slate-400 uppercase block font-semibold">2nd Ver Dated</span>
                      <span className="font-mono font-bold text-indigo-900">
                        {record.secondVerDate || '—'}
                      </span>
                    </div>
                    <div className="p-2.5 rounded-lg border border-slate-200 bg-slate-50">
                      <span className="text-[10px] text-slate-400 uppercase block font-semibold">3rd Ver (Final)</span>
                      <span className="font-mono font-bold text-emerald-900">
                        {record.thirdVerDate || (record.verified ? 'Approved' : '—')}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Right Column: QR Code & Security Stamp (1 col) */}
              <div className="space-y-4">
                <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200 text-center flex flex-col items-center">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-2">
                    Official Digital QR Stamp
                  </span>

                  <div className="bg-white p-2.5 rounded-xl shadow-xs border border-slate-200 mb-3">
                    {qrUrl ? (
                      <img
                        src={qrUrl}
                        alt="Verification QR Stamp"
                        className="w-40 h-40 object-contain rounded"
                      />
                    ) : (
                      <div className="w-40 h-40 flex items-center justify-center text-slate-400 text-xs">
                        Generating QR...
                      </div>
                    )}
                  </div>

                  <span className="text-xs font-bold text-slate-800">
                    Scan to Verify Authenticity
                  </span>
                  <span className="text-[10px] text-slate-500 mt-1 max-w-[200px]">
                    Direct cryptographic verification link to Punjab Excise & Taxation records
                  </span>

                  <div className="mt-4 pt-3 border-t border-slate-200 w-full text-left">
                    <span className="text-[9px] uppercase font-bold text-slate-400 block">Digital Token</span>
                    <span className="text-[10px] font-mono text-slate-700 break-all select-all block">
                      {fingerprint}
                    </span>
                  </div>

                  <div className="mt-2 w-full text-left">
                    <span className="text-[9px] uppercase font-bold text-slate-400 block">Payment Date</span>
                    <span className="text-[10px] font-mono text-slate-700 block">
                      {record.date || 'Pending'}
                    </span>
                  </div>

                  <div className="mt-2 w-full text-left">
                    <span className="text-[9px] uppercase font-bold text-slate-400 block">Challan Ref</span>
                    <span className="text-[10px] font-mono text-slate-700 block">
                      {record.challanNo || `CH-${record.id}`}
                    </span>
                  </div>
                </div>

                {/* Government Security Disclaimer */}
                <div className="p-3 bg-amber-50/80 rounded-xl border border-amber-200 text-[11px] text-amber-900 space-y-1">
                  <div className="font-bold flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-amber-700" />
                    <span>Legal Notice:</span>
                  </div>
                  <p className="text-[10px] text-amber-800 leading-relaxed">
                    This document is an electronic certificate issued under the Punjab Urban Immoveable Property Tax Act. Verification is valid as of {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })}.
                  </p>
                </div>
              </div>
            </div>

            {/* Official Certification Signature Block */}
            <div className="pt-8 border-t border-slate-200 grid grid-cols-1 sm:grid-cols-3 gap-6 text-center text-xs text-slate-600">
              <div>
                <div className="border-t border-slate-300 pt-2 font-semibold text-slate-800">
                  Field Auditor / Excise Inspector
                </div>
                <div className="text-[10px] text-slate-400 font-mono">Circle {record.circle}</div>
              </div>
              <div>
                <div className="border-t border-slate-300 pt-2 font-semibold text-slate-800">
                  Accounts & Verification Branch
                </div>
                <div className="text-[10px] text-slate-400 font-mono">Special Audit Directorate</div>
              </div>
              <div>
                <div className="border-t border-slate-300 pt-2 font-semibold text-slate-800">
                  Director / Assessing Authority
                </div>
                <div className="text-[10px] text-slate-400 font-mono">Rawalpindi Division</div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="no-print mt-auto border-t border-slate-200 bg-white py-4 px-6 text-center text-xs text-slate-500">
        <span>AppSheet Audit Engine</span> · Property Tax & Recovery Tracker · Government of Punjab
      </footer>
    </div>
  );
};
