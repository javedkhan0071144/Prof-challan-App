import React, { useState, useMemo } from 'react';
import { AuditRecord } from '../types';
import { formatCurrency } from '../utils/formatters';
import { Printer, X, Download, ShieldCheck, Filter } from 'lucide-react';

interface AuditReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  records: AuditRecord[];
  onExportCSV: () => void;
  initialParaNo?: string;
}

export const AuditReportModal: React.FC<AuditReportModalProps> = ({
  isOpen,
  onClose,
  records,
  onExportCSV,
  initialParaNo = 'all',
}) => {
  const [selectedPara, setSelectedPara] = useState<string>(initialParaNo);

  // Sync initialParaNo
  React.useEffect(() => {
    if (initialParaNo) setSelectedPara(initialParaNo);
  }, [initialParaNo, isOpen]);

  const uniqueParas = useMemo(() => {
    const set = new Set<string>();
    records.forEach(r => {
      if (r.paraNo) set.add(r.paraNo);
    });
    return Array.from(set).sort();
  }, [records]);

  const displayedRecords = useMemo(() => {
    if (selectedPara === 'all') return records;
    return records.filter(r => (r.paraNo || 'Para-General') === selectedPara);
  }, [records, selectedPara]);

  if (!isOpen) return null;

  const totalAudit = displayedRecords.reduce((acc, r) => acc + (r.auditAmt || 0), 0);
  const totalRecovered = displayedRecords.reduce((acc, r) => acc + (r.recovered || 0), 0);
  const totalPrior = displayedRecords.reduce((acc, r) => acc + (r.priorAudit || 0), 0);
  const totalNotDue = displayedRecords.reduce((acc, r) => acc + (r.notDue || 0), 0);
  const totalReceipts = displayedRecords.reduce((acc, r) => acc + (r.receiptAmt || 0), 0);
  const totalBalance = displayedRecords.reduce((acc, r) => acc + (r.balance || 0), 0);
  const verifiedCount = displayedRecords.filter(r => r.verified).length;

  const handlePrint = () => {
    window.print();
  };

  const currentParaDetails = selectedPara !== 'all' 
    ? (displayedRecords[0]?.details || selectedPara)
    : `Consolidated Portfolio (${uniqueParas.length} Paras)`;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-5xl w-full max-h-[95vh] flex flex-col overflow-hidden border border-slate-200">
        {/* Modal Controls Bar (Hidden during print) */}
        <div className="no-print p-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 bg-slate-50 shrink-0">
          <div className="flex items-center gap-3">
            <span className="text-sm font-bold text-slate-800">
              Official Property Tax Audit Reconciliation Report
            </span>
            <span className="text-xs text-slate-500 font-mono">({displayedRecords.length} Records)</span>
          </div>

          <div className="flex items-center gap-2">
            {/* Para filter dropdown */}
            <div className="flex items-center gap-1.5 bg-white border border-slate-300 rounded-lg px-2.5 py-1 text-xs">
              <Filter className="w-3.5 h-3.5 text-slate-400" />
              <select
                value={selectedPara}
                onChange={(e) => setSelectedPara(e.target.value)}
                className="bg-transparent text-slate-700 font-medium focus:outline-none cursor-pointer"
              >
                <option value="all">All Paras (Consolidated)</option>
                {uniqueParas.map((p) => (
                  <option key={p} value={p}>
                    {p} Annexure
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={handlePrint}
              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs transition"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Document</span>
            </button>
            <button
              onClick={onExportCSV}
              className="px-3 py-1.5 bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 rounded-lg text-xs font-medium flex items-center gap-1.5 transition"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Document View */}
        <div className="flex-1 overflow-y-auto p-6 sm:p-8 space-y-6 text-slate-900 bg-white">
          {/* Header */}
          <div className="text-center border-b-2 border-slate-900 pb-4 space-y-1">
            <h1 className="text-xl sm:text-2xl font-black uppercase tracking-wider text-slate-900">
              Excise, Taxation & Narcotics Control Department
            </h1>
            <h2 className="text-sm sm:text-base font-semibold text-slate-700">
              Property Tax Special Audit & Recovery Reconciliation Sheet
            </h2>
            <div className="flex flex-wrap items-center justify-center gap-3 text-xs text-slate-500 pt-1 font-mono">
              <span>District: Rawalpindi Division (RWP)</span>
              <span>·</span>
              <span className="font-bold text-slate-800">
                Audit Scope: {selectedPara === 'all' ? 'All Paras' : selectedPara} ({currentParaDetails})
              </span>
              <span>·</span>
              <span>Date Generated: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</span>
            </div>
          </div>

          {/* Key Executive Summary Box */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 bg-slate-50 border border-slate-300 rounded-lg text-xs">
            <div>
              <span className="text-slate-500 uppercase tracking-wider font-semibold block text-[10px]">
                Total Audit Assessment
              </span>
              <span className="text-base font-bold font-mono text-slate-900">
                {formatCurrency(totalAudit)}
              </span>
            </div>
            <div>
              <span className="text-slate-500 uppercase tracking-wider font-semibold block text-[10px]">
                Total Recovered Amount
              </span>
              <span className="text-base font-bold font-mono text-emerald-700">
                {formatCurrency(totalRecovered)}
              </span>
            </div>
            <div>
              <span className="text-slate-500 uppercase tracking-wider font-semibold block text-[10px]">
                Total Deductions (Prior + Not Due)
              </span>
              <span className="text-base font-bold font-mono text-slate-700">
                {formatCurrency(totalPrior + totalNotDue)}
              </span>
            </div>
            <div>
              <span className="text-slate-500 uppercase tracking-wider font-semibold block text-[10px]">
                Net Outstanding Due
              </span>
              <span className={`text-base font-bold font-mono ${totalBalance > 0 ? 'text-rose-600' : 'text-slate-900'}`}>
                {formatCurrency(totalBalance)}
              </span>
            </div>
          </div>

          {/* Formal Audit Table */}
          <div className="border border-slate-300 rounded-lg overflow-hidden">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-slate-100 border-b border-slate-300 text-slate-700 font-bold uppercase text-[10px]">
                <tr>
                  <th className="py-2 px-2.5 border-r border-slate-300">Sr#</th>
                  <th className="py-2 px-2.5 border-r border-slate-300">Para No</th>
                  <th className="py-2 px-2.5 border-r border-slate-300">Para Name</th>
                  <th className="py-2 px-2.5 border-r border-slate-300">Tehsil / Circle</th>
                  <th className="py-2 px-2.5 border-r border-slate-300">Property No</th>
                  <th className="py-2 px-2.5 border-r border-slate-300">Owner</th>
                  <th className="py-2 px-2.5 border-r border-slate-300 text-right">Audit Amt (Rs.)</th>
                  <th className="py-2 px-2.5 border-r border-slate-300 text-right">Recovered (Rs.)</th>
                  <th className="py-2 px-2.5 border-r border-slate-300 text-right">Prior to Audit</th>
                  <th className="py-2 px-2.5 border-r border-slate-300 text-right">Not Due Amount</th>
                  <th className="py-2 px-2.5 border-r border-slate-300 text-right">Receipt Amt</th>
                  <th className="py-2 px-2.5 border-r border-slate-300 text-right">Balance Due</th>
                  <th className="py-2 px-2.5 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {displayedRecords.map((r, i) => (
                  <tr key={r.id} className={i % 2 === 1 ? 'bg-slate-50/50' : 'bg-white'}>
                    <td className="py-1.5 px-2.5 font-mono text-center border-r border-slate-200">{r.id}</td>
                    <td className="py-1.5 px-2.5 font-mono font-semibold text-slate-800 border-r border-slate-200">{r.paraNo || 'Para-6'}</td>
                    <td className="py-1.5 px-2.5 border-r border-slate-200">{r.details || '6-Petrol Pump'}</td>
                    <td className="py-1.5 px-2.5 border-r border-slate-200">{r.tehsil} - {r.circle}</td>
                    <td className="py-1.5 px-2.5 font-semibold text-slate-900 font-mono border-r border-slate-200">{r.propertyNo}</td>
                    <td className="py-1.5 px-2.5 border-r border-slate-200">{r.owner}</td>
                    <td className="py-1.5 px-2.5 text-right font-mono border-r border-slate-200">{formatCurrency(r.auditAmt)}</td>
                    <td className="py-1.5 px-2.5 text-right font-mono text-emerald-700 border-r border-slate-200">{formatCurrency(r.recovered)}</td>
                    <td className="py-1.5 px-2.5 text-right font-mono text-slate-600 border-r border-slate-200">
                      {formatCurrency(r.priorAudit || 0)}
                    </td>
                    <td className="py-1.5 px-2.5 text-right font-mono text-slate-600 border-r border-slate-200">
                      {formatCurrency(r.notDue || 0)}
                    </td>
                    <td className="py-1.5 px-2.5 text-right font-mono border-r border-slate-200">{formatCurrency(r.receiptAmt)}</td>
                    <td className={`py-1.5 px-2.5 text-right font-mono font-bold border-r border-slate-200 ${r.balance > 0 ? 'text-rose-600' : 'text-slate-800'}`}>
                      {formatCurrency(r.balance)}
                    </td>
                    <td className="py-1.5 px-2.5 text-center text-[10px] font-mono whitespace-nowrap">
                      {(() => {
                        const stage = r.verificationStage || (r.verified ? '3rd' : 'pending');
                        if (stage === '3rd') return <span className="text-emerald-800 font-bold">3rd Ver ({r.thirdVerDate || 'Endorsed'})</span>;
                        if (stage === '2nd') return <span className="text-indigo-800 font-bold">2nd Ver ({r.secondVerDate || 'Checked'})</span>;
                        if (stage === '1st') return <span className="text-blue-800 font-bold">1st Ver ({r.firstVerDate || 'Inspected'})</span>;
                        return <span className="text-slate-400">PENDING</span>;
                      })()}
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="bg-slate-100 font-bold border-t-2 border-slate-900">
                <tr>
                  <td colSpan={6} className="py-2 px-2.5 text-right uppercase text-[11px] border-r border-slate-300">
                    Grand Total
                  </td>
                  <td className="py-2 px-2.5 text-right font-mono border-r border-slate-300">{formatCurrency(totalAudit)}</td>
                  <td className="py-2 px-2.5 text-right font-mono text-emerald-700 border-r border-slate-300">{formatCurrency(totalRecovered)}</td>
                  <td className="py-2 px-2.5 text-right font-mono text-slate-700 border-r border-slate-300">
                    {formatCurrency(totalPrior)}
                  </td>
                  <td className="py-2 px-2.5 text-right font-mono text-slate-700 border-r border-slate-300">
                    {formatCurrency(totalNotDue)}
                  </td>
                  <td className="py-2 px-2.5 text-right font-mono border-r border-slate-300">{formatCurrency(totalReceipts)}</td>
                  <td className={`py-2 px-2.5 text-right font-mono ${totalBalance > 0 ? 'text-rose-600' : 'text-slate-900'} border-r border-slate-300`}>
                    {formatCurrency(totalBalance)}
                  </td>
                  <td className="py-2 px-2.5 text-center text-[10px]">
                    {verifiedCount}/{displayedRecords.length} Verified
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Official Signatures Block */}
          <div className="pt-10 grid grid-cols-3 gap-6 text-center text-xs text-slate-600">
            <div>
              <div className="border-t border-slate-400 pt-2 font-semibold">Prepared By</div>
              <div className="text-[11px] text-slate-500">Excise Inspector / Field Auditor</div>
            </div>
            <div>
              <div className="border-t border-slate-400 pt-2 font-semibold">Cross-Checked By</div>
              <div className="text-[11px] text-slate-500">Circle Revenue Officer</div>
            </div>
            <div>
              <div className="border-t border-slate-400 pt-2 font-semibold">Approved By</div>
              <div className="text-[11px] text-slate-500">Director / Assessment Officer</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
