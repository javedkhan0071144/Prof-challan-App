import React, { useState, useMemo } from 'react';
import { AuditRecord } from '../types';
import { formatCurrency, exportAccountsOfficeReportToCSV } from '../utils/formatters';
import { Printer, X, Download, ShieldCheck, CheckCircle2, Clock, Filter, Search } from 'lucide-react';

interface AccountsOfficeReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  records: AuditRecord[];
}

export const AccountsOfficeReportModal: React.FC<AccountsOfficeReportModalProps> = ({
  isOpen,
  onClose,
  records,
}) => {
  const [stageFilter, setStageFilter] = useState<'all' | 'pending' | '1st' | '2nd' | '3rd'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPara, setSelectedPara] = useState<string>('all');

  // Unique paras
  const uniqueParas = useMemo(() => {
    const paras = new Set<string>();
    records.forEach(r => {
      if (r.paraNo) paras.add(r.paraNo);
    });
    return Array.from(paras);
  }, [records]);

  // Filtered dataset
  const displayedRecords = useMemo(() => {
    return records.filter(r => {
      // Stage filter
      const stage = r.verificationStage || (r.verified ? '3rd' : 'pending');
      if (stageFilter !== 'all' && stage !== stageFilter) return false;

      // Para filter
      if (selectedPara !== 'all' && r.paraNo !== selectedPara) return false;

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const match =
          r.propertyNo.toLowerCase().includes(q) ||
          r.owner.toLowerCase().includes(q) ||
          r.id.toString().includes(q) ||
          (r.challanNo && r.challanNo.toLowerCase().includes(q)) ||
          (r.details && r.details.toLowerCase().includes(q)) ||
          (r.circle && r.circle.toLowerCase().includes(q));
        if (!match) return false;
      }

      return true;
    });
  }, [records, stageFilter, selectedPara, searchQuery]);

  if (!isOpen) return null;

  const totalAudit = displayedRecords.reduce((acc, r) => acc + (r.auditAmt || 0), 0);
  const totalReceipts = displayedRecords.reduce((acc, r) => acc + (r.receiptAmt || 0), 0);
  const totalRecovered = displayedRecords.reduce((acc, r) => acc + (r.recovered || 0), 0);
  const totalPrior = displayedRecords.reduce((acc, r) => acc + (r.priorAudit || 0), 0);
  const totalNotDue = displayedRecords.reduce((acc, r) => acc + (r.notDue || 0), 0);
  const totalBalance = displayedRecords.reduce((acc, r) => acc + (r.balance || 0), 0);

  const thirdCount = displayedRecords.filter(r => (r.verificationStage || (r.verified ? '3rd' : 'pending')) === '3rd').length;
  const secondCount = displayedRecords.filter(r => r.verificationStage === '2nd').length;
  const firstCount = displayedRecords.filter(r => r.verificationStage === '1st').length;
  const pendingCount = displayedRecords.filter(r => (!r.verificationStage || r.verificationStage === 'pending') && !r.verified).length;

  const handlePrint = () => {
    window.print();
  };

  const handleExportCSV = () => {
    exportAccountsOfficeReportToCSV(displayedRecords, 'Accounts_Office_Verification_Report.csv');
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-6xl w-full max-h-[96vh] flex flex-col overflow-hidden border border-slate-200">
        {/* Modal Controls Bar (Hidden during print) */}
        <div className="no-print p-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 bg-slate-50 shrink-0">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-sm font-bold text-slate-800">
              Accounts Office Verification Report (Treasury & Receipt Reconciliation)
            </span>
            <span className="text-xs text-slate-500 font-mono">
              ({displayedRecords.length} of {records.length} Records)
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs transition cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Official Report</span>
            </button>
            <button
              onClick={handleExportCSV}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs transition cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Accounts CSV</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Filter Bar (Hidden during print) */}
        <div className="no-print px-4 py-2.5 bg-slate-100 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 shrink-0 text-xs">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-slate-500 font-medium flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" /> Stage:
            </span>
            {(['all', 'pending', '1st', '2nd', '3rd'] as const).map(stg => (
              <button
                key={stg}
                onClick={() => setStageFilter(stg)}
                className={`px-2.5 py-1 rounded-md text-xs font-medium transition cursor-pointer ${
                  stageFilter === stg
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'bg-white text-slate-600 hover:bg-slate-200 border border-slate-200'
                }`}
              >
                {stg === 'all' && 'All Stages'}
                {stg === 'pending' && `Pending (${pendingCount})`}
                {stg === '1st' && `1st Ver (${firstCount})`}
                {stg === '2nd' && `2nd Ver (${secondCount})`}
                {stg === '3rd' && `3rd Ver Final (${thirdCount})`}
              </button>
            ))}

            {uniqueParas.length > 0 && (
              <select
                value={selectedPara}
                onChange={e => setSelectedPara(e.target.value)}
                className="bg-white border border-slate-200 rounded-md px-2.5 py-1 text-xs text-slate-700 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              >
                <option value="all">All Audit Paras</option>
                {uniqueParas.map(p => (
                  <option key={p} value={p}>{p}</option>
                ))}
              </select>
            )}
          </div>

          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search Property, Owner, Challan..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="bg-white pl-8 pr-3 py-1 rounded-md border border-slate-200 text-xs text-slate-800 placeholder-slate-400 w-56 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>
        </div>

        {/* Printable Document View */}
        <div className="flex-1 overflow-y-auto p-6 sm:p-8 space-y-6 text-slate-900 bg-white">
          {/* Header */}
          <div className="text-center border-b-2 border-slate-900 pb-4 space-y-1.5">
            <div className="flex items-center justify-center gap-2 mb-1">
              <span className="text-[11px] font-bold tracking-widest uppercase bg-slate-900 text-white px-2.5 py-0.5 rounded">
                Official Treasury & Audit Schedule
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black uppercase tracking-wider text-slate-900">
              Government of Punjab · Excise, Taxation & Narcotics Control Department
            </h1>
            <h2 className="text-sm sm:text-base font-bold text-indigo-900">
              Accounts Office Verification Report (Receipts, Payment Dates & Balance Reconciliation)
            </h2>
            <div className="flex flex-wrap items-center justify-center gap-4 text-xs text-slate-600 pt-1 font-mono">
              <span>District: Rawalpindi Division (RWP)</span>
              <span>·</span>
              <span>Major Head: C02801 - Property Tax</span>
              <span>·</span>
              <span>Report Generated: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</span>
            </div>
          </div>

          {/* Accounts Office Summary Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 p-4 bg-slate-50 border border-slate-300 rounded-lg text-xs">
            <div>
              <span className="text-slate-500 uppercase tracking-wider font-semibold block text-[10px]">
                Audit Assessed Total
              </span>
              <span className="text-base font-bold font-mono text-slate-900">
                {formatCurrency(totalAudit)}
              </span>
              <span className="text-[10px] text-slate-400 block mt-0.5">{displayedRecords.length} units audited</span>
            </div>
            <div className="bg-indigo-50/60 -m-1 p-2 rounded border border-indigo-200">
              <span className="text-indigo-800 uppercase tracking-wider font-bold block text-[10px]">
                Receipt Amount (Verified)
              </span>
              <span className="text-base font-bold font-mono text-indigo-700">
                {formatCurrency(totalReceipts)}
              </span>
              <span className="text-[10px] text-indigo-600 block mt-0.5">Presented to Treasury</span>
            </div>
            <div>
              <span className="text-slate-500 uppercase tracking-wider font-semibold block text-[10px]">
                Total Recovered
              </span>
              <span className="text-base font-bold font-mono text-emerald-700">
                {formatCurrency(totalRecovered)}
              </span>
              <span className="text-[10px] text-emerald-600 block mt-0.5">Credited to Govt.</span>
            </div>
            <div>
              <span className="text-slate-500 uppercase tracking-wider font-semibold block text-[10px]">
                Prior / Not Due
              </span>
              <span className="text-base font-bold font-mono text-slate-700">
                {formatCurrency(totalPrior + totalNotDue)}
              </span>
              <span className="text-[10px] text-slate-400 block mt-0.5">Prior: {formatCurrency(totalPrior)}</span>
            </div>
            <div className="bg-rose-50/60 -m-1 p-2 rounded border border-rose-200">
              <span className="text-rose-800 uppercase tracking-wider font-bold block text-[10px]">
                Net Balance Due
              </span>
              <span className={`text-base font-bold font-mono ${totalBalance > 0 ? 'text-rose-600' : 'text-emerald-700'}`}>
                {formatCurrency(totalBalance)}
              </span>
              <span className="text-[10px] text-rose-500 block mt-0.5">Outstanding Demand</span>
            </div>
          </div>

          {/* Accounts Office Detailed Verification Table */}
          <div className="border border-slate-300 rounded-lg overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-slate-100 border-b-2 border-slate-300 text-slate-800 font-bold uppercase text-[10px]">
                <tr>
                  <th className="py-2 px-2 border-r border-slate-300 text-center w-8">Sr#</th>
                  <th className="py-2 px-2 border-r border-slate-300 whitespace-nowrap">Audit Para No</th>
                  <th className="py-2 px-2 border-r border-slate-300 whitespace-nowrap">Para Name</th>
                  <th className="py-2 px-2 border-r border-slate-300 whitespace-nowrap">Tehsil/Circle</th>
                  <th className="py-2 px-2 border-r border-slate-300 whitespace-nowrap">Property No</th>
                  <th className="py-2 px-2 border-r border-slate-300 whitespace-nowrap">Owner/Taxpayer</th>
                  <th className="py-2 px-2 border-r border-slate-300 whitespace-nowrap">Challan Ref</th>
                  <th className="py-2 px-2 border-r border-slate-300 whitespace-nowrap bg-blue-50/50">Payment Date</th>
                  <th className="py-2 px-2 border-r border-slate-300 text-right whitespace-nowrap">Audit Amt (Rs.)</th>
                  <th className="py-2 px-2 border-r border-slate-300 text-right whitespace-nowrap bg-indigo-50/70 font-black text-indigo-900">
                    Receipt Amount (Rs.)
                  </th>
                  <th className="py-2 px-2 border-r border-slate-300 text-right whitespace-nowrap">Recovered (Rs.)</th>
                  <th className="py-2 px-2 border-r border-slate-300 text-right whitespace-nowrap">Prior / Not Due</th>
                  <th className="py-2 px-2 border-r border-slate-300 text-right whitespace-nowrap bg-rose-50/70 font-black text-rose-900">
                    Balance Due (Rs.)
                  </th>
                  <th className="py-2 px-2 border-r border-slate-300 text-center whitespace-nowrap">1st Ver Dated</th>
                  <th className="py-2 px-2 border-r border-slate-300 text-center whitespace-nowrap">2nd Ver Dated</th>
                  <th className="py-2 px-2 border-r border-slate-300 text-center whitespace-nowrap">3rd Ver Dated</th>
                  <th className="py-2 px-2 text-center whitespace-nowrap">Accounts Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {displayedRecords.length === 0 ? (
                  <tr>
                    <td colSpan={17} className="py-8 text-center text-slate-500">
                      No records match the selected Accounts Office filter criteria.
                    </td>
                  </tr>
                ) : (
                  displayedRecords.map((r, i) => {
                    const stage = r.verificationStage || (r.verified ? '3rd' : 'pending');
                    return (
                      <tr key={r.id} className={i % 2 === 1 ? 'bg-slate-50/60' : 'bg-white'}>
                        <td className="py-1.5 px-2 font-mono text-center border-r border-slate-200">{r.id}</td>
                        <td className="py-1.5 px-2 font-mono font-semibold text-indigo-900 border-r border-slate-200 whitespace-nowrap">
                          {r.paraNo || 'Para-6'}
                        </td>
                        <td className="py-1.5 px-2 border-r border-slate-200 whitespace-nowrap text-slate-700">
                          {r.details || '6-Petrol Pump'}
                        </td>
                        <td className="py-1.5 px-2 border-r border-slate-200 whitespace-nowrap">
                          <span className="font-medium text-slate-800">{r.tehsil}</span>
                          <span className="text-slate-400 mx-0.5">/</span>
                          <span className="text-slate-500">{r.circle}</span>
                        </td>
                        <td className="py-1.5 px-2 font-semibold text-slate-900 font-mono border-r border-slate-200 whitespace-nowrap">
                          {r.propertyNo}
                        </td>
                        <td className="py-1.5 px-2 border-r border-slate-200 whitespace-nowrap text-slate-800">
                          {r.owner}
                        </td>
                        <td className="py-1.5 px-2 font-mono text-slate-600 border-r border-slate-200 whitespace-nowrap">
                          {r.challanNo || `CH-${r.id}`}
                        </td>
                        {/* Payment Date column explicitly requested */}
                        <td className="py-1.5 px-2 font-mono text-slate-800 border-r border-slate-200 whitespace-nowrap bg-blue-50/30">
                          {r.date ? (
                            <span className="font-semibold text-slate-900">{r.date}</span>
                          ) : (
                            <span className="text-slate-400 italic">Unpaid</span>
                          )}
                        </td>
                        <td className="py-1.5 px-2 text-right font-mono border-r border-slate-200 tabular-nums">
                          {formatCurrency(r.auditAmt)}
                        </td>
                        {/* Receipt Amount column explicitly requested */}
                        <td className="py-1.5 px-2 text-right font-mono font-bold text-indigo-900 border-r border-slate-200 bg-indigo-50/50 tabular-nums">
                          {formatCurrency(r.receiptAmt)}
                        </td>
                        <td className="py-1.5 px-2 text-right font-mono text-emerald-700 border-r border-slate-200 tabular-nums">
                          {formatCurrency(r.recovered)}
                        </td>
                        <td className="py-1.5 px-2 text-right font-mono text-slate-600 border-r border-slate-200 tabular-nums">
                          {(r.priorAudit || 0) + (r.notDue || 0) > 0 ? (
                            <span>{formatCurrency((r.priorAudit || 0) + (r.notDue || 0))}</span>
                          ) : (
                            <span className="text-slate-300">—</span>
                          )}
                        </td>
                        {/* Balance column explicitly requested */}
                        <td className={`py-1.5 px-2 text-right font-mono font-bold border-r border-slate-200 bg-rose-50/30 tabular-nums ${
                          r.balance > 0 ? 'text-rose-600' : 'text-slate-800'
                        }`}>
                          {formatCurrency(r.balance)}
                        </td>
                        {/* 1st Ver Dated */}
                        <td className="py-1.5 px-2 font-mono text-center border-r border-slate-200 whitespace-nowrap">
                          {r.firstVerDate ? (
                            <span className="text-blue-800 font-semibold">{r.firstVerDate}</span>
                          ) : (
                            <span className="text-slate-300">—</span>
                          )}
                        </td>
                        {/* 2nd Ver Dated */}
                        <td className="py-1.5 px-2 font-mono text-center border-r border-slate-200 whitespace-nowrap">
                          {r.secondVerDate ? (
                            <span className="text-indigo-800 font-semibold">{r.secondVerDate}</span>
                          ) : (
                            <span className="text-slate-300">—</span>
                          )}
                        </td>
                        {/* 3rd Ver Dated */}
                        <td className="py-1.5 px-2 font-mono text-center border-r border-slate-200 whitespace-nowrap">
                          {r.thirdVerDate ? (
                            <span className="text-emerald-800 font-semibold">{r.thirdVerDate}</span>
                          ) : (
                            <span className="text-slate-300">—</span>
                          )}
                        </td>
                        {/* Accounts Office Status */}
                        <td className="py-1.5 px-2 text-center whitespace-nowrap text-[10px]">
                          {stage === '3rd' && (
                            <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold">
                              <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                              Reconciled
                            </span>
                          )}
                          {stage === '2nd' && (
                            <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-indigo-100 text-indigo-800 font-semibold">
                              2nd Stage
                            </span>
                          )}
                          {stage === '1st' && (
                            <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-blue-100 text-blue-800 font-semibold">
                              1st Stage
                            </span>
                          )}
                          {stage === 'pending' && (
                            <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 font-medium">
                              <Clock className="w-3 h-3 text-amber-600" />
                              Pending Scroll
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
              <tfoot className="bg-slate-100 font-bold border-t-2 border-slate-900">
                <tr>
                  <td colSpan={8} className="py-2.5 px-2 text-right uppercase text-[11px] border-r border-slate-300">
                    Accounts Office Grand Total ({displayedRecords.length} Items):
                  </td>
                  <td className="py-2.5 px-2 text-right font-mono border-r border-slate-300">{formatCurrency(totalAudit)}</td>
                  <td className="py-2.5 px-2 text-right font-mono text-indigo-900 border-r border-slate-300 bg-indigo-50/70">
                    {formatCurrency(totalReceipts)}
                  </td>
                  <td className="py-2.5 px-2 text-right font-mono text-emerald-700 border-r border-slate-300">{formatCurrency(totalRecovered)}</td>
                  <td className="py-2.5 px-2 text-right font-mono text-slate-700 border-r border-slate-300">
                    {formatCurrency(totalPrior + totalNotDue)}
                  </td>
                  <td className={`py-2.5 px-2 text-right font-mono border-r border-slate-300 bg-rose-50/70 ${totalBalance > 0 ? 'text-rose-600' : 'text-slate-900'}`}>
                    {formatCurrency(totalBalance)}
                  </td>
                  <td colSpan={3} className="py-2.5 px-2 text-center text-[10px] border-r border-slate-300">
                    {thirdCount} Final Reconciled · {pendingCount} Pending
                  </td>
                  <td className="py-2.5 px-2 text-center text-[10px] text-emerald-800 font-bold">
                    Official DAO Certified
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Official Accounts Office Attestation & Signatures Block */}
          <div className="pt-8 border-t border-slate-300 space-y-4">
            <div className="p-3 bg-slate-50 border border-slate-300 rounded text-xs text-slate-700 italic">
              <strong>Accounts Verification Certificate:</strong> Certified that the Receipt Amounts and Payment Dates listed in this report have been scrutinized against the Treasury Cash Book, Bank Scrolls, and Revenue Receipt Vouchers. The remaining Balance amounts represent confirmed outstanding audit recoverable liabilities.
            </div>

            <div className="pt-6 grid grid-cols-1 sm:grid-cols-3 gap-6 text-center text-xs text-slate-700">
              <div className="space-y-1">
                <div className="border-t border-slate-400 pt-2 font-bold">
                  Dealing Assistant (Treasury & Scroll)
                </div>
                <div className="text-[11px] text-slate-500 font-mono">Receipts Matched with Bank Scroll</div>
              </div>
              <div className="space-y-1">
                <div className="border-t border-slate-400 pt-2 font-bold">
                  Assistant Accounts Officer / Senior Auditor
                </div>
                <div className="text-[11px] text-slate-500 font-mono">Special Audit Branch (Excise & Taxation)</div>
              </div>
              <div className="space-y-1">
                <div className="border-t border-slate-400 pt-2 font-bold">
                  District Accounts Officer (DAO) / Treasury Officer
                </div>
                <div className="text-[11px] text-slate-500 font-mono">With Official Seal, Stamp & Date</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
