import React, { useState } from 'react';
import { AuditRecord, SortField, SortOrder, VerificationStage } from '../types';
import { formatCurrency, calculateBalance } from '../utils/formatters';
import {
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  Edit2,
  Copy,
  Trash2,
  Receipt,
  CheckCircle2,
  Clock,
  Plus,
  QrCode,
  Check,
  X,
  Edit3,
  Download,
  Calendar,
  MessageSquare,
  Sparkles,
  ChevronDown
} from 'lucide-react';

interface AuditTableProps {
  records: AuditRecord[];
  sortField: SortField;
  sortOrder: SortOrder;
  onSort: (field: SortField) => void;
  selectedIds: number[];
  onToggleSelect: (id: number) => void;
  onToggleSelectAll: () => void;
  onEdit: (record: AuditRecord) => void;
  onDuplicate: (record: AuditRecord) => void;
  onDelete: (id: number) => void;
  onToggleVerified: (record: AuditRecord) => void;
  onViewVoucher: (record: AuditRecord) => void;
  onShowQRCode: (record: AuditRecord) => void;
  onOpenAddModal: () => void;
  onClearFilters: () => void;
  isFiltered: boolean;
  onUpdateRecordField?: (id: number, updates: Partial<AuditRecord>) => void;
  onExportSelected?: () => void;
}

export const AuditTable: React.FC<AuditTableProps> = ({
  records,
  sortField,
  sortOrder,
  onSort,
  selectedIds,
  onToggleSelect,
  onToggleSelectAll,
  onEdit,
  onDuplicate,
  onDelete,
  onToggleVerified,
  onViewVoucher,
  onShowQRCode,
  onOpenAddModal,
  onClearFilters,
  isFiltered,
  onUpdateRecordField,
  onExportSelected,
}) => {
  const allSelected = records.length > 0 && selectedIds.length === records.length;
  const isPartiallySelected = selectedIds.length > 0 && selectedIds.length < records.length;

  // In-cell quick editing state
  const [isQuickEditMode, setIsQuickEditMode] = useState<boolean>(false);
  const [editingCell, setEditingCell] = useState<{ id: number; field: string } | null>(null);
  const [cellValue, setCellValue] = useState<string>('');
  const [savedRowId, setSavedRowId] = useState<number | null>(null);
  const [stageMenuOpenId, setStageMenuOpenId] = useState<number | null>(null);

  const totalAudit = records.reduce((acc, r) => acc + (r.auditAmt || 0), 0);
  const totalRecovered = records.reduce((acc, r) => acc + (r.recovered || 0), 0);
  const totalPrior = records.reduce((acc, r) => acc + (r.priorAudit || 0), 0);
  const totalNotDue = records.reduce((acc, r) => acc + (r.notDue || 0), 0);
  const totalReceipts = records.reduce((acc, r) => acc + (r.receiptAmt || 0), 0);
  const totalBalance = records.reduce((acc, r) => acc + (r.balance || 0), 0);

  const renderSortIcon = (field: SortField) => {
    if (sortField !== field) {
      return <ArrowUpDown className="w-3 h-3 text-slate-400 group-hover:text-slate-600" />;
    }
    return sortOrder === 'asc' ? (
      <ArrowUp className="w-3 h-3 text-indigo-600" />
    ) : (
      <ArrowDown className="w-3 h-3 text-indigo-600" />
    );
  };

  // Start in-cell edit for single cell
  const handleStartCellEdit = (id: number, field: string, initialVal: any) => {
    setEditingCell({ id, field });
    setCellValue(initialVal !== undefined && initialVal !== null ? String(initialVal) : '');
  };

  // Save in-cell single edit
  const handleSaveCell = (record: AuditRecord) => {
    if (!editingCell || !onUpdateRecordField) {
      setEditingCell(null);
      return;
    }

    const { id, field } = editingCell;
    const updates: Partial<AuditRecord> = {};

    if (
      field === 'auditAmt' ||
      field === 'recovered' ||
      field === 'priorAudit' ||
      field === 'notDue' ||
      field === 'receiptAmt' ||
      field === 'balance' ||
      field === 'auditSrNo'
    ) {
      const numVal = Math.max(0, Number(cellValue) || 0);
      (updates as any)[field] = numVal;
    } else {
      (updates as any)[field] = cellValue.trim();
    }

    onUpdateRecordField(id, updates);
    setSavedRowId(id);
    setTimeout(() => setSavedRowId(null), 1200);
    setEditingCell(null);
  };

  // Direct change handler for Spreadsheet Mode
  const handleDirectFieldChange = (id: number, field: keyof AuditRecord, val: any) => {
    if (!onUpdateRecordField) return;
    onUpdateRecordField(id, { [field]: val });
    setSavedRowId(id);
    setTimeout(() => setSavedRowId(null), 800);
  };

  // Status stage changer helper
  const handleSetStage = (record: AuditRecord, stage: VerificationStage) => {
    if (!onUpdateRecordField) {
      onToggleVerified(record);
      return;
    }
    const today = new Date().toISOString().split('T')[0];
    const updates: Partial<AuditRecord> = {
      verificationStage: stage,
      verified: stage === '3rd',
    };
    if (stage === '1st' && !record.firstVerDate) updates.firstVerDate = today;
    if (stage === '2nd' && !record.secondVerDate) updates.secondVerDate = today;
    if (stage === '3rd' && !record.thirdVerDate) updates.thirdVerDate = today;

    onUpdateRecordField(record.id, updates);
    setStageMenuOpenId(null);
    setSavedRowId(record.id);
    setTimeout(() => setSavedRowId(null), 1000);
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
      {/* Table status header with Top Row Frozen badge and Quick In-Cell Edit Mode toggle */}
      <div className="bg-slate-50/90 px-4 py-2.5 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-2">
          {/* Top Row Frozen Pill */}
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 font-semibold text-[11px] shadow-2xs">
            <span className="w-2 h-2 rounded-full bg-indigo-600 animate-pulse" />
            Top Row Frozen (Headers Pinned)
          </span>

          {/* In-Cell Edit Mode Toggle Button */}
          <button
            type="button"
            onClick={() => setIsQuickEditMode((prev) => !prev)}
            className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full font-semibold text-[11px] transition cursor-pointer shadow-2xs border ${
              isQuickEditMode
                ? 'bg-emerald-600 text-white border-emerald-700 ring-2 ring-emerald-300'
                : 'bg-white hover:bg-slate-100 text-slate-700 border-slate-300'
            }`}
            title="Toggle between compact viewing (click-to-edit) and continuous spreadsheet cell editing"
          >
            <Edit3 className={`w-3.5 h-3.5 ${isQuickEditMode ? 'text-white' : 'text-indigo-600'}`} />
            <span>Quick In-Cell Edit Mode:</span>
            <span className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${isQuickEditMode ? 'bg-emerald-800 text-emerald-100' : 'bg-slate-200 text-slate-700'}`}>
              {isQuickEditMode ? 'ON' : 'OFF'}
            </span>
          </button>

          <span className="text-slate-500 text-[11px] hidden lg:inline">
            {isQuickEditMode
              ? 'Spreadsheet grid active: edit any cell directly with auto-save'
              : 'Click any cell marked ✏️ to update instantly inline'}
          </span>
        </div>

        <div className="flex items-center gap-2 sm:gap-3">
          {selectedIds.length > 0 && onExportSelected && (
            <button
              type="button"
              onClick={onExportSelected}
              className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full font-semibold text-[11px] bg-emerald-600 hover:bg-emerald-700 text-white transition shadow-2xs cursor-pointer animate-fade-in"
              title={`Export only the ${selectedIds.length} selected records to CSV with current verification status and audit calculations`}
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Selected ({selectedIds.length})</span>
            </button>
          )}

          {savedRowId && (
            <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-600 animate-fade-in">
              <Check className="w-3.5 h-3.5" />
              Saved #{savedRowId}
            </span>
          )}
          <div className="text-slate-500 text-[11px] font-mono">
            Showing <strong className="text-slate-800">{records.length}</strong> records
          </div>
        </div>
      </div>

      <div className="overflow-x-auto overflow-y-auto max-h-[calc(100vh-270px)] min-h-[380px] relative">
        <table className="w-full text-left text-sm border-separate border-spacing-0">
          <thead className="sticky top-0 z-20 select-none shadow-xs">
            <tr>
              {/* Checkbox */}
              <th className="py-3 px-3 w-10 text-center sticky top-0 bg-slate-100 z-20 border-b-2 border-slate-300">
                <input
                  type="checkbox"
                  checked={allSelected}
                  ref={(input) => {
                    if (input) input.indeterminate = isPartiallySelected;
                  }}
                  onChange={onToggleSelectAll}
                  className="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500 cursor-pointer"
                  title="Select all rows"
                />
              </th>

              {/* ID */}
              <th
                onClick={() => onSort('id')}
                className="py-3 px-3 cursor-pointer group hover:bg-slate-200 transition whitespace-nowrap sticky top-0 bg-slate-100 z-20 border-b-2 border-slate-300 text-slate-700 font-bold uppercase text-[11px] tracking-wider"
              >
                <div className="flex items-center gap-1">
                  <span>ID</span>
                  {renderSortIcon('id')}
                </div>
              </th>

              {/* Audit Sr. No. (NEW COLUMN) */}
              <th
                onClick={() => onSort('auditSrNo')}
                className="py-3 px-3 cursor-pointer group hover:bg-slate-200 transition whitespace-nowrap sticky top-0 bg-slate-100 z-20 border-b-2 border-slate-300 text-slate-700 font-bold uppercase text-[11px] tracking-wider"
                title="Audit Serial Number (Editable cell)"
              >
                <div className="flex items-center gap-1">
                  <span>Audit Sr. No.</span>
                  <span className="text-[10px] text-indigo-600 font-normal">✏️</span>
                  {renderSortIcon('auditSrNo')}
                </div>
              </th>

              {/* Audit Para No */}
              <th
                onClick={() => onSort('paraNo')}
                className="py-3 px-3 cursor-pointer group hover:bg-slate-200 transition whitespace-nowrap sticky top-0 bg-slate-100 z-20 border-b-2 border-slate-300 text-slate-700 font-bold uppercase text-[11px] tracking-wider"
              >
                <div className="flex items-center gap-1">
                  <span>Audit Para No</span>
                  {renderSortIcon('paraNo')}
                </div>
              </th>

              {/* Audit Para Name */}
              <th
                onClick={() => onSort('details')}
                className="py-3 px-3 cursor-pointer group hover:bg-slate-200 transition whitespace-nowrap sticky top-0 bg-slate-100 z-20 border-b-2 border-slate-300 text-slate-700 font-bold uppercase text-[11px] tracking-wider"
              >
                <div className="flex items-center gap-1">
                  <span>Audit Para Name</span>
                  {renderSortIcon('details')}
                </div>
              </th>

              {/* Tehsil / Circle */}
              <th
                onClick={() => onSort('tehsil')}
                className="py-3 px-3 cursor-pointer group hover:bg-slate-200 transition whitespace-nowrap sticky top-0 bg-slate-100 z-20 border-b-2 border-slate-300 text-slate-700 font-bold uppercase text-[11px] tracking-wider"
              >
                <div className="flex items-center gap-1">
                  <span>Tehsil / Circle</span>
                  {renderSortIcon('tehsil')}
                </div>
              </th>

              {/* Property No */}
              <th
                onClick={() => onSort('propertyNo')}
                className="py-3 px-3 cursor-pointer group hover:bg-slate-200 transition whitespace-nowrap sticky top-0 bg-slate-100 z-20 border-b-2 border-slate-300 text-slate-700 font-bold uppercase text-[11px] tracking-wider"
              >
                <div className="flex items-center gap-1">
                  <span>Property No</span>
                  {renderSortIcon('propertyNo')}
                </div>
              </th>

              {/* Owner */}
              <th
                onClick={() => onSort('owner')}
                className="py-3 px-3 cursor-pointer group hover:bg-slate-200 transition whitespace-nowrap sticky top-0 bg-slate-100 z-20 border-b-2 border-slate-300 text-slate-700 font-bold uppercase text-[11px] tracking-wider"
              >
                <div className="flex items-center gap-1">
                  <span>Owner</span>
                  {renderSortIcon('owner')}
                </div>
              </th>

              {/* Audit Amt (Editable) */}
              <th
                onClick={() => onSort('auditAmt')}
                className="py-3 px-3 text-right cursor-pointer group hover:bg-slate-200 transition whitespace-nowrap sticky top-0 bg-slate-100 z-20 border-b-2 border-slate-300 text-slate-700 font-bold uppercase text-[11px] tracking-wider"
                title="Assessed Audit Amount (Click cell to edit)"
              >
                <div className="flex items-center justify-end gap-1">
                  <span>Audit Amount</span>
                  <span className="text-[10px] text-indigo-600 font-normal">✏️</span>
                  {renderSortIcon('auditAmt')}
                </div>
              </th>

              {/* Recovered (Editable) */}
              <th
                onClick={() => onSort('recovered')}
                className="py-3 px-3 text-right cursor-pointer group hover:bg-slate-200 transition whitespace-nowrap sticky top-0 bg-slate-100 z-20 border-b-2 border-slate-300 text-slate-700 font-bold uppercase text-[11px] tracking-wider"
                title="Recovered Amount (Click cell to edit)"
              >
                <div className="flex items-center justify-end gap-1">
                  <span>Recovered</span>
                  <span className="text-[10px] text-indigo-600 font-normal">✏️</span>
                  {renderSortIcon('recovered')}
                </div>
              </th>

              {/* Prior to Audit (Editable) */}
              <th
                onClick={() => onSort('priorAudit')}
                className="py-3 px-3 text-right cursor-pointer group hover:bg-slate-200 transition whitespace-nowrap sticky top-0 bg-slate-100 z-20 border-b-2 border-slate-300 text-slate-700 font-bold uppercase text-[11px] tracking-wider"
                title="Prior to Audit Amount (Click cell to edit)"
              >
                <div className="flex items-center justify-end gap-1">
                  <span>Prior to Audit</span>
                  <span className="text-[10px] text-indigo-600 font-normal">✏️</span>
                  {renderSortIcon('priorAudit')}
                </div>
              </th>

              {/* Not Due Amount (Editable) */}
              <th
                onClick={() => onSort('notDue')}
                className="py-3 px-3 text-right cursor-pointer group hover:bg-slate-200 transition whitespace-nowrap sticky top-0 bg-slate-100 z-20 border-b-2 border-slate-300 text-slate-700 font-bold uppercase text-[11px] tracking-wider"
                title="Not Due Amount (Click cell to edit)"
              >
                <div className="flex items-center justify-end gap-1">
                  <span>Not Due Amount</span>
                  <span className="text-[10px] text-indigo-600 font-normal">✏️</span>
                  {renderSortIcon('notDue')}
                </div>
              </th>

              {/* Receipt Amt (Editable) */}
              <th
                onClick={() => onSort('receiptAmt')}
                className="py-3 px-3 text-right cursor-pointer group hover:bg-slate-200 transition whitespace-nowrap sticky top-0 bg-slate-100 z-20 border-b-2 border-slate-300 text-slate-700 font-bold uppercase text-[11px] tracking-wider"
                title="Receipt Amount (Click cell to edit)"
              >
                <div className="flex items-center justify-end gap-1">
                  <span>Receipt Amount</span>
                  <span className="text-[10px] text-indigo-600 font-normal">✏️</span>
                  {renderSortIcon('receiptAmt')}
                </div>
              </th>

              {/* Balance (Editable / Auto) */}
              <th
                onClick={() => onSort('balance')}
                className="py-3 px-3 text-right cursor-pointer group hover:bg-slate-200 transition whitespace-nowrap sticky top-0 bg-slate-100 z-20 border-b-2 border-slate-300 text-slate-700 font-bold uppercase text-[11px] tracking-wider"
                title="Balance Amount (Click cell to edit or auto-calculate)"
              >
                <div className="flex items-center justify-end gap-1">
                  <span>Balance Amount</span>
                  <span className="text-[10px] text-indigo-600 font-normal">✏️</span>
                  {renderSortIcon('balance')}
                </div>
              </th>

              {/* Date Payment (Editable) */}
              <th
                onClick={() => onSort('date')}
                className="py-3 px-3 cursor-pointer group hover:bg-slate-200 transition whitespace-nowrap sticky top-0 bg-slate-100 z-20 border-b-2 border-slate-300 text-slate-700 font-bold uppercase text-[11px] tracking-wider"
                title="Date Payment (Click cell to edit)"
              >
                <div className="flex items-center gap-1">
                  <span>Date Payment</span>
                  <span className="text-[10px] text-indigo-600 font-normal">✏️</span>
                  {renderSortIcon('date')}
                </div>
              </th>

              {/* Status (Editable) */}
              <th
                onClick={() => onSort('verified')}
                className="py-3 px-3 text-center cursor-pointer group hover:bg-slate-200 transition whitespace-nowrap sticky top-0 bg-slate-100 z-20 border-b-2 border-slate-300 text-slate-700 font-bold uppercase text-[11px] tracking-wider"
                title="Accounts Verification Status (Click cell to update stage)"
              >
                <div className="flex items-center justify-center gap-1">
                  <span>Status</span>
                  <span className="text-[10px] text-indigo-600 font-normal">✏️</span>
                  {renderSortIcon('verified')}
                </div>
              </th>

              {/* Remarks at the end (NEW COLUMN & Editable) */}
              <th
                onClick={() => onSort('remarks')}
                className="py-3 px-3 cursor-pointer group hover:bg-slate-200 transition whitespace-nowrap sticky top-0 bg-slate-100 z-20 border-b-2 border-slate-300 text-slate-700 font-bold uppercase text-[11px] tracking-wider"
                title="Auditor Remarks at the end (Click cell to edit)"
              >
                <div className="flex items-center gap-1">
                  <span>Remarks</span>
                  <span className="text-[10px] text-indigo-600 font-normal">✏️</span>
                  {renderSortIcon('remarks')}
                </div>
              </th>

              {/* Actions */}
              <th className="py-3 px-3 text-center whitespace-nowrap sticky top-0 bg-slate-100 z-20 border-b-2 border-slate-300 text-slate-700 font-bold uppercase text-[11px] tracking-wider">
                Actions
              </th>
            </tr>
          </thead>

          <tbody className="divide-y divide-slate-100">
            {records.length === 0 ? (
              <tr>
                <td colSpan={18} className="py-12 text-center text-slate-500">
                  <div className="max-w-sm mx-auto space-y-3">
                    <p className="text-base font-semibold text-slate-800">No matching audit records</p>
                    <p className="text-xs text-slate-500">
                      {isFiltered
                        ? "No records meet the active filter or search criteria."
                        : "No property tax audit records have been loaded yet."}
                    </p>
                    <div className="flex items-center justify-center gap-2 pt-2">
                      {isFiltered && (
                        <button
                          onClick={onClearFilters}
                          className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition"
                        >
                          Clear Filters
                        </button>
                      )}
                      <button
                        onClick={onOpenAddModal}
                        className="px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition flex items-center gap-1.5 shadow-xs"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        Add New Entry
                      </button>
                    </div>
                  </div>
                </td>
              </tr>
            ) : (
              records.map((r) => {
                const isSelected = selectedIds.includes(r.id);
                const isRowSaved = savedRowId === r.id;
                const stage = r.verificationStage || (r.verified ? '3rd' : 'pending');

                return (
                  <tr
                    key={r.id}
                    className={`transition-colors duration-150 ${
                      isRowSaved
                        ? 'bg-emerald-50/70'
                        : isSelected
                        ? 'bg-indigo-50/60 hover:bg-indigo-50'
                        : 'hover:bg-slate-50/80'
                    }`}
                  >
                    {/* Row checkbox */}
                    <td className="py-2.5 px-3 text-center border-b border-slate-100">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => onToggleSelect(r.id)}
                        className="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500 cursor-pointer"
                      />
                    </td>

                    {/* ID */}
                    <td className="py-2.5 px-3 font-mono font-bold text-slate-700 text-xs border-b border-slate-100 whitespace-nowrap">
                      #{r.id}
                    </td>

                    {/* Audit Sr. No. (NEW COLUMN - EDITABLE) */}
                    <td className="py-2.5 px-3 border-b border-slate-100 whitespace-nowrap group/cell">
                      {isQuickEditMode ? (
                        <input
                          type="number"
                          value={r.auditSrNo ?? r.id}
                          onChange={(e) =>
                            handleDirectFieldChange(r.id, 'auditSrNo', Number(e.target.value) || 0)
                          }
                          className="w-16 px-1.5 py-1 text-xs font-mono font-bold text-indigo-900 bg-white border border-indigo-200 rounded focus:ring-2 focus:ring-indigo-400 focus:outline-hidden"
                        />
                      ) : editingCell?.id === r.id && editingCell?.field === 'auditSrNo' ? (
                        <div className="flex items-center gap-1">
                          <input
                            type="number"
                            autoFocus
                            value={cellValue}
                            onChange={(e) => setCellValue(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleSaveCell(r);
                              if (e.key === 'Escape') setEditingCell(null);
                            }}
                            className="w-16 px-1.5 py-0.5 text-xs font-mono font-bold border border-indigo-400 rounded bg-white"
                          />
                          <button
                            onClick={() => handleSaveCell(r)}
                            className="p-1 text-emerald-600 hover:bg-emerald-50 rounded"
                            title="Save"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setEditingCell(null)}
                            className="p-1 text-slate-400 hover:bg-slate-100 rounded"
                            title="Cancel"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <div
                          onClick={() => handleStartCellEdit(r.id, 'auditSrNo', r.auditSrNo ?? r.id)}
                          className="cursor-pointer inline-flex items-center gap-1 px-1.5 py-0.5 rounded hover:bg-indigo-50/80 border border-transparent hover:border-indigo-200 transition"
                          title="Click to edit Audit Sr. No."
                        >
                          <span className="font-mono text-xs font-bold text-indigo-900">
                            {r.auditSrNo ?? r.id}
                          </span>
                          <Edit2 className="w-2.5 h-2.5 text-indigo-400 opacity-0 group-hover/cell:opacity-100 transition" />
                        </div>
                      )}
                    </td>

                    {/* Audit Para No */}
                    <td className="py-2.5 px-3 whitespace-nowrap font-mono text-xs font-semibold text-slate-700 border-b border-slate-100">
                      {r.paraNo || 'Para-6'}
                    </td>

                    {/* Audit Para Name */}
                    <td className="py-2.5 px-3 whitespace-nowrap text-xs text-slate-800 font-medium border-b border-slate-100">
                      {r.details || '6-Petrol Pump'}
                    </td>

                    {/* Tehsil / Circle */}
                    <td className="py-2.5 px-3 whitespace-nowrap border-b border-slate-100">
                      <span className="font-semibold text-slate-800 text-xs">{r.tehsil}</span>
                      <span className="text-slate-400 mx-1">/</span>
                      <span className="text-slate-500 text-xs">{r.circle}</span>
                      <div className="text-[10px] text-slate-400 font-mono">{r.district}</div>
                    </td>

                    {/* Property No with QR code button */}
                    <td className="py-2.5 px-3 border-b border-slate-100">
                      <div className="flex items-center gap-1.5 whitespace-nowrap">
                        <span className="font-semibold text-indigo-700 text-xs font-mono">
                          {r.propertyNo}
                        </span>
                        <button
                          type="button"
                          onClick={() => onShowQRCode(r)}
                          title={`Generate & view verification QR code for ${r.propertyNo}`}
                          className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-mono font-semibold bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200/80 transition cursor-pointer shadow-2xs"
                        >
                          <QrCode className="w-3 h-3 text-indigo-600" />
                          <span>QR</span>
                        </button>
                      </div>
                    </td>

                    {/* Owner */}
                    <td className="py-2.5 px-3 text-slate-800 text-xs border-b border-slate-100">
                      <span className="font-medium">{r.owner}</span>
                    </td>

                    {/* Audit Amount (EDITABLE CELL) */}
                    <td className="py-2.5 px-3 text-right border-b border-slate-100 group/cell">
                      {isQuickEditMode ? (
                        <input
                          type="number"
                          value={r.auditAmt || 0}
                          onChange={(e) =>
                            handleDirectFieldChange(r.id, 'auditAmt', Number(e.target.value) || 0)
                          }
                          className="w-24 px-1.5 py-1 text-right text-xs font-mono font-bold text-slate-800 bg-white border border-slate-300 rounded focus:ring-2 focus:ring-indigo-400 focus:outline-hidden"
                        />
                      ) : editingCell?.id === r.id && editingCell?.field === 'auditAmt' ? (
                        <div className="flex items-center justify-end gap-1">
                          <input
                            type="number"
                            autoFocus
                            value={cellValue}
                            onChange={(e) => setCellValue(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleSaveCell(r);
                              if (e.key === 'Escape') setEditingCell(null);
                            }}
                            className="w-24 px-1.5 py-0.5 text-right text-xs font-mono font-bold border border-indigo-400 rounded bg-white"
                          />
                          <button
                            onClick={() => handleSaveCell(r)}
                            className="p-1 text-emerald-600 hover:bg-emerald-50 rounded"
                            title="Save"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setEditingCell(null)}
                            className="p-1 text-slate-400 hover:bg-slate-100 rounded"
                            title="Cancel"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <div
                          onClick={() => handleStartCellEdit(r.id, 'auditAmt', r.auditAmt)}
                          className="cursor-pointer inline-flex items-center justify-end gap-1 px-1.5 py-0.5 rounded hover:bg-indigo-50/80 border border-transparent hover:border-indigo-200 transition"
                          title="Click to edit Audit Amount"
                        >
                          <span className="font-mono font-medium text-slate-800 text-xs tabular-nums">
                            {formatCurrency(r.auditAmt)}
                          </span>
                          <Edit2 className="w-2.5 h-2.5 text-indigo-400 opacity-0 group-hover/cell:opacity-100 transition" />
                        </div>
                      )}
                    </td>

                    {/* Recovered (EDITABLE CELL) */}
                    <td className="py-2.5 px-3 text-right border-b border-slate-100 group/cell">
                      {isQuickEditMode ? (
                        <input
                          type="number"
                          value={r.recovered || 0}
                          onChange={(e) =>
                            handleDirectFieldChange(r.id, 'recovered', Number(e.target.value) || 0)
                          }
                          className="w-24 px-1.5 py-1 text-right text-xs font-mono font-bold text-emerald-700 bg-white border border-emerald-300 rounded focus:ring-2 focus:ring-emerald-400 focus:outline-hidden"
                        />
                      ) : editingCell?.id === r.id && editingCell?.field === 'recovered' ? (
                        <div className="flex items-center justify-end gap-1">
                          <input
                            type="number"
                            autoFocus
                            value={cellValue}
                            onChange={(e) => setCellValue(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleSaveCell(r);
                              if (e.key === 'Escape') setEditingCell(null);
                            }}
                            className="w-24 px-1.5 py-0.5 text-right text-xs font-mono font-bold border border-emerald-400 rounded bg-white"
                          />
                          <button
                            onClick={() => handleSaveCell(r)}
                            className="p-1 text-emerald-600 hover:bg-emerald-50 rounded"
                            title="Save"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setEditingCell(null)}
                            className="p-1 text-slate-400 hover:bg-slate-100 rounded"
                            title="Cancel"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <div
                          onClick={() => handleStartCellEdit(r.id, 'recovered', r.recovered)}
                          className="cursor-pointer inline-flex items-center justify-end gap-1 px-1.5 py-0.5 rounded hover:bg-emerald-50/80 border border-transparent hover:border-emerald-200 transition"
                          title="Click to edit Recovered Amount"
                        >
                          <span className="font-mono font-medium text-emerald-600 text-xs tabular-nums">
                            {formatCurrency(r.recovered)}
                          </span>
                          <Edit2 className="w-2.5 h-2.5 text-emerald-500 opacity-0 group-hover/cell:opacity-100 transition" />
                        </div>
                      )}
                    </td>

                    {/* Prior to Audit Amount (EDITABLE CELL) */}
                    <td className="py-2.5 px-3 text-right border-b border-slate-100 group/cell">
                      {isQuickEditMode ? (
                        <input
                          type="number"
                          value={r.priorAudit || 0}
                          onChange={(e) =>
                            handleDirectFieldChange(r.id, 'priorAudit', Number(e.target.value) || 0)
                          }
                          className="w-20 px-1.5 py-1 text-right text-xs font-mono text-slate-700 bg-white border border-slate-300 rounded focus:ring-2 focus:ring-indigo-400 focus:outline-hidden"
                        />
                      ) : editingCell?.id === r.id && editingCell?.field === 'priorAudit' ? (
                        <div className="flex items-center justify-end gap-1">
                          <input
                            type="number"
                            autoFocus
                            value={cellValue}
                            onChange={(e) => setCellValue(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleSaveCell(r);
                              if (e.key === 'Escape') setEditingCell(null);
                            }}
                            className="w-20 px-1.5 py-0.5 text-right text-xs font-mono font-bold border border-indigo-400 rounded bg-white"
                          />
                          <button
                            onClick={() => handleSaveCell(r)}
                            className="p-1 text-emerald-600 hover:bg-emerald-50 rounded"
                            title="Save"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setEditingCell(null)}
                            className="p-1 text-slate-400 hover:bg-slate-100 rounded"
                            title="Cancel"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <div
                          onClick={() => handleStartCellEdit(r.id, 'priorAudit', r.priorAudit || 0)}
                          className="cursor-pointer inline-flex items-center justify-end gap-1 px-1.5 py-0.5 rounded hover:bg-indigo-50/80 border border-transparent hover:border-indigo-200 transition"
                          title="Click to edit Prior to Audit Amount"
                        >
                          <span className="font-mono text-xs tabular-nums">
                            {(r.priorAudit || 0) > 0 ? (
                              <span className="font-medium text-slate-700">
                                {formatCurrency(r.priorAudit)}
                              </span>
                            ) : (
                              <span className="text-slate-300 font-sans">—</span>
                            )}
                          </span>
                          <Edit2 className="w-2.5 h-2.5 text-indigo-400 opacity-0 group-hover/cell:opacity-100 transition" />
                        </div>
                      )}
                    </td>

                    {/* Not Due Amount (EDITABLE CELL) */}
                    <td className="py-2.5 px-3 text-right border-b border-slate-100 group/cell">
                      {isQuickEditMode ? (
                        <input
                          type="number"
                          value={r.notDue || 0}
                          onChange={(e) =>
                            handleDirectFieldChange(r.id, 'notDue', Number(e.target.value) || 0)
                          }
                          className="w-20 px-1.5 py-1 text-right text-xs font-mono text-slate-700 bg-white border border-slate-300 rounded focus:ring-2 focus:ring-indigo-400 focus:outline-hidden"
                        />
                      ) : editingCell?.id === r.id && editingCell?.field === 'notDue' ? (
                        <div className="flex items-center justify-end gap-1">
                          <input
                            type="number"
                            autoFocus
                            value={cellValue}
                            onChange={(e) => setCellValue(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleSaveCell(r);
                              if (e.key === 'Escape') setEditingCell(null);
                            }}
                            className="w-20 px-1.5 py-0.5 text-right text-xs font-mono font-bold border border-indigo-400 rounded bg-white"
                          />
                          <button
                            onClick={() => handleSaveCell(r)}
                            className="p-1 text-emerald-600 hover:bg-emerald-50 rounded"
                            title="Save"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setEditingCell(null)}
                            className="p-1 text-slate-400 hover:bg-slate-100 rounded"
                            title="Cancel"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <div
                          onClick={() => handleStartCellEdit(r.id, 'notDue', r.notDue || 0)}
                          className="cursor-pointer inline-flex items-center justify-end gap-1 px-1.5 py-0.5 rounded hover:bg-indigo-50/80 border border-transparent hover:border-indigo-200 transition"
                          title="Click to edit Not Due Amount"
                        >
                          <span className="font-mono text-xs tabular-nums">
                            {(r.notDue || 0) > 0 ? (
                              <span className="font-medium text-slate-700">
                                {formatCurrency(r.notDue)}
                              </span>
                            ) : (
                              <span className="text-slate-300 font-sans">—</span>
                            )}
                          </span>
                          <Edit2 className="w-2.5 h-2.5 text-indigo-400 opacity-0 group-hover/cell:opacity-100 transition" />
                        </div>
                      )}
                    </td>

                    {/* Receipt Amount (EDITABLE CELL) */}
                    <td className="py-2.5 px-3 text-right border-b border-slate-100 group/cell">
                      {isQuickEditMode ? (
                        <input
                          type="number"
                          value={r.receiptAmt || 0}
                          onChange={(e) =>
                            handleDirectFieldChange(r.id, 'receiptAmt', Number(e.target.value) || 0)
                          }
                          className="w-24 px-1.5 py-1 text-right text-xs font-mono font-bold text-indigo-700 bg-white border border-indigo-300 rounded focus:ring-2 focus:ring-indigo-400 focus:outline-hidden"
                        />
                      ) : editingCell?.id === r.id && editingCell?.field === 'receiptAmt' ? (
                        <div className="flex items-center justify-end gap-1">
                          <input
                            type="number"
                            autoFocus
                            value={cellValue}
                            onChange={(e) => setCellValue(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleSaveCell(r);
                              if (e.key === 'Escape') setEditingCell(null);
                            }}
                            className="w-24 px-1.5 py-0.5 text-right text-xs font-mono font-bold border border-indigo-400 rounded bg-white"
                          />
                          <button
                            onClick={() => handleSaveCell(r)}
                            className="p-1 text-emerald-600 hover:bg-emerald-50 rounded"
                            title="Save"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setEditingCell(null)}
                            className="p-1 text-slate-400 hover:bg-slate-100 rounded"
                            title="Cancel"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <div
                          onClick={() => handleStartCellEdit(r.id, 'receiptAmt', r.receiptAmt)}
                          className="cursor-pointer inline-flex items-center justify-end gap-1 px-1.5 py-0.5 rounded hover:bg-indigo-50/80 border border-transparent hover:border-indigo-200 transition"
                          title="Click to edit Receipt Amount"
                        >
                          <span className="font-mono font-semibold text-indigo-700 text-xs tabular-nums">
                            {formatCurrency(r.receiptAmt)}
                          </span>
                          <Edit2 className="w-2.5 h-2.5 text-indigo-400 opacity-0 group-hover/cell:opacity-100 transition" />
                        </div>
                      )}
                    </td>

                    {/* Balance Amount (EDITABLE CELL & Auto-Recalculate) */}
                    <td className="py-2.5 px-3 text-right border-b border-slate-100 group/cell">
                      {isQuickEditMode ? (
                        <div className="inline-flex items-center gap-1">
                          <input
                            type="number"
                            value={r.balance || 0}
                            onChange={(e) =>
                              handleDirectFieldChange(r.id, 'balance', Number(e.target.value) || 0)
                            }
                            className={`w-24 px-1.5 py-1 text-right text-xs font-mono font-bold bg-white border rounded focus:ring-2 focus:outline-hidden ${
                              r.balance > 0
                                ? 'text-rose-600 border-rose-300 focus:ring-rose-400'
                                : 'text-slate-700 border-slate-300 focus:ring-indigo-400'
                            }`}
                          />
                        </div>
                      ) : editingCell?.id === r.id && editingCell?.field === 'balance' ? (
                        <div className="flex items-center justify-end gap-1">
                          <input
                            type="number"
                            autoFocus
                            value={cellValue}
                            onChange={(e) => setCellValue(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleSaveCell(r);
                              if (e.key === 'Escape') setEditingCell(null);
                            }}
                            className="w-24 px-1.5 py-0.5 text-right text-xs font-mono font-bold border border-rose-400 rounded bg-white text-rose-700"
                          />
                          <button
                            onClick={() => handleSaveCell(r)}
                            className="p-1 text-emerald-600 hover:bg-emerald-50 rounded"
                            title="Save"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setEditingCell(null)}
                            className="p-1 text-slate-400 hover:bg-slate-100 rounded"
                            title="Cancel"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <div
                          onClick={() => handleStartCellEdit(r.id, 'balance', r.balance)}
                          className="cursor-pointer inline-flex items-center justify-end gap-1 px-1.5 py-0.5 rounded hover:bg-rose-50/80 border border-transparent hover:border-rose-200 transition"
                          title="Click to edit Balance Amount or auto-calculate"
                        >
                          <span className="font-mono font-bold text-xs tabular-nums">
                            <span className={r.balance > 0 ? 'text-rose-600' : 'text-slate-400'}>
                              {formatCurrency(r.balance)}
                            </span>
                          </span>
                          <Edit2 className="w-2.5 h-2.5 text-rose-400 opacity-0 group-hover/cell:opacity-100 transition" />
                        </div>
                      )}
                    </td>

                    {/* Date Payment (EDITABLE CELL) */}
                    <td className="py-2.5 px-3 border-b border-slate-100 whitespace-nowrap group/cell">
                      {isQuickEditMode ? (
                        <input
                          type="date"
                          value={r.date || ''}
                          onChange={(e) => handleDirectFieldChange(r.id, 'date', e.target.value)}
                          className="w-32 px-1.5 py-1 text-xs font-mono text-slate-700 bg-white border border-slate-300 rounded focus:ring-2 focus:ring-indigo-400 focus:outline-hidden"
                        />
                      ) : editingCell?.id === r.id && editingCell?.field === 'date' ? (
                        <div className="flex items-center gap-1">
                          <input
                            type="date"
                            autoFocus
                            value={cellValue}
                            onChange={(e) => setCellValue(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleSaveCell(r);
                              if (e.key === 'Escape') setEditingCell(null);
                            }}
                            className="w-32 px-1.5 py-0.5 text-xs font-mono border border-indigo-400 rounded bg-white"
                          />
                          <button
                            onClick={() => handleSaveCell(r)}
                            className="p-1 text-emerald-600 hover:bg-emerald-50 rounded"
                            title="Save"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setEditingCell(null)}
                            className="p-1 text-slate-400 hover:bg-slate-100 rounded"
                            title="Cancel"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <div
                          onClick={() => handleStartCellEdit(r.id, 'date', r.date || '')}
                          className="cursor-pointer inline-flex items-center gap-1 px-1.5 py-0.5 rounded hover:bg-indigo-50/80 border border-transparent hover:border-indigo-200 transition"
                          title="Click to edit Date Payment"
                        >
                          <span className="text-xs text-slate-600 font-mono">
                            {r.date || <span className="text-slate-300 font-sans">Pending</span>}
                          </span>
                          <Edit2 className="w-2.5 h-2.5 text-indigo-400 opacity-0 group-hover/cell:opacity-100 transition" />
                        </div>
                      )}
                    </td>

                    {/* Status (EDITABLE CELL with Quick Stage Menu) */}
                    <td className="py-2.5 px-3 text-center whitespace-nowrap border-b border-slate-100 relative">
                      {isQuickEditMode ? (
                        <select
                          value={stage}
                          onChange={(e) =>
                            handleSetStage(r, e.target.value as VerificationStage)
                          }
                          className="px-2 py-1 text-xs font-semibold rounded border border-slate-300 bg-white text-slate-800 focus:ring-2 focus:ring-indigo-400 focus:outline-hidden"
                        >
                          <option value="pending">Pending</option>
                          <option value="1st">1st Ver</option>
                          <option value="2nd">2nd Ver</option>
                          <option value="3rd">3rd Ver (Final)</option>
                        </select>
                      ) : (
                        <div className="inline-block relative">
                          <button
                            type="button"
                            onClick={() =>
                              setStageMenuOpenId(stageMenuOpenId === r.id ? null : r.id)
                            }
                            title="Click to change verification stage and dates"
                            className="inline-flex flex-col items-center justify-center py-1 px-2.5 rounded-lg transition hover:bg-slate-100 border border-transparent hover:border-slate-200 cursor-pointer"
                          >
                            {stage === '3rd' && (
                              <>
                                <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-700">
                                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                                  3rd Ver (Final)
                                  <ChevronDown className="w-2.5 h-2.5 text-slate-400" />
                                </span>
                                <span className="text-[10px] text-emerald-600 font-mono">
                                  {r.thirdVerDate ? `Dated: ${r.thirdVerDate}` : 'Endorsed'}
                                </span>
                              </>
                            )}
                            {stage === '2nd' && (
                              <>
                                <span className="inline-flex items-center gap-1 text-xs font-bold text-indigo-700">
                                  <span className="w-2 h-2 rounded-full bg-indigo-500 shrink-0" />
                                  2nd Ver
                                  <ChevronDown className="w-2.5 h-2.5 text-slate-400" />
                                </span>
                                <span className="text-[10px] text-indigo-600 font-mono">
                                  {r.secondVerDate ? `Dated: ${r.secondVerDate}` : 'Re-checked'}
                                </span>
                              </>
                            )}
                            {stage === '1st' && (
                              <>
                                <span className="inline-flex items-center gap-1 text-xs font-bold text-blue-700">
                                  <span className="w-2 h-2 rounded-full bg-blue-500 shrink-0" />
                                  1st Ver
                                  <ChevronDown className="w-2.5 h-2.5 text-slate-400" />
                                </span>
                                <span className="text-[10px] text-blue-600 font-mono">
                                  {r.firstVerDate ? `Dated: ${r.firstVerDate}` : 'Initial OK'}
                                </span>
                              </>
                            )}
                            {stage === 'pending' && (
                              <>
                                <span className="inline-flex items-center gap-1 text-xs font-medium text-amber-700">
                                  <Clock className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                                  Pending
                                  <ChevronDown className="w-2.5 h-2.5 text-slate-400" />
                                </span>
                                <span className="text-[10px] text-slate-400 font-mono">
                                  Awaiting Ver
                                </span>
                              </>
                            )}
                          </button>

                          {/* Quick stage popup menu */}
                          {stageMenuOpenId === r.id && (
                            <div className="absolute top-full left-1/2 -translate-x-1/2 mt-1 z-30 bg-white rounded-xl shadow-xl border border-slate-200 p-2 w-48 text-left space-y-1 animate-fade-in">
                              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-2 py-0.5">
                                Select Stage:
                              </div>
                              <button
                                onClick={() => handleSetStage(r, 'pending')}
                                className="w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-medium hover:bg-amber-50 text-amber-800 flex items-center justify-between"
                              >
                                <span className="flex items-center gap-1.5">
                                  <Clock className="w-3 h-3 text-amber-500" />
                                  Pending
                                </span>
                                {stage === 'pending' && <Check className="w-3.5 h-3.5 text-amber-600" />}
                              </button>
                              <button
                                onClick={() => handleSetStage(r, '1st')}
                                className="w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-medium hover:bg-blue-50 text-blue-800 flex items-center justify-between"
                              >
                                <span className="flex items-center gap-1.5">
                                  <span className="w-2 h-2 rounded-full bg-blue-500" />
                                  1st Ver
                                </span>
                                {stage === '1st' && <Check className="w-3.5 h-3.5 text-blue-600" />}
                              </button>
                              <button
                                onClick={() => handleSetStage(r, '2nd')}
                                className="w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-medium hover:bg-indigo-50 text-indigo-800 flex items-center justify-between"
                              >
                                <span className="flex items-center gap-1.5">
                                  <span className="w-2 h-2 rounded-full bg-indigo-500" />
                                  2nd Ver
                                </span>
                                {stage === '2nd' && <Check className="w-3.5 h-3.5 text-indigo-600" />}
                              </button>
                              <button
                                onClick={() => handleSetStage(r, '3rd')}
                                className="w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-medium hover:bg-emerald-50 text-emerald-800 flex items-center justify-between"
                              >
                                <span className="flex items-center gap-1.5">
                                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                                  3rd Ver (Final)
                                </span>
                                {stage === '3rd' && <Check className="w-3.5 h-3.5 text-emerald-600" />}
                              </button>
                              <div className="pt-1 border-t border-slate-100 flex justify-end">
                                <button
                                  onClick={() => setStageMenuOpenId(null)}
                                  className="text-[10px] text-slate-400 hover:text-slate-600 px-2 py-0.5"
                                >
                                  Close
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </td>

                    {/* Remarks at the end (NEW COLUMN & EDITABLE CELL) */}
                    <td className="py-2.5 px-3 border-b border-slate-100 group/cell">
                      {isQuickEditMode ? (
                        <input
                          type="text"
                          value={r.remarks || ''}
                          placeholder="Add remark..."
                          onChange={(e) =>
                            handleDirectFieldChange(r.id, 'remarks', e.target.value)
                          }
                          className="w-36 px-2 py-1 text-xs text-slate-700 bg-white border border-slate-300 rounded focus:ring-2 focus:ring-indigo-400 focus:outline-hidden"
                        />
                      ) : editingCell?.id === r.id && editingCell?.field === 'remarks' ? (
                        <div className="flex items-center gap-1 min-w-[180px]">
                          <input
                            type="text"
                            autoFocus
                            value={cellValue}
                            placeholder="Type remarks..."
                            onChange={(e) => setCellValue(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleSaveCell(r);
                              if (e.key === 'Escape') setEditingCell(null);
                            }}
                            className="w-full px-2 py-1 text-xs border border-indigo-400 rounded bg-white"
                          />
                          <button
                            onClick={() => handleSaveCell(r)}
                            className="p-1 text-emerald-600 hover:bg-emerald-50 rounded"
                            title="Save"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setEditingCell(null)}
                            className="p-1 text-slate-400 hover:bg-slate-100 rounded"
                            title="Cancel"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <div
                          onClick={() => handleStartCellEdit(r.id, 'remarks', r.remarks || '')}
                          className="cursor-pointer inline-flex items-center gap-1.5 px-2 py-1 rounded hover:bg-indigo-50/80 border border-transparent hover:border-indigo-200 transition max-w-[200px]"
                          title="Click to edit Remarks"
                        >
                          <span className="text-xs text-slate-700 truncate">
                            {r.remarks || <span className="text-slate-300 italic text-[11px]">— Add remarks —</span>}
                          </span>
                          <Edit2 className="w-2.5 h-2.5 text-indigo-400 opacity-0 group-hover/cell:opacity-100 shrink-0 transition" />
                        </div>
                      )}
                    </td>

                    {/* Actions */}
                    <td className="py-2.5 px-3 text-center whitespace-nowrap border-b border-slate-100">
                      <div className="inline-flex items-center gap-1">
                        <button
                          onClick={() => onShowQRCode(r)}
                          title="Generate & View Public Verification QR Code"
                          className="p-1 text-slate-500 hover:text-indigo-600 hover:bg-slate-100 rounded transition cursor-pointer"
                        >
                          <QrCode className="w-3.5 h-3.5 text-indigo-600" />
                        </button>
                        <button
                          onClick={() => onEdit(r)}
                          title="Full edit dialog"
                          className="p-1 text-slate-500 hover:text-indigo-600 hover:bg-slate-100 rounded transition"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => onViewVoucher(r)}
                          title="View Tax Voucher / Challan"
                          className="p-1 text-slate-500 hover:text-emerald-600 hover:bg-slate-100 rounded transition"
                        >
                          <Receipt className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => onDuplicate(r)}
                          title="Duplicate as new entry"
                          className="p-1 text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded transition"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => onDelete(r.id)}
                          title="Delete entry"
                          className="p-1 text-slate-400 hover:text-rose-600 hover:bg-slate-100 rounded transition"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>

          {records.length > 0 && (
            <tfoot className="sticky bottom-0 z-20 bg-slate-100/95 backdrop-blur-xs font-bold border-t-2 border-slate-300 text-xs shadow-sm">
              <tr>
                <td
                  colSpan={8}
                  className="py-2.5 px-3 text-right uppercase text-[11px] font-bold text-slate-700 border-b border-slate-200"
                >
                  Total for {records.length} Records:
                </td>
                <td className="py-2.5 px-3 text-right font-mono text-slate-800 border-b border-slate-200 tabular-nums">
                  {formatCurrency(totalAudit)}
                </td>
                <td className="py-2.5 px-3 text-right font-mono text-emerald-600 border-b border-slate-200 tabular-nums">
                  {formatCurrency(totalRecovered)}
                </td>
                <td className="py-2.5 px-3 text-right font-mono text-slate-700 border-b border-slate-200 tabular-nums">
                  {totalPrior > 0 ? formatCurrency(totalPrior) : '—'}
                </td>
                <td className="py-2.5 px-3 text-right font-mono text-slate-700 border-b border-slate-200 tabular-nums">
                  {totalNotDue > 0 ? formatCurrency(totalNotDue) : '—'}
                </td>
                <td className="py-2.5 px-3 text-right font-mono text-indigo-700 border-b border-slate-200 tabular-nums">
                  {formatCurrency(totalReceipts)}
                </td>
                <td
                  className={`py-2.5 px-3 text-right font-mono font-bold border-b border-slate-200 tabular-nums ${
                    totalBalance > 0 ? 'text-rose-600' : 'text-slate-800'
                  }`}
                >
                  {formatCurrency(totalBalance)}
                </td>
                <td
                  colSpan={4}
                  className="py-2.5 px-3 text-center text-[10px] text-slate-500 font-mono border-b border-slate-200"
                >
                  Top Row Frozen Active • In-Cell Quick Edit Enabled
                </td>
              </tr>
            </tfoot>
          )}
        </table>
      </div>
    </div>
  );
};
