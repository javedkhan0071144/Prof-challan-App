import React from 'react';
import { FilterState } from '../types';
import { Search, X, RotateCcw } from 'lucide-react';

interface FilterToolbarProps {
  filter: FilterState;
  setFilter: React.Dispatch<React.SetStateAction<FilterState>>;
  districts: string[];
  tehsils: string[];
  circles: string[];
  paras?: { paraNo: string; title: string }[];
  totalCount: number;
  filteredCount: number;
  onResetFilters: () => void;
}

export const FilterToolbar: React.FC<FilterToolbarProps> = ({
  filter,
  setFilter,
  districts,
  tehsils,
  circles,
  paras = [],
  totalCount,
  filteredCount,
  onResetFilters,
}) => {
  const isAnyFilterActive =
    Boolean(filter.search) ||
    Boolean(filter.district) ||
    Boolean(filter.tehsil) ||
    Boolean(filter.circle) ||
    (Boolean(filter.paraFilter) && filter.paraFilter !== 'all') ||
    filter.verifiedStatus !== 'all' ||
    filter.balanceStatus !== 'all';

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-4 space-y-3 shadow-xs">
      {/* Top row: Search input + Para & District & Tehsil & Circle dropdowns */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-center">
        {/* Search */}
        <div className="md:col-span-4 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={filter.search}
            onChange={(e) => setFilter(prev => ({ ...prev, search: e.target.value }))}
            placeholder="Search Property No, Owner, ID, Circle, Para..."
            className="w-full pl-9 pr-8 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-white placeholder-slate-400"
          />
          {filter.search && (
            <button
              onClick={() => setFilter(prev => ({ ...prev, search: '' }))}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Audit Para */}
        <div className="md:col-span-2">
          <select
            value={filter.paraFilter || 'all'}
            onChange={(e) => setFilter(prev => ({ ...prev, paraFilter: e.target.value }))}
            className="w-full text-sm border border-slate-300 rounded-lg px-2.5 py-2 bg-white text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium"
          >
            <option value="all">All Audit Paras</option>
            {paras.map(p => (
              <option key={p.paraNo} value={p.paraNo}>
                {p.paraNo}: {p.title.split('&')[0].trim()}
              </option>
            ))}
          </select>
        </div>

        {/* District */}
        <div className="md:col-span-2">
          <select
            value={filter.district}
            onChange={(e) => setFilter(prev => ({ ...prev, district: e.target.value }))}
            className="w-full text-sm border border-slate-300 rounded-lg px-2.5 py-2 bg-white text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="">All Districts</option>
            {districts.map(d => (
              <option key={d} value={d}>{d}</option>
            ))}
          </select>
        </div>

        {/* Tehsil */}
        <div className="md:col-span-2">
          <select
            value={filter.tehsil}
            onChange={(e) => setFilter(prev => ({ ...prev, tehsil: e.target.value }))}
            className="w-full text-sm border border-slate-300 rounded-lg px-2.5 py-2 bg-white text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="">All Tehsils</option>
            {tehsils.map(t => (
              <option key={t} value={t}>{t}</option>
            ))}
          </select>
        </div>

        {/* Circle */}
        <div className="md:col-span-2">
          <select
            value={filter.circle}
            onChange={(e) => setFilter(prev => ({ ...prev, circle: e.target.value }))}
            className="w-full text-sm border border-slate-300 rounded-lg px-2.5 py-2 bg-white text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="">All Circles</option>
            {circles.map(c => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Bottom row: Status segment filters & Reset button */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100 text-xs">
        <div className="flex flex-wrap items-center gap-3">
          {/* Verification Segment */}
          <div className="flex items-center gap-1">
            <span className="text-slate-500 font-medium mr-1">Verification:</span>
            <div className="inline-flex p-0.5 bg-slate-100 rounded-md border border-slate-200">
              <button
                type="button"
                onClick={() => setFilter(prev => ({ ...prev, verifiedStatus: 'all' }))}
                className={`px-2 py-1 rounded text-xs font-medium transition-colors ${
                  filter.verifiedStatus === 'all'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                All
              </button>
              <button
                type="button"
                onClick={() => setFilter(prev => ({ ...prev, verifiedStatus: 'pending' }))}
                className={`px-2 py-1 rounded text-xs font-medium transition-colors ${
                  filter.verifiedStatus === 'pending'
                    ? 'bg-white text-amber-700 font-semibold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Pending
              </button>
              <button
                type="button"
                onClick={() => setFilter(prev => ({ ...prev, verifiedStatus: '1st' }))}
                className={`px-2 py-1 rounded text-xs font-medium transition-colors ${
                  filter.verifiedStatus === '1st'
                    ? 'bg-white text-blue-700 font-semibold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                1st Ver
              </button>
              <button
                type="button"
                onClick={() => setFilter(prev => ({ ...prev, verifiedStatus: '2nd' }))}
                className={`px-2 py-1 rounded text-xs font-medium transition-colors ${
                  filter.verifiedStatus === '2nd'
                    ? 'bg-white text-indigo-700 font-semibold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                2nd Ver
              </button>
              <button
                type="button"
                onClick={() => setFilter(prev => ({ ...prev, verifiedStatus: '3rd' }))}
                className={`px-2 py-1 rounded text-xs font-medium transition-colors ${
                  filter.verifiedStatus === '3rd'
                    ? 'bg-white text-emerald-700 font-semibold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                3rd Ver (Final)
              </button>
            </div>
          </div>

          {/* Balance Segment */}
          <div className="flex items-center gap-1">
            <span className="text-slate-500 font-medium mr-1">Balance:</span>
            <div className="inline-flex p-0.5 bg-slate-100 rounded-md border border-slate-200">
              <button
                type="button"
                onClick={() => setFilter(prev => ({ ...prev, balanceStatus: 'all' }))}
                className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                  filter.balanceStatus === 'all'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                All
              </button>
              <button
                type="button"
                onClick={() => setFilter(prev => ({ ...prev, balanceStatus: 'outstanding' }))}
                className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                  filter.balanceStatus === 'outstanding'
                    ? 'bg-white text-rose-700 font-semibold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Outstanding (&gt; 0)
              </button>
              <button
                type="button"
                onClick={() => setFilter(prev => ({ ...prev, balanceStatus: 'settled' }))}
                className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                  filter.balanceStatus === 'settled'
                    ? 'bg-white text-slate-800 font-semibold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Zero Balance
              </button>
            </div>
          </div>
        </div>

        {/* Right side: Count and Reset button */}
        <div className="flex items-center gap-3">
          <span className="text-slate-500 font-mono">
            Showing <strong className="text-slate-900">{filteredCount}</strong> of {totalCount} records
          </span>
          {isAnyFilterActive && (
            <button
              onClick={onResetFilters}
              className="text-indigo-600 hover:text-indigo-800 font-medium flex items-center gap-1 hover:underline cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" />
              Reset Filters
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
