import React from 'react';
import { Plus, Download, Upload, BarChart3, Printer, RotateCcw, Layers } from 'lucide-react';

interface HeaderProps {
  activeTab: 'ledger' | 'paras-dashboard' | 'analytics' | 'report';
  setActiveTab: (tab: 'ledger' | 'paras-dashboard' | 'analytics' | 'report') => void;
  onOpenAddModal: () => void;
  onOpenImportModal: () => void;
  onExportCSV: () => void;
  onResetData: () => void;
  totalRecords: number;
  totalParas?: number;
  selectedCount?: number;
  onExportSelected?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onOpenAddModal,
  onOpenImportModal,
  onExportCSV,
  onResetData,
  totalRecords,
  totalParas,
  selectedCount = 0,
  onExportSelected,
}) => {
  return (
    <header className="bg-slate-900 text-white border-b border-slate-800 sticky top-0 z-30 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-6">
        {/* Zone 1: Wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-9 h-9 rounded-lg bg-indigo-600 flex items-center justify-center font-bold text-white text-base shadow-sm">
            AE
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-base font-bold tracking-tight text-white whitespace-nowrap">
                AppSheet Audit Engine
              </span>
              <span className="text-xs text-slate-400 hidden sm:inline">
                Property Tax & Recovery
              </span>
            </div>
            <div className="text-[11px] text-slate-400 font-mono flex items-center gap-2">
              <span>Real-time Ledger · {totalRecords} records</span>
              {totalParas !== undefined && (
                <>
                  <span>·</span>
                  <span className="text-indigo-400 font-semibold">{totalParas} Audit Paras</span>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Zone 2: Navigation Tabs */}
        <nav className="hidden md:flex items-center gap-1 bg-slate-800/80 p-1 rounded-lg border border-slate-700/60 text-xs">
          <button
            onClick={() => setActiveTab('ledger')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors whitespace-nowrap ${
              activeTab === 'ledger'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
            }`}
          >
            Audit Ledger
          </button>
          <button
            onClick={() => setActiveTab('paras-dashboard')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'paras-dashboard'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Paras Dashboard</span>
            <span className="px-1.5 py-0.2 rounded bg-indigo-500/40 text-[10px] text-indigo-200 font-mono font-bold">
              Broad
            </span>
          </button>
          <button
            onClick={() => setActiveTab('analytics')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'analytics'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            Circle Analytics
          </button>
          <button
            onClick={() => setActiveTab('report')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'report'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
            }`}
          >
            <Printer className="w-3.5 h-3.5" />
            Audit Report
          </button>
        </nav>

        {/* Zone 3: Actions */}
        <div className="flex items-center gap-2 shrink-0">
          {selectedCount > 0 && onExportSelected && (
            <button
              onClick={onExportSelected}
              title={`Export only the ${selectedCount} selected records to CSV with current verification status and audit calculations`}
              className="px-2.5 py-1.5 text-xs font-semibold text-emerald-200 bg-emerald-950/90 hover:bg-emerald-900 border border-emerald-600/70 rounded-lg transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer shadow-xs animate-fade-in"
            >
              <Download className="w-3.5 h-3.5 text-emerald-400" />
              <span>Export Selected ({selectedCount})</span>
            </button>
          )}

          <button
            onClick={onExportCSV}
            title="Export full audit dataset as CSV"
            className="px-2.5 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 hover:text-white rounded-lg border border-slate-700 transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Export CSV</span>
          </button>

          {/* Prominent Import CSV Button */}
          <button
            type="button"
            onClick={onOpenImportModal}
            title="Bulk import property tax audit records from CSV or spreadsheet"
            className="px-3 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 rounded-lg transition-all duration-150 flex items-center gap-1.5 shadow-xs whitespace-nowrap cursor-pointer hover:shadow-emerald-900/40"
          >
            <Upload className="w-3.5 h-3.5 text-emerald-100" />
            <span>Import CSV</span>
          </button>

          <button
            onClick={onResetData}
            title="Reset to default sample data"
            className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={onOpenAddModal}
            className="px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 rounded-lg transition flex items-center gap-1.5 shadow-sm whitespace-nowrap cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Entry</span>
          </button>
        </div>
      </div>
    </header>
  );
};
