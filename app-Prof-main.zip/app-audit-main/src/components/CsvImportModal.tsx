import React, { useState } from 'react';
import { AuditRecord } from '../types';
import { parseCSVToRecords, formatCurrency } from '../utils/formatters';
import { X, Upload, FileText, Check, AlertCircle } from 'lucide-react';

interface CsvImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImport: (records: AuditRecord[], mode: 'append' | 'replace') => void;
  currentMaxId: number;
}

export const CsvImportModal: React.FC<CsvImportModalProps> = ({
  isOpen,
  onClose,
  onImport,
  currentMaxId,
}) => {
  const [csvText, setCsvText] = useState<string>('');
  const [importMode, setImportMode] = useState<'append' | 'replace'>('append');
  const [parsedPreview, setParsedPreview] = useState<AuditRecord[]>([]);
  const [errorMsg, setErrorMsg] = useState<string>('');

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      setCsvText(content);
      handleParse(content);
    };
    reader.readAsText(file);
  };

  const handleParse = (text: string) => {
    try {
      setErrorMsg('');
      const startingId = importMode === 'replace' ? 1 : currentMaxId + 1;
      const parsed = parseCSVToRecords(text, startingId);
      if (parsed.length === 0) {
        setErrorMsg('Could not find valid records in the provided CSV text. Please check the columns.');
      }
      setParsedPreview(parsed);
    } catch (err: any) {
      setErrorMsg(err?.message || 'Error parsing CSV data');
    }
  };

  const handleLoadSample = () => {
    const sample = `Sr/No-ID,Para Details,Para No,District,Tehsil,Circle Name,Property No,Owners Name,Audit Sr No,Audit Amt,Recovered,Prior Audit,Not Due,Receipt Amt,Date,Balance,Used in Verification,Challan No,Remarks
10,6-Petrol Pump,Para-6,RWP,GK,GKB-I,501/Petrol Pump,Sunrise Petroleum,101,310000,310000,0,0,310000,2026-04-05,0,Yes,CH-2026-310,Tax challan cleared
11,6-Petrol Pump,Para-6,RWP,Taxila,Taxila,24-B/Commercial,Apex Filling Station,102,480000,240000,40000,0,240000,2026-04-06,200000,No,CH-2026-311,Installment 1 verified
12,6-Petrol Pump,Para-6,RWP,GK,GKB-II,77/Filling,Capital Energy,103,195000,195000,0,0,195000,2026-04-07,0,Yes,CH-2026-312,Verified via NBP`;
    setCsvText(sample);
    handleParse(sample);
  };

  const handleConfirmImport = () => {
    if (parsedPreview.length === 0) {
      setErrorMsg('No valid records to import.');
      return;
    }
    onImport(parsedPreview, importMode);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] flex flex-col overflow-hidden border border-slate-200">
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between shrink-0">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900">
              Import Audit Records
            </h2>
            <p className="text-xs text-slate-500">
              Upload a CSV file or paste tabular data from Excel or AppSheet
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-4">
          {/* File Upload & Sample Controls */}
          <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-slate-50 border border-slate-200 rounded-xl">
            <label className="cursor-pointer inline-flex items-center gap-2 px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-50 shadow-xs transition">
              <Upload className="w-3.5 h-3.5 text-indigo-600" />
              <span>Choose CSV File</span>
              <input
                type="file"
                accept=".csv,text/csv"
                onChange={handleFileUpload}
                className="hidden"
              />
            </label>

            <button
              type="button"
              onClick={handleLoadSample}
              className="text-xs text-indigo-600 hover:text-indigo-800 font-medium hover:underline flex items-center gap-1 cursor-pointer"
            >
              <FileText className="w-3.5 h-3.5" />
              Load Sample Data
            </button>
          </div>

          {/* Paste CSV Area */}
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">
              CSV Content (Paste below)
            </label>
            <textarea
              rows={4}
              value={csvText}
              onChange={(e) => {
                setCsvText(e.target.value);
                handleParse(e.target.value);
              }}
              placeholder="Sr/No-ID,Para Details,Para No,District,Tehsil,Circle Name,Property No,Owners Name,Audit Sr No,Audit Amt,Recovered..."
              className="w-full font-mono text-xs border border-slate-300 rounded-lg p-3 text-slate-800 focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg flex items-center gap-2 text-xs text-rose-700">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Import Mode Options */}
          <div className="flex items-center gap-4 text-xs font-medium text-slate-700">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="radio"
                name="importMode"
                value="append"
                checked={importMode === 'append'}
                onChange={() => setImportMode('append')}
                className="text-indigo-600 focus:ring-indigo-500"
              />
              <span>Append to existing records</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="radio"
                name="importMode"
                value="replace"
                checked={importMode === 'replace'}
                onChange={() => setImportMode('replace')}
                className="text-indigo-600 focus:ring-indigo-500"
              />
              <span>Replace entire current dataset</span>
            </label>
          </div>

          {/* Parsed Preview Table */}
          {parsedPreview.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-700">
                <span>Preview ({parsedPreview.length} records parsed)</span>
                <span className="text-emerald-600">Ready to import</span>
              </div>
              <div className="max-h-48 overflow-y-auto border border-slate-200 rounded-lg">
                <table className="w-full text-left text-xs border-collapse">
                  <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 sticky top-0">
                    <tr>
                      <th className="py-2 px-2.5">ID</th>
                      <th className="py-2 px-2.5">Property</th>
                      <th className="py-2 px-2.5">Owner</th>
                      <th className="py-2 px-2.5 text-right">Audit Amt</th>
                      <th className="py-2 px-2.5 text-right">Balance</th>
                      <th className="py-2 px-2.5 text-center">Verified</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {parsedPreview.slice(0, 10).map((r, idx) => (
                      <tr key={idx} className="hover:bg-slate-50 font-mono">
                        <td className="py-1.5 px-2.5">#{r.id}</td>
                        <td className="py-1.5 px-2.5 font-sans font-semibold text-indigo-700">{r.propertyNo}</td>
                        <td className="py-1.5 px-2.5 font-sans">{r.owner}</td>
                        <td className="py-1.5 px-2.5 text-right">{formatCurrency(r.auditAmt)}</td>
                        <td className="py-1.5 px-2.5 text-right font-bold text-rose-600">{formatCurrency(r.balance)}</td>
                        <td className="py-1.5 px-2.5 text-center font-sans">
                          {r.verified ? '✓ Yes' : 'Pending'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {parsedPreview.length > 10 && (
                <p className="text-[11px] text-slate-400">
                  + {parsedPreview.length - 10} more records will be imported
                </p>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 flex items-center justify-end gap-3 shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-50 transition"
          >
            Cancel
          </button>
          <button
            type="button"
            disabled={parsedPreview.length === 0}
            onClick={handleConfirmImport}
            className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-lg text-xs font-semibold shadow-xs transition flex items-center gap-1.5"
          >
            <Check className="w-4 h-4" />
            <span>Confirm Import ({parsedPreview.length})</span>
          </button>
        </div>
      </div>
    </div>
  );
};
