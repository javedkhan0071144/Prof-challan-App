import React, { useState, useEffect } from 'react';
import { AuditRecord } from '../types';
import { formatCurrency } from '../utils/formatters';
import { generateQRCode, getVerificationUrl, getVerificationFingerprint } from '../utils/qrCode';
import { QrCode, X, Copy, Check, ExternalLink, Download, ShieldCheck, CheckCircle2, Clock } from 'lucide-react';

interface QRCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
  record: AuditRecord | null;
  onOpenPublicView: (record: AuditRecord) => void;
}

export const QRCodeModal: React.FC<QRCodeModalProps> = ({
  isOpen,
  onClose,
  record,
  onOpenPublicView,
}) => {
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);

  const verificationUrl = record ? getVerificationUrl(record) : '';
  const fingerprint = record ? getVerificationFingerprint(record) : '';

  useEffect(() => {
    if (!record || !isOpen) {
      setQrDataUrl('');
      return;
    }

    setLoading(true);
    generateQRCode(verificationUrl, 320)
      .then((url) => {
        setQrDataUrl(url);
        setLoading(false);
      })
      .catch(() => {
        setLoading(false);
      });
  }, [record, isOpen, verificationUrl]);

  if (!isOpen || !record) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(verificationUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    if (!qrDataUrl) return;
    const link = document.createElement('a');
    link.href = qrDataUrl;
    link.download = `QR_Verification_${record.propertyNo.replace(/[^a-zA-Z0-9]/g, '_')}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const stage = record.verificationStage || (record.verified ? '3rd' : 'pending');

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-600 flex items-center justify-center text-white shadow-xs">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Property Verification QR Code
              </h3>
              <p className="text-[11px] text-slate-500 font-mono">
                Property #{record.propertyNo} · ID #{record.id}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200/50 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 sm:p-6 space-y-5">
          {/* QR Code Presentation Box */}
          <div className="flex flex-col items-center justify-center p-6 bg-slate-50 rounded-2xl border border-slate-200 text-center">
            <div className="relative bg-white p-3 rounded-2xl shadow-sm border border-slate-200/80 mb-3">
              {loading ? (
                <div className="w-48 h-48 flex items-center justify-center text-slate-400 text-xs">
                  Generating secure QR...
                </div>
              ) : qrDataUrl ? (
                <img
                  src={qrDataUrl}
                  alt={`QR Code for Property ${record.propertyNo}`}
                  className="w-48 h-48 sm:w-56 sm:h-56 object-contain rounded-lg"
                />
              ) : (
                <div className="w-48 h-48 flex items-center justify-center text-rose-500 text-xs">
                  Error generating QR Code
                </div>
              )}

              {/* Verified seal indicator */}
              <div className="absolute -bottom-2 -right-2 bg-emerald-600 text-white p-1.5 rounded-full shadow-md">
                <ShieldCheck className="w-4 h-4" />
              </div>
            </div>

            <span className="text-xs font-semibold text-slate-800">
              Scan with any mobile phone or barcode scanner
            </span>
            <span className="text-[11px] text-slate-500 max-w-xs mt-0.5">
              Instantly opens the secure public property tax audit verification portal
            </span>
          </div>

          {/* Key Property Audit Data */}
          <div className="bg-slate-50 rounded-xl p-3.5 border border-slate-200 space-y-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-slate-500">Taxpayer / Owner:</span>
              <span className="font-semibold text-slate-800">{record.owner}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-500">Jurisdiction:</span>
              <span className="font-medium text-slate-700">
                {record.tehsil} / {record.circle} ({record.district})
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-500">Audit Para:</span>
              <span className="font-medium text-indigo-900 font-mono">
                {record.paraNo || 'Para-6'} ({record.details || 'Commercial'})
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-500">Current Balance:</span>
              <span className={`font-mono font-bold ${record.balance > 0 ? 'text-rose-600' : 'text-emerald-700'}`}>
                {formatCurrency(record.balance)} {record.balance === 0 ? '(SETTLED)' : ''}
              </span>
            </div>
            <div className="flex items-center justify-between pt-1 border-t border-slate-200">
              <span className="text-slate-500">Verification Status:</span>
              <span className="inline-flex items-center gap-1 font-semibold text-[11px]">
                {stage === '3rd' ? (
                  <span className="text-emerald-700 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    3rd Ver (Final Reconciled)
                  </span>
                ) : stage === '2nd' ? (
                  <span className="text-indigo-700 flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-indigo-500" />
                    2nd Ver
                  </span>
                ) : stage === '1st' ? (
                  <span className="text-blue-700 flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-blue-500" />
                    1st Ver
                  </span>
                ) : (
                  <span className="text-amber-700 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-amber-500" />
                    Pending Verification
                  </span>
                )}
              </span>
            </div>
          </div>

          {/* Verification URL & Copy Control */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
              Public Verification Link
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={verificationUrl}
                className="w-full bg-slate-100 border border-slate-200 text-slate-700 rounded-lg px-3 py-1.5 text-xs font-mono select-all focus:outline-none"
              />
              <button
                type="button"
                onClick={handleCopy}
                className="px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1 transition cursor-pointer whitespace-nowrap"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span className="text-emerald-700">Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>
            <div className="text-[10px] text-slate-400 font-mono truncate">
              Security Token: {fingerprint}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-2.5 pt-2">
            <button
              type="button"
              onClick={handleDownload}
              className="px-4 py-2 bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer shadow-2xs"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download QR</span>
            </button>
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenPublicView(record);
              }}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 shadow-xs transition cursor-pointer"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Open Public View</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
