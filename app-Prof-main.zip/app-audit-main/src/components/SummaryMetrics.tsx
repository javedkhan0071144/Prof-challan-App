import React, { useMemo } from 'react';
import { AuditRecord } from '../types';
import { formatCurrency } from '../utils/formatters';
import { Calculator, CheckCircle2, Receipt, Scale, ShieldCheck, TrendingUp, TrendingDown } from 'lucide-react';

interface SummaryMetricsProps {
  records: AuditRecord[];
  filteredRecords: AuditRecord[];
}

export const SummaryMetrics: React.FC<SummaryMetricsProps> = ({
  records,
  filteredRecords,
}) => {
  const isFiltered = filteredRecords.length !== records.length;
  const currentSet = filteredRecords;

  const totalAudit = currentSet.reduce((acc, r) => acc + (r.auditAmt || 0), 0);
  const totalRecovered = currentSet.reduce((acc, r) => acc + (r.recovered || 0), 0);
  const totalReceipts = currentSet.reduce((acc, r) => acc + (r.receiptAmt || 0), 0);
  const totalBalance = currentSet.reduce((acc, r) => acc + (r.balance || 0), 0);
  const totalPriorAudit = currentSet.reduce((acc, r) => acc + (r.priorAudit || 0), 0);
  const totalNotDue = currentSet.reduce((acc, r) => acc + (r.notDue || 0), 0);

  const thirdVerCount = currentSet.filter(r => r.verificationStage === '3rd' || r.verified).length;
  const secondVerCount = currentSet.filter(r => r.verificationStage === '2nd').length;
  const firstVerCount = currentSet.filter(r => r.verificationStage === '1st').length;
  const pendingVerCount = currentSet.filter(r => (!r.verificationStage || r.verificationStage === 'pending') && !r.verified).length;

  const recoveryRate = totalAudit > 0 ? Math.min(100, Math.round((totalRecovered / totalAudit) * 100)) : 0;

  // Chronological recovery sparkline points
  const { recoverySparkline, dateRangeText, balanceSparkline } = useMemo(() => {
    const dated = currentSet
      .filter((r) => r.date && r.date.trim().length > 0)
      .sort((a, b) => a.date.localeCompare(b.date));

    if (dated.length === 0) {
      return {
        recoverySparkline: { points: '0,24 50,14 100,6', areaPath: 'M0,28 L0,24 L50,14 L100,6 L100,28 Z', lastY: 6 },
        dateRangeText: 'Timeline in progress',
        balanceSparkline: { points: '0,6 50,16 100,22', areaPath: 'M0,28 L0,6 L50,16 L100,22 L100,28 Z', lastY: 22 },
      };
    }

    // Aggregate recoveries by unique date
    const byDate: Record<string, { recovered: number; audit: number }> = {};
    dated.forEach((r) => {
      if (!byDate[r.date]) {
        byDate[r.date] = { recovered: 0, audit: 0 };
      }
      byDate[r.date].recovered += r.recovered || 0;
      byDate[r.date].audit += r.auditAmt || 0;
    });

    const dates = Object.keys(byDate).sort();
    let cumRecovered = 0;
    let cumBalance = totalAudit;

    const dataPoints: { recovered: number; balance: number }[] = [];

    // Initial baseline point
    dataPoints.push({ recovered: 0, balance: totalAudit });

    dates.forEach((d) => {
      cumRecovered += byDate[d].recovered;
      cumBalance = Math.max(0, cumBalance - byDate[d].recovered);
      dataPoints.push({ recovered: cumRecovered, balance: cumBalance });
    });

    const maxRecovered = Math.max(cumRecovered, 1);
    const maxBalance = Math.max(totalAudit, 1);
    const numPoints = dataPoints.length;

    // Map to SVG coordinates: viewBox 0 0 100 28
    const recCoords = dataPoints.map((p, idx) => {
      const x = Math.round((idx / (numPoints - 1)) * 100);
      const ratio = p.recovered / maxRecovered;
      // y inverted: 24 is baseline (low), 4 is max (high)
      const y = Math.round(24 - ratio * 20);
      return { x, y };
    });

    const balCoords = dataPoints.map((p, idx) => {
      const x = Math.round((idx / (numPoints - 1)) * 100);
      const ratio = p.balance / maxBalance;
      const y = Math.round(24 - ratio * 20);
      return { x, y };
    });

    const recLine = recCoords.map((c) => `${c.x},${c.y}`).join(' ');
    const recArea = `M0,28 L${recCoords.map((c) => `${c.x},${c.y}`).join(' L')} L100,28 Z`;

    const balLine = balCoords.map((c) => `${c.x},${c.y}`).join(' ');
    const balArea = `M0,28 L${balCoords.map((c) => `${c.x},${c.y}`).join(' L')} L100,28 Z`;

    const minDateStr = dates[0];
    const maxDateStr = dates[dates.length - 1];
    const range = `${minDateStr} → ${maxDateStr}`;

    return {
      recoverySparkline: {
        points: recLine,
        areaPath: recArea,
        lastY: recCoords[recCoords.length - 1]?.y ?? 4,
      },
      balanceSparkline: {
        points: balLine,
        areaPath: balArea,
        lastY: balCoords[balCoords.length - 1]?.y ?? 20,
      },
      dateRangeText: range,
    };
  }, [currentSet, totalAudit]);

  return (
    <div className="w-full space-y-3">
      {isFiltered && (
        <div className="flex items-center justify-between text-xs text-indigo-700 bg-indigo-50 border border-indigo-200/60 px-3.5 py-1.5 rounded-lg">
          <span>Showing metrics for filtered subset ({filteredRecords.length} of {records.length} records)</span>
          <span className="font-medium font-mono">Filtered Active</span>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Total Audit Amount */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Total Audit Amount
              </p>
              <h3 className="text-2xl font-bold text-slate-900 tracking-tight font-mono tabular-nums">
                {formatCurrency(totalAudit)}
              </h3>
            </div>
            <div className="w-10 h-10 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
              <Calculator className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span className="font-mono">{currentSet.length} assessed properties</span>
            <span className="text-[11px] text-slate-400 font-mono">Para-6 Base</span>
          </div>
        </div>

        {/* Card 2: Total Recovered with Sparkline Trend */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Total Recovered
              </p>
              <h3 className="text-2xl font-bold text-emerald-600 tracking-tight font-mono tabular-nums">
                {formatCurrency(totalRecovered)}
              </h3>
            </div>
            <div className="w-10 h-10 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
              <CheckCircle2 className="w-5 h-5" />
            </div>
          </div>

          {/* Sparkline & Trend Area */}
          <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-end justify-between gap-2">
            <div className="space-y-0.5">
              <div className="flex items-center gap-1.5 text-xs">
                <span className="text-emerald-700 font-bold font-mono">{recoveryRate}%</span>
                <span className="text-slate-500 text-[11px]">recovered</span>
                <span className="inline-flex items-center text-[10px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200/60 px-1 py-0.5 rounded font-mono">
                  <TrendingUp className="w-3 h-3 mr-0.5" />
                  Trend
                </span>
              </div>
              <div className="text-[10px] text-slate-400 font-mono truncate max-w-[120px]" title={dateRangeText}>
                {dateRangeText}
              </div>
            </div>

            {/* Sparkline SVG */}
            <div className="w-24 h-7 shrink-0 relative" title={`Recovery pace: ${formatCurrency(totalRecovered)} recovered over time`}>
              <svg className="w-full h-full overflow-visible" viewBox="0 0 100 28" preserveAspectRatio="none">
                <defs>
                  <linearGradient id="recoveryGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#10b981" stopOpacity="0.25" />
                    <stop offset="100%" stopColor="#10b981" stopOpacity="0.0" />
                  </linearGradient>
                </defs>
                <path d={recoverySparkline.areaPath} fill="url(#recoveryGradient)" />
                <polyline
                  fill="none"
                  stroke="#059669"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  points={recoverySparkline.points}
                />
                <circle cx="100" cy={recoverySparkline.lastY} r="2.5" fill="#047857" />
              </svg>
            </div>
          </div>
        </div>

        {/* Card 3: Total Receipts */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Total Receipts
              </p>
              <h3 className="text-2xl font-bold text-indigo-600 tracking-tight font-mono tabular-nums">
                {formatCurrency(totalReceipts)}
              </h3>
            </div>
            <div className="w-10 h-10 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0">
              <Receipt className="w-5 h-5" />
            </div>
          </div>

          <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <div className="flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-indigo-600" />
              <span>{thirdVerCount} fully verified</span>
            </div>
            <span className="font-mono text-[10px] text-slate-500">
              <strong className="text-blue-600">{firstVerCount}</strong> 1st · <strong className="text-indigo-600">{secondVerCount}</strong> 2nd · <strong className="text-amber-600">{pendingVerCount}</strong> Pend
            </span>
          </div>
        </div>

        {/* Card 4: Outstanding Balance with Burn-Down Trend */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Outstanding Balance
              </p>
              <h3 className={`text-2xl font-bold tracking-tight font-mono tabular-nums ${totalBalance > 0 ? 'text-rose-600' : 'text-slate-700'}`}>
                {formatCurrency(totalBalance)}
              </h3>
            </div>
            <div className="w-10 h-10 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center shrink-0">
              <Scale className="w-5 h-5" />
            </div>
          </div>

          {/* Sparkline & Burn-Down Area */}
          <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-end justify-between gap-2">
            <div className="space-y-0.5">
              <div className="flex items-center gap-1.5 text-xs">
                <span className={`font-mono font-bold ${totalBalance > 0 ? 'text-rose-600' : 'text-slate-600'}`}>
                  {totalBalance === 0 ? 'Settled' : `${Math.round((totalBalance / Math.max(totalAudit, 1)) * 100)}%`}
                </span>
                <span className="text-slate-500 text-[11px]">due</span>
                {totalBalance > 0 && (
                  <span className="inline-flex items-center text-[10px] font-semibold text-rose-700 bg-rose-50 border border-rose-200/60 px-1 py-0.5 rounded font-mono">
                    <TrendingDown className="w-3 h-3 mr-0.5" />
                    Burn
                  </span>
                )}
              </div>
              <div className="text-[10px] text-slate-400 font-mono">
                {totalBalance > 0 ? 'Deductions applied' : 'Zero balance complete'}
              </div>
            </div>

            {/* Burn-down Sparkline SVG */}
            <div className="w-24 h-7 shrink-0 relative" title={`Outstanding balance burn-down curve`}>
              <svg className="w-full h-full overflow-visible" viewBox="0 0 100 28" preserveAspectRatio="none">
                <defs>
                  <linearGradient id="balanceGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#f43f5e" stopOpacity="0.2" />
                    <stop offset="100%" stopColor="#f43f5e" stopOpacity="0.0" />
                  </linearGradient>
                </defs>
                <path d={balanceSparkline.areaPath} fill="url(#balanceGradient)" />
                <polyline
                  fill="none"
                  stroke={totalBalance > 0 ? '#e11d48' : '#94a3b8'}
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  points={balanceSparkline.points}
                />
                <circle cx="100" cy={balanceSparkline.lastY} r="2.5" fill={totalBalance > 0 ? '#be123c' : '#64748b'} />
              </svg>
            </div>
          </div>
        </div>
      </div>

      {/* Subtle AppSheet Deduction Ribbon */}
      <div className="bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-600">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-slate-700">AppSheet Deduction Summary:</span>
          <span className="font-mono">Prior Audit: <strong className="text-slate-800">{formatCurrency(totalPriorAudit)}</strong></span>
          <span className="text-slate-300">·</span>
          <span className="font-mono">Not Due: <strong className="text-slate-800">{formatCurrency(totalNotDue)}</strong></span>
        </div>
        <div className="text-slate-500 font-mono text-[11px]">
          Formula: <span className="text-indigo-600 font-medium">Balance = Audit Amount − Recovered − Prior Audit − Not Due</span>
        </div>
      </div>
    </div>
  );
};
