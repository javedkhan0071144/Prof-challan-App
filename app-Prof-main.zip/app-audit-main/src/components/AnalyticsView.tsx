import React from 'react';
import { AuditRecord } from '../types';
import { formatCurrency } from '../utils/formatters';
import { BarChart3, CheckCircle2, Clock, AlertTriangle } from 'lucide-react';

interface AnalyticsViewProps {
  records: AuditRecord[];
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({ records }) => {
  // Aggregate by Tehsil
  const tehsilStats = records.reduce((acc, r) => {
    const key = r.tehsil || 'Unknown';
    if (!acc[key]) {
      acc[key] = { audit: 0, recovered: 0, balance: 0, count: 0, verified: 0 };
    }
    acc[key].audit += r.auditAmt || 0;
    acc[key].recovered += r.recovered || 0;
    acc[key].balance += r.balance || 0;
    acc[key].count += 1;
    if (r.verificationStage === '3rd' || r.verified) acc[key].verified += 1;
    return acc;
  }, {} as Record<string, { audit: number; recovered: number; balance: number; count: number; verified: number }>);

  // Aggregate by Circle
  const circleStats = records.reduce((acc, r) => {
    const key = `${r.circle} (${r.tehsil})`;
    if (!acc[key]) {
      acc[key] = { circle: r.circle, tehsil: r.tehsil, audit: 0, recovered: 0, balance: 0, count: 0, verified: 0 };
    }
    acc[key].audit += r.auditAmt || 0;
    acc[key].recovered += r.recovered || 0;
    acc[key].balance += r.balance || 0;
    acc[key].count += 1;
    if (r.verificationStage === '3rd' || r.verified) acc[key].verified += 1;
    return acc;
  }, {} as Record<string, { circle: string; tehsil: string; audit: number; recovered: number; balance: number; count: number; verified: number }>);

  // Aggregate by Audit Para
  const paraStats = records.reduce((acc, r) => {
    const key = r.paraNo || 'Para-General';
    if (!acc[key]) {
      acc[key] = { paraNo: key, details: r.details || key, audit: 0, recovered: 0, balance: 0, count: 0, verified: 0 };
    }
    acc[key].audit += r.auditAmt || 0;
    acc[key].recovered += r.recovered || 0;
    acc[key].balance += r.balance || 0;
    acc[key].count += 1;
    if (r.verificationStage === '3rd' || r.verified) acc[key].verified += 1;
    return acc;
  }, {} as Record<string, { paraNo: string; details: string; audit: number; recovered: number; balance: number; count: number; verified: number }>);

  // Top outstanding balances
  const topDelinquent = [...records]
    .filter(r => r.balance > 0)
    .sort((a, b) => b.balance - a.balance)
    .slice(0, 5);

  return (
    <div className="space-y-6">
      {/* Overview Intro */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-indigo-600" />
            Circle & Jurisdiction Recovery Performance
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Real-time reconciliation of assessed property taxes, recovery percentages, and pending audit verifications.
          </p>
        </div>
        <div className="flex items-center gap-3 text-xs font-mono">
          <div className="bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-lg">
            <span className="text-slate-500">Total Circles:</span>{' '}
            <strong className="text-slate-900">{Object.keys(circleStats).length}</strong>
          </div>
          <div className="bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-lg">
            <span className="text-slate-500">Total Tehsils:</span>{' '}
            <strong className="text-slate-900">{Object.keys(tehsilStats).length}</strong>
          </div>
        </div>
      </div>

      {/* Tehsil Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {Object.entries(tehsilStats).map(([name, data]) => {
          const rate = data.audit > 0 ? Math.round((data.recovered / data.audit) * 100) : 0;
          return (
            <div key={name} className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Tehsil: {name}</h3>
                  <span className="text-xs text-slate-500 font-mono">
                    {data.count} properties assessed · {data.verified} verified
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-lg font-bold font-mono text-emerald-600">{rate}%</span>
                  <div className="text-[10px] text-slate-400 uppercase">Recovery Rate</div>
                </div>
              </div>

              {/* Progress bar */}
              <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                <div
                  className="bg-emerald-500 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${Math.min(100, rate)}%` }}
                />
              </div>

              <div className="grid grid-cols-3 gap-2 pt-1 text-xs font-mono">
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-sans">Audit Total</span>
                  <span className="font-semibold text-slate-800">{formatCurrency(data.audit)}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-sans">Recovered</span>
                  <span className="font-semibold text-emerald-600">{formatCurrency(data.recovered)}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-sans">Outstanding</span>
                  <span className={`font-semibold ${data.balance > 0 ? 'text-rose-600' : 'text-slate-500'}`}>
                    {formatCurrency(data.balance)}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Circle Detailed Grid */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
            Circle-Wise Audit Ledger Breakdown
          </span>
          <span className="text-xs text-slate-500 font-mono">
            {records.length} Total Properties Tracked
          </span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-white text-slate-600 font-semibold border-b border-slate-200 uppercase text-[10px]">
              <tr>
                <th className="py-2.5 px-4">Circle Name</th>
                <th className="py-2.5 px-4">Tehsil</th>
                <th className="py-2.5 px-4 text-center">Properties</th>
                <th className="py-2.5 px-4 text-right">Audit Assessment</th>
                <th className="py-2.5 px-4 text-right">Recovered</th>
                <th className="py-2.5 px-4 text-right">Outstanding Balance</th>
                <th className="py-2.5 px-4 text-center">Recovery %</th>
                <th className="py-2.5 px-4 text-center">Verification</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono">
              {Object.values(circleStats).map((item, idx) => {
                const circleRate = item.audit > 0 ? Math.round((item.recovered / item.audit) * 100) : 0;
                return (
                  <tr key={idx} className="hover:bg-slate-50">
                    <td className="py-2.5 px-4 font-bold font-sans text-indigo-900">{item.circle}</td>
                    <td className="py-2.5 px-4 font-sans text-slate-600">{item.tehsil}</td>
                    <td className="py-2.5 px-4 text-center text-slate-800">{item.count}</td>
                    <td className="py-2.5 px-4 text-right font-medium text-slate-800">{formatCurrency(item.audit)}</td>
                    <td className="py-2.5 px-4 text-right font-medium text-emerald-600">{formatCurrency(item.recovered)}</td>
                    <td className={`py-2.5 px-4 text-right font-bold ${item.balance > 0 ? 'text-rose-600' : 'text-slate-400'}`}>
                      {formatCurrency(item.balance)}
                    </td>
                    <td className="py-2.5 px-4 text-center font-bold text-emerald-700">
                      {circleRate}%
                    </td>
                    <td className="py-2.5 px-4 text-center font-sans text-slate-600">
                      {item.verified} / {item.count}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Top Outstanding Due Delinquencies */}
      {topDelinquent.length > 0 && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 space-y-3">
          <div className="flex items-center gap-2 text-rose-700">
            <AlertTriangle className="w-4 h-4" />
            <h3 className="text-sm font-bold text-slate-900">
              Top Outstanding Tax Assessments Requiring Action
            </h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {topDelinquent.map(r => (
              <div key={r.id} className="p-3 bg-rose-50/40 border border-rose-200/80 rounded-lg space-y-1 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-mono font-bold text-indigo-700">{r.propertyNo}</span>
                  <span className="font-mono font-bold text-rose-600">{formatCurrency(r.balance)}</span>
                </div>
                <div className="text-slate-700 font-medium truncate">{r.owner}</div>
                <div className="text-[11px] text-slate-500 font-mono">
                  {r.tehsil} / {r.circle} · Audit: {formatCurrency(r.auditAmt)}
                </div>
                {r.remarks && (
                  <div className="text-[10px] text-slate-500 truncate pt-1 border-t border-rose-100">
                    {r.remarks}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
