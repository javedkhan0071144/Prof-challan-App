export type VerificationStage = 'pending' | '1st' | '2nd' | '3rd';

export interface AuditRecord {
  id: number;
  details: string;       // e.g. "6-Petrol Pump"
  paraNo: string;        // e.g. "Para-6"
  district: string;      // e.g. "RWP"
  tehsil: string;        // e.g. "GK", "Taxila"
  circle: string;        // e.g. "GKB-II", "Taxila", "GKB-III"
  propertyNo: string;    // e.g. "468-A-12/Pump"
  owner: string;         // e.g. "A1"
  auditSrNo: number;     // e.g. 17
  auditAmt: number;      // e.g. 423367
  recovered: number;     // e.g. 423367
  priorAudit: number;    // e.g. 0
  notDue: number;        // e.g. 0
  receiptAmt: number;    // e.g. 423367
  balance: number;       // Calculated: auditAmt - recovered - priorAudit - notDue
  date: string;          // e.g. "2026-03-20"
  verified: boolean;     // Backward compatibility flag
  verificationStage: VerificationStage; // 'pending' | '1st' | '2nd' | '3rd'
  firstVerDate?: string;  // 1st Ver Dated
  secondVerDate?: string; // 2nd Ver Dated
  thirdVerDate?: string;  // 3rd Ver Dated
  remarks: string;       // Auditor Remarks
  challanNo?: string;    // Optional challan reference
  updatedAt?: string;    // Timestamp
}

export interface AuditParaInfo {
  paraNo: string;
  title: string;
  description: string;
  category?: 'Commercial' | 'Residential' | 'Institutional' | 'Financial' | 'Industrial' | 'Special' | 'Other';
}

export interface FilterState {
  search: string;
  district: string;
  tehsil: string;
  circle: string;
  paraFilter: string;
  verifiedStatus: 'all' | 'pending' | '1st' | '2nd' | '3rd';
  balanceStatus: 'all' | 'outstanding' | 'settled';
}

export type SortField = 
  | 'id'
  | 'auditSrNo'
  | 'paraNo'
  | 'details'
  | 'propertyNo'
  | 'owner'
  | 'tehsil'
  | 'circle'
  | 'auditAmt'
  | 'recovered'
  | 'priorAudit'
  | 'notDue'
  | 'receiptAmt'
  | 'balance'
  | 'date'
  | 'remarks'
  | 'verified';

export type SortOrder = 'asc' | 'desc';
