import { AuditRecord } from '../types';

export function formatCurrency(amount: number | undefined | null): string {
  const val = Number(amount) || 0;
  return 'Rs. ' + Math.round(val).toLocaleString('en-US');
}

export function formatNumber(val: number | undefined | null): string {
  return (Number(val) || 0).toLocaleString('en-US');
}

export function calculateBalance(
  auditAmt: number,
  recovered: number,
  priorAudit: number,
  notDue: number
): number {
  const audit = Number(auditAmt) || 0;
  const rec = Number(recovered) || 0;
  const prior = Number(priorAudit) || 0;
  const nd = Number(notDue) || 0;
  return audit - rec - prior - nd;
}

export function exportRecordsToCSV(records: AuditRecord[], filename = 'Audit_AppSheet_Export.csv') {
  const headers = [
    "Sr/No-ID",
    "Para Details",
    "Para No",
    "District",
    "Tehsil",
    "Circle Name",
    "Property No",
    "Owners Name",
    "Audit Sr No",
    "Audit Amt",
    "Recovered",
    "Prior to Audit",
    "Not Due Amount",
    "Receipt Amt",
    "Date",
    "Balance",
    "Verification Status",
    "1st Ver Dated",
    "2nd Ver Dated",
    "3rd Ver Dated",
    "Challan No",
    "Remarks"
  ];

  const rows = records.map(r => [
    r.id,
    `"${(r.details || '').replace(/"/g, '""')}"`,
    `"${(r.paraNo || '').replace(/"/g, '""')}"`,
    `"${(r.district || '').replace(/"/g, '""')}"`,
    `"${(r.tehsil || '').replace(/"/g, '""')}"`,
    `"${(r.circle || '').replace(/"/g, '""')}"`,
    `"${(r.propertyNo || '').replace(/"/g, '""')}"`,
    `"${(r.owner || '').replace(/"/g, '""')}"`,
    r.auditSrNo || '',
    r.auditAmt || 0,
    r.recovered || 0,
    r.priorAudit || 0,
    r.notDue || 0,
    r.receiptAmt || 0,
    `"${r.date || ''}"`,
    r.balance || 0,
    `"${r.verificationStage || (r.verified ? '3rd' : 'pending')}"`,
    `"${r.firstVerDate || ''}"`,
    `"${r.secondVerDate || ''}"`,
    `"${r.thirdVerDate || ''}"`,
    `"${(r.challanNo || '').replace(/"/g, '""')}"`,
    `"${(r.remarks || '').replace(/"/g, '""')}"`
  ]);

  const csvContent = "\uFEFF" + [headers.join(","), ...rows.map(row => row.join(","))].join("\r\n");
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.setAttribute("href", url);
  link.setAttribute("download", filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Exports only selected records to CSV with complete verification status and audit calculations
 */
export function exportSelectedRecordsToCSV(
  records: AuditRecord[],
  filename?: string
) {
  if (!records || records.length === 0) return;

  const defaultFilename = `Audit_Selected_${records.length}_Records_Verification_Export.csv`;
  const nameToUse = filename || defaultFilename;

  const headers = [
    "Sr/No-ID",
    "Audit Sr No",
    "Audit Para No",
    "Audit Para Name",
    "District",
    "Tehsil",
    "Circle Name",
    "Property No",
    "Owners Name",
    "Challan / Scroll No",
    "Payment Date",
    "Audit Assessed Amount (Rs.)",
    "Recovered Amount (Rs.)",
    "Prior to Audit Amount (Rs.)",
    "Not Due Amount (Rs.)",
    "Receipt Amount Presented (Rs.)",
    "Net Balance Due (Rs.)",
    "Recovery Rate (%)",
    "Settlement Classification",
    "Total Relief & Deductions (Rs.)",
    "Current Verification Status",
    "Verification Stage Code",
    "1st Ver Dated",
    "2nd Ver Dated",
    "3rd Ver Dated",
    "Auditor Remarks"
  ];

  const rows = records.map((r) => {
    const stage = r.verificationStage || (r.verified ? '3rd' : 'pending');
    let stageLabel = 'Pending Verification';
    if (stage === '3rd') stageLabel = '3rd Ver (Final Approved)';
    else if (stage === '2nd') stageLabel = '2nd Ver (Re-checked)';
    else if (stage === '1st') stageLabel = '1st Ver (Initial OK)';

    const auditAmt = Number(r.auditAmt) || 0;
    const recovered = Number(r.recovered) || 0;
    const prior = Number(r.priorAudit) || 0;
    const notDue = Number(r.notDue) || 0;
    const balance = Number(
      r.balance !== undefined
        ? r.balance
        : calculateBalance(auditAmt, recovered, prior, notDue)
    );
    const recoveryRate =
      auditAmt > 0 ? ((recovered / auditAmt) * 100).toFixed(2) + '%' : '0.00%';
    const settlementStatus =
      balance <= 0
        ? 'Fully Settled / Reconciled'
        : recovered > 0
        ? 'Partially Recovered'
        : 'Unrecovered Outstanding';
    const deductions = prior + notDue;

    return [
      r.id,
      r.auditSrNo ?? r.id,
      `"${(r.paraNo || '').replace(/"/g, '""')}"`,
      `"${(r.details || '').replace(/"/g, '""')}"`,
      `"${(r.district || '').replace(/"/g, '""')}"`,
      `"${(r.tehsil || '').replace(/"/g, '""')}"`,
      `"${(r.circle || '').replace(/"/g, '""')}"`,
      `"${(r.propertyNo || '').replace(/"/g, '""')}"`,
      `"${(r.owner || '').replace(/"/g, '""')}"`,
      `"${(r.challanNo || '').replace(/"/g, '""')}"`,
      `"${r.date || ''}"`,
      auditAmt,
      recovered,
      prior,
      notDue,
      Number(r.receiptAmt) || 0,
      balance,
      `"${recoveryRate}"`,
      `"${settlementStatus}"`,
      deductions,
      `"${stageLabel}"`,
      `"${stage}"`,
      `"${r.firstVerDate || ''}"`,
      `"${r.secondVerDate || ''}"`,
      `"${r.thirdVerDate || ''}"`,
      `"${(r.remarks || '').replace(/"/g, '""')}"`
    ];
  });

  // Calculate grand totals summary for the selected records
  const sumAudit = records.reduce((acc, r) => acc + (Number(r.auditAmt) || 0), 0);
  const sumRecovered = records.reduce((acc, r) => acc + (Number(r.recovered) || 0), 0);
  const sumPrior = records.reduce((acc, r) => acc + (Number(r.priorAudit) || 0), 0);
  const sumNotDue = records.reduce((acc, r) => acc + (Number(r.notDue) || 0), 0);
  const sumReceipts = records.reduce((acc, r) => acc + (Number(r.receiptAmt) || 0), 0);
  const sumBalance = records.reduce((acc, r) => acc + (Number(r.balance) || 0), 0);
  const totalRecoveryRate =
    sumAudit > 0 ? ((sumRecovered / sumAudit) * 100).toFixed(2) + '%' : '0.00%';

  const summaryRow = [
    `"TOTALS (${records.length} SELECTED RECORDS)"`,
    '""',
    '""',
    '""',
    '""',
    '""',
    '""',
    '""',
    '""',
    '""',
    '""',
    sumAudit,
    sumRecovered,
    sumPrior,
    sumNotDue,
    sumReceipts,
    sumBalance,
    `"${totalRecoveryRate}"`,
    sumBalance <= 0 ? '"All Selected Settled"' : '"Outstanding Balance Pending"',
    sumPrior + sumNotDue,
    '""',
    '""',
    '""',
    '""',
    '""',
    `"Exported on ${new Date().toLocaleString()}"`
  ];

  const csvContent =
    "\uFEFF" +
    [headers.join(","), ...rows.map((row) => row.join(",")), summaryRow.join(",")].join(
      "\r\n"
    );
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.setAttribute("href", url);
  link.setAttribute("download", nameToUse);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function exportAccountsOfficeReportToCSV(records: AuditRecord[], filename = 'Accounts_Office_Verification_Report.csv') {
  const headers = [
    "Sr/No-ID",
    "Audit Para No",
    "Audit Para Name",
    "District",
    "Tehsil",
    "Circle Name",
    "Property No",
    "Taxpayer / Owner",
    "Challan / Scroll No",
    "Payment Date",
    "Audit Amount",
    "Receipt Amount",
    "Recovered",
    "Prior to Audit",
    "Not Due Amount",
    "Balance Due",
    "Verification Stage",
    "1st Ver Dated",
    "2nd Ver Dated",
    "3rd Ver Dated",
    "Accounts Verification Status",
    "Remarks"
  ];

  const rows = records.map(r => {
    const stage = r.verificationStage || (r.verified ? '3rd' : 'pending');
    let accountsStatus = 'Pending Verification';
    if (stage === '3rd') accountsStatus = 'Fully Reconciled & Approved';
    else if (stage === '2nd') accountsStatus = '2nd Stage Verified';
    else if (stage === '1st') accountsStatus = '1st Stage Verified';

    return [
      r.id,
      `"${(r.paraNo || '').replace(/"/g, '""')}"`,
      `"${(r.details || '').replace(/"/g, '""')}"`,
      `"${(r.district || '').replace(/"/g, '""')}"`,
      `"${(r.tehsil || '').replace(/"/g, '""')}"`,
      `"${(r.circle || '').replace(/"/g, '""')}"`,
      `"${(r.propertyNo || '').replace(/"/g, '""')}"`,
      `"${(r.owner || '').replace(/"/g, '""')}"`,
      `"${(r.challanNo || '').replace(/"/g, '""')}"`,
      `"${r.date || ''}"`,
      r.auditAmt || 0,
      r.receiptAmt || 0,
      r.recovered || 0,
      r.priorAudit || 0,
      r.notDue || 0,
      r.balance || 0,
      `"${stage}"`,
      `"${r.firstVerDate || ''}"`,
      `"${r.secondVerDate || ''}"`,
      `"${r.thirdVerDate || ''}"`,
      `"${accountsStatus}"`,
      `"${(r.remarks || '').replace(/"/g, '""')}"`
    ];
  });

  const csvContent = "\uFEFF" + [headers.join(","), ...rows.map(row => row.join(","))].join("\r\n");
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.setAttribute("href", url);
  link.setAttribute("download", filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function parseCSVToRecords(csvText: string, startingId: number): AuditRecord[] {
  const lines = csvText.trim().split(/\r?\n/).filter(l => l.trim().length > 0);
  if (lines.length < 2) return [];

  // Check header row
  const dataLines = lines.slice(1);
  const records: AuditRecord[] = [];
  let currentId = startingId;

  for (const line of dataLines) {
    // Parse CSV line handling quotes
    const values: string[] = [];
    let insideQuote = false;
    let currentValue = '';

    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      if (char === '"') {
        if (insideQuote && line[i + 1] === '"') {
          currentValue += '"';
          i++; // skip escaped quote
        } else {
          insideQuote = !insideQuote;
        }
      } else if (char === ',' && !insideQuote) {
        values.push(currentValue.trim());
        currentValue = '';
      } else {
        currentValue += char;
      }
    }
    values.push(currentValue.trim());

    if (values.length < 5) continue; // Skip incomplete lines

    // Try to map columns gracefully
    const idVal = parseInt(values[0], 10);
    const validId = !isNaN(idVal) && idVal > 0 ? idVal : currentId++;

    const details = values[1] || "6-Petrol Pump";
    const paraNo = values[2] || "Para-6";
    const district = values[3] || "RWP";
    const tehsil = values[4] || "GK";
    const circle = values[5] || "GKB-II";
    const propertyNo = values[6] || `Prop-${validId}`;
    const owner = values[7] || "Owner";
    const auditSrNo = parseInt(values[8], 10) || validId;
    const auditAmt = parseFloat(values[9]?.replace(/[^0-9.-]/g, '')) || 0;
    const recovered = parseFloat(values[10]?.replace(/[^0-9.-]/g, '')) || 0;
    const priorAudit = parseFloat(values[11]?.replace(/[^0-9.-]/g, '')) || 0;
    const notDue = parseFloat(values[12]?.replace(/[^0-9.-]/g, '')) || 0;
    const receiptAmt = parseFloat(values[13]?.replace(/[^0-9.-]/g, '')) || 0;
    const date = values[14] || "";
    const balance = calculateBalance(auditAmt, recovered, priorAudit, notDue);
    const stageRaw = (values[16] || '').toLowerCase();
    let verificationStage: 'pending' | '1st' | '2nd' | '3rd' = 'pending';
    if (stageRaw.includes('3') || stageRaw === 'yes' || stageRaw === 'verified') verificationStage = '3rd';
    else if (stageRaw.includes('2')) verificationStage = '2nd';
    else if (stageRaw.includes('1')) verificationStage = '1st';

    const firstVerDate = values[17] || "";
    const secondVerDate = values[18] || "";
    const thirdVerDate = values[19] || "";
    const challanNo = values[20] || "";
    const remarks = values[21] || values[15] || "";

    records.push({
      id: validId,
      details,
      paraNo,
      district,
      tehsil,
      circle,
      propertyNo,
      owner,
      auditSrNo,
      auditAmt,
      recovered,
      priorAudit,
      notDue,
      receiptAmt,
      date,
      balance,
      verified: verificationStage === '3rd',
      verificationStage,
      firstVerDate,
      secondVerDate,
      thirdVerDate,
      remarks,
      challanNo,
      updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 16)
    });
  }

  return records;
}
