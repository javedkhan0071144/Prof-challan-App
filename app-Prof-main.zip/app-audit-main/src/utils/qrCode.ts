import QRCode from 'qrcode';
import { AuditRecord } from '../types';

/**
 * Builds the secure public-facing verification URL for a property record
 */
export function getVerificationUrl(record: AuditRecord): string {
  const origin = window.location.origin || '';
  const pathname = window.location.pathname || '';
  const propClean = encodeURIComponent(record.propertyNo);
  return `${origin}${pathname}?verify=${record.id}&prop=${propClean}`;
}

/**
 * Generates an official digital verification fingerprint token for audit tracking
 */
export function getVerificationFingerprint(record: AuditRecord): string {
  const idHex = Number(record.id).toString(16).padStart(4, '0').toUpperCase();
  const amtHex = Math.round(Number(record.auditAmt || 0)).toString(16).toUpperCase();
  const recHex = Math.round(Number(record.recovered || 0)).toString(16).toUpperCase();
  const cleanProp = (record.propertyNo || '').replace(/[^a-zA-Z0-9]/g, '').slice(0, 6).toUpperCase();
  return `ETNC-PK-${record.district || 'RWP'}-${cleanProp}-${idHex}-${amtHex}${recHex}`;
}

/**
 * Generates high-resolution QR code data URL (PNG format)
 */
export async function generateQRCode(url: string, width = 260): Promise<string> {
  try {
    return await QRCode.toDataURL(url, {
      width,
      margin: 1.5,
      color: {
        dark: '#1e1b4b', // deep indigo
        light: '#ffffff',
      },
      errorCorrectionLevel: 'M',
    });
  } catch (err) {
    console.error('Failed to generate QR code:', err);
    return '';
  }
}
