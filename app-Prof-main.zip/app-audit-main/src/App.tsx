/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { AuditRecord, FilterState, SortField, SortOrder } from './types';
import { INITIAL_RECORDS, STORAGE_KEY } from './data/initialRecords';
import { exportRecordsToCSV, exportSelectedRecordsToCSV, exportAccountsOfficeReportToCSV, calculateBalance, formatCurrency } from './utils/formatters';
import { Header } from './components/Header';
import { SummaryMetrics } from './components/SummaryMetrics';
import { FilterToolbar } from './components/FilterToolbar';
import { AuditTable } from './components/AuditTable';
import { RecordModal } from './components/RecordModal';
import { CsvImportModal } from './components/CsvImportModal';
import { AuditReportModal } from './components/AuditReportModal';
import { AccountsOfficeReportModal } from './components/AccountsOfficeReportModal';
import { ReceiptVoucherModal } from './components/ReceiptVoucherModal';
import { QRCodeModal } from './components/QRCodeModal';
import { PublicVerificationView } from './components/PublicVerificationView';
import { AnalyticsView } from './components/AnalyticsView';
import { CheckCircle2, Clock, Trash2, Download, X, Printer, ShieldCheck, FileSpreadsheet, Building2, Search } from 'lucide-react';

export default function App() {
  // Load records from LocalStorage or use INITIAL_RECORDS
  const [records, setRecords] = useState<AuditRecord[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch {
      // Fallback if parsing fails
    }
    return INITIAL_RECORDS;
  });

  // Sync to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
    } catch (err) {
      console.error('Failed to save to localStorage:', err);
    }
  }, [records]);

  // Main UI Navigation Tab
  const [activeTab, setActiveTab] = useState<'ledger' | 'analytics' | 'report'>('ledger');

  // Filter State
  const [filter, setFilter] = useState<FilterState>({
    search: '',
    district: '',
    tehsil: '',
    circle: '',
    verifiedStatus: 'all',
    balanceStatus: 'all',
  });

  // Sort State
  const [sortField, setSortField] = useState<SortField>('id');
  const [sortOrder, setSortOrder] = useState<SortOrder>('asc');

  // Row Selection State
  const [selectedIds, setSelectedIds] = useState<number[]>([]);

  // Modal States
  const [isRecordModalOpen, setIsRecordModalOpen] = useState<boolean>(false);
  const [recordToEdit, setRecordToEdit] = useState<AuditRecord | null>(null);
  const [isImportModalOpen, setIsImportModalOpen] = useState<boolean>(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState<boolean>(false);
  const [isAccountsOfficeModalOpen, setIsAccountsOfficeModalOpen] = useState<boolean>(false);
  const [activeReportSubTab, setActiveReportSubTab] = useState<'accounts' | 'standard'>('accounts');
  const [accountsReportStageFilter, setAccountsReportStageFilter] = useState<'all' | 'pending' | '1st' | '2nd' | '3rd'>('all');
  const [accountsReportSearch, setAccountsReportSearch] = useState<string>('');
  const [isVoucherModalOpen, setIsVoucherModalOpen] = useState<boolean>(false);
  const [selectedVoucherRecord, setSelectedVoucherRecord] = useState<AuditRecord | null>(null);

  // QR Code & Public Verification States
  const [isQRCodeModalOpen, setIsQRCodeModalOpen] = useState<boolean>(false);
  const [selectedQRRecord, setSelectedQRRecord] = useState<AuditRecord | null>(null);
  const [publicVerificationRecord, setPublicVerificationRecord] = useState<AuditRecord | null>(null);

  // Check URL parameters for direct public verification navigation (?verify=ID)
  useEffect(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      const verifyId = params.get('verify') || params.get('id');
      const verifyProp = params.get('prop');
      if (verifyId || verifyProp) {
        const found = records.find(
          (r) =>
            (verifyId && r.id.toString() === verifyId) ||
            (verifyProp && r.propertyNo.toLowerCase() === verifyProp.toLowerCase())
        );
        if (found) {
          setPublicVerificationRecord(found);
        }
      }
    } catch {}
  }, [records]);

  // Computed next ID
  const nextId = useMemo(() => {
    return records.length > 0 ? Math.max(...records.map((r) => r.id)) + 1 : 1;
  }, [records]);

  // Filtered accounts office report records for interactive view
  const accountsReportRecords = useMemo(() => {
    return records.filter((r) => {
      const stage = r.verificationStage || (r.verified ? '3rd' : 'pending');
      if (accountsReportStageFilter !== 'all' && stage !== accountsReportStageFilter) return false;
      if (accountsReportSearch.trim()) {
        const q = accountsReportSearch.toLowerCase();
        const match =
          r.propertyNo.toLowerCase().includes(q) ||
          r.owner.toLowerCase().includes(q) ||
          r.id.toString().includes(q) ||
          (r.challanNo && r.challanNo.toLowerCase().includes(q)) ||
          (r.details && r.details.toLowerCase().includes(q)) ||
          (r.circle && r.circle.toLowerCase().includes(q));
        if (!match) return false;
      }
      return true;
    });
  }, [records, accountsReportStageFilter, accountsReportSearch]);

  const accTotalAudit = accountsReportRecords.reduce((acc, r) => acc + (r.auditAmt || 0), 0);
  const accTotalReceipts = accountsReportRecords.reduce((acc, r) => acc + (r.receiptAmt || 0), 0);
  const accTotalRecovered = accountsReportRecords.reduce((acc, r) => acc + (r.recovered || 0), 0);
  const accTotalPriorAndNotDue = accountsReportRecords.reduce((acc, r) => acc + (r.priorAudit || 0) + (r.notDue || 0), 0);
  const accTotalBalance = accountsReportRecords.reduce((acc, r) => acc + (r.balance || 0), 0);

  // Unique Dropdown Options
  const districts = useMemo(() => {
    return Array.from(new Set(records.map((r) => r.district).filter(Boolean))).sort();
  }, [records]);

  const tehsils = useMemo(() => {
    return Array.from(new Set(records.map((r) => r.tehsil).filter(Boolean))).sort();
  }, [records]);

  const circles = useMemo(() => {
    return Array.from(new Set(records.map((r) => r.circle).filter(Boolean))).sort();
  }, [records]);

  // Filtered Records
  const filteredRecords = useMemo(() => {
    const q = filter.search.toLowerCase().trim();

    return records.filter((r) => {
      // Search matching
      if (q) {
        const matchesSearch =
          r.propertyNo.toLowerCase().includes(q) ||
          r.owner.toLowerCase().includes(q) ||
          r.id.toString().includes(q) ||
          (r.circle && r.circle.toLowerCase().includes(q)) ||
          (r.details && r.details.toLowerCase().includes(q)) ||
          (r.paraNo && r.paraNo.toLowerCase().includes(q)) ||
          (r.remarks && r.remarks.toLowerCase().includes(q));

        if (!matchesSearch) return false;
      }

      // District
      if (filter.district && r.district !== filter.district) return false;

      // Tehsil
      if (filter.tehsil && r.tehsil !== filter.tehsil) return false;

      // Circle
      if (filter.circle && r.circle !== filter.circle) return false;

      // Verification stage filter
      if (filter.verifiedStatus !== 'all') {
        const stage = r.verificationStage || (r.verified ? '3rd' : 'pending');
        if (filter.verifiedStatus !== stage) return false;
      }

      // Balance status
      if (filter.balanceStatus === 'outstanding' && (r.balance || 0) <= 0) return false;
      if (filter.balanceStatus === 'settled' && (r.balance || 0) !== 0) return false;

      return true;
    });
  }, [records, filter]);

  // Sorted Records
  const sortedRecords = useMemo(() => {
    return [...filteredRecords].sort((a, b) => {
      let aVal = a[sortField];
      let bVal = b[sortField];

      if (typeof aVal === 'string') {
        aVal = aVal.toLowerCase();
        bVal = ((bVal as string) || '').toLowerCase();
      }

      if (aVal === undefined || aVal === null) aVal = '';
      if (bVal === undefined || bVal === null) bVal = '';

      if (aVal < bVal) return sortOrder === 'asc' ? -1 : 1;
      if (aVal > bVal) return sortOrder === 'asc' ? 1 : -1;
      return 0;
    });
  }, [filteredRecords, sortField, sortOrder]);

  // Sorting Toggle Handler
  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortOrder('asc');
    }
  };

  // Selection Handlers
  const handleToggleSelect = (id: number) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleToggleSelectAll = () => {
    if (selectedIds.length === sortedRecords.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(sortedRecords.map((r) => r.id));
    }
  };

  // CRUD Operations
  const handleOpenAddModal = () => {
    setRecordToEdit(null);
    setIsRecordModalOpen(true);
  };

  const handleEditRecord = (record: AuditRecord) => {
    setRecordToEdit(record);
    setIsRecordModalOpen(true);
  };

  const handleSaveRecord = (savedRecord: AuditRecord) => {
    setRecords((prev) => {
      const exists = prev.some((r) => r.id === savedRecord.id);
      if (exists) {
        return prev.map((r) => (r.id === savedRecord.id ? savedRecord : r));
      } else {
        return [...prev, savedRecord];
      }
    });
  };

  const handleDuplicateRecord = (record: AuditRecord) => {
    const duplicated: AuditRecord = {
      ...record,
      id: nextId,
      auditSrNo: nextId,
      propertyNo: `${record.propertyNo}-COPY`,
      challanNo: `CH-2026-${String(nextId).padStart(3, '0')}`,
      updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
    };
    setRecords((prev) => [...prev, duplicated]);
  };

  const handleUpdateRecordField = (id: number, updates: Partial<AuditRecord>) => {
    setRecords((prev) =>
      prev.map((r) => {
        if (r.id !== id) return r;
        const updated = {
          ...r,
          ...updates,
          updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
        };
        // Auto-recalculate balance if financial columns were updated without explicit balance
        if (
          ('auditAmt' in updates || 'recovered' in updates || 'priorAudit' in updates || 'notDue' in updates) &&
          !('balance' in updates)
        ) {
          updated.balance = calculateBalance(
            updated.auditAmt,
            updated.recovered,
            updated.priorAudit,
            updated.notDue
          );
        }
        return updated;
      })
    );
  };

  const handleDeleteRecord = (id: number) => {
    if (window.confirm(`Are you sure you want to delete audit record #${id}?`)) {
      setRecords((prev) => prev.filter((r) => r.id !== id));
      setSelectedIds((prev) => prev.filter((item) => item !== id));
    }
  };

  const handleToggleVerified = (record: AuditRecord) => {
    const today = new Date().toISOString().split('T')[0];
    const currentStage = record.verificationStage || (record.verified ? '3rd' : 'pending');

    let nextStage: 'pending' | '1st' | '2nd' | '3rd' = '1st';
    let firstVerDate = record.firstVerDate;
    let secondVerDate = record.secondVerDate;
    let thirdVerDate = record.thirdVerDate;
    let verified = false;

    if (currentStage === 'pending') {
      nextStage = '1st';
      firstVerDate = firstVerDate || today;
    } else if (currentStage === '1st') {
      nextStage = '2nd';
      secondVerDate = secondVerDate || today;
    } else if (currentStage === '2nd') {
      nextStage = '3rd';
      thirdVerDate = thirdVerDate || today;
      verified = true;
    } else {
      nextStage = 'pending';
      verified = false;
    }

    setRecords((prev) =>
      prev.map((r) => {
        if (r.id === record.id) {
          return {
            ...r,
            verificationStage: nextStage,
            firstVerDate,
            secondVerDate,
            thirdVerDate,
            verified,
            updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
          };
        }
        return r;
      })
    );
  };

  const handleViewVoucher = (record: AuditRecord) => {
    setSelectedVoucherRecord(record);
    setIsVoucherModalOpen(true);
  };

  const handleShowQRCode = (record: AuditRecord) => {
    setSelectedQRRecord(record);
    setIsQRCodeModalOpen(true);
  };

  const handleOpenPublicView = (record: AuditRecord) => {
    setPublicVerificationRecord(record);
    try {
      const url = new URL(window.location.href);
      url.searchParams.set('verify', record.id.toString());
      url.searchParams.set('prop', record.propertyNo);
      window.history.pushState({}, '', url.toString());
    } catch {}
  };

  const handleBackFromPublicView = () => {
    setPublicVerificationRecord(null);
    try {
      const url = new URL(window.location.href);
      url.searchParams.delete('verify');
      url.searchParams.delete('prop');
      url.searchParams.delete('id');
      window.history.pushState({}, '', url.pathname + (url.search || ''));
    } catch {}
  };

  // Bulk Operations
  const handleBulkSetStage = (stage: 'pending' | '1st' | '2nd' | '3rd') => {
    const today = new Date().toISOString().split('T')[0];
    setRecords((prev) =>
      prev.map((r) => {
        if (selectedIds.includes(r.id)) {
          return {
            ...r,
            verificationStage: stage,
            firstVerDate: stage === '1st' ? (r.firstVerDate || today) : r.firstVerDate,
            secondVerDate: stage === '2nd' ? (r.secondVerDate || today) : r.secondVerDate,
            thirdVerDate: stage === '3rd' ? (r.thirdVerDate || today) : r.thirdVerDate,
            verified: stage === '3rd',
            updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
          };
        }
        return r;
      })
    );
  };

  const handleBulkDelete = () => {
    if (
      window.confirm(
        `Are you sure you want to delete ${selectedIds.length} selected record(s)?`
      )
    ) {
      setRecords((prev) => prev.filter((r) => !selectedIds.includes(r.id)));
      setSelectedIds([]);
    }
  };

  const handleBulkExport = () => {
    const toExport = records.filter((r) => selectedIds.includes(r.id));
    if (toExport.length === 0) return;
    exportSelectedRecordsToCSV(
      toExport,
      `Audit_Selected_${toExport.length}_Records_Verification.csv`
    );
  };

  // Import Handler
  const handleImport = (imported: AuditRecord[], mode: 'append' | 'replace') => {
    if (mode === 'replace') {
      setRecords(imported);
    } else {
      setRecords((prev) => [...prev, ...imported]);
    }
    setSelectedIds([]);
  };

  // Reset Data Handler
  const handleResetData = () => {
    if (
      window.confirm(
        'Reset audit database to the standard sample dataset? Current modifications will be replaced.'
      )
    ) {
      setRecords(INITIAL_RECORDS);
      setSelectedIds([]);
      setFilter({
        search: '',
        district: '',
        tehsil: '',
        circle: '',
        verifiedStatus: 'all',
        balanceStatus: 'all',
      });
    }
  };

  const handleResetFilters = () => {
    setFilter({
      search: '',
      district: '',
      tehsil: '',
      circle: '',
      verifiedStatus: 'all',
      balanceStatus: 'all',
    });
  };

  // If a public verification view is requested (via QR scan or button)
  if (publicVerificationRecord) {
    return (
      <PublicVerificationView
        record={publicVerificationRecord}
        onBack={handleBackFromPublicView}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800 antialiased flex flex-col font-sans">
      {/* Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenAddModal={handleOpenAddModal}
        onOpenImportModal={() => setIsImportModalOpen(true)}
        onExportCSV={() => exportRecordsToCSV(records)}
        onResetData={handleResetData}
        totalRecords={records.length}
        selectedCount={selectedIds.length}
        onExportSelected={handleBulkExport}
      />

      {/* Main View Area */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 w-full flex-1 space-y-6">
        {/* Metric Dashboard */}
        <SummaryMetrics records={records} filteredRecords={filteredRecords} />

        {/* View Switcher: Ledger Table vs Analytics vs Report */}
        {activeTab === 'ledger' && (
          <div className="space-y-4">
            {/* Search and Filters Toolbar */}
            <FilterToolbar
              filter={filter}
              setFilter={setFilter}
              districts={districts}
              tehsils={tehsils}
              circles={circles}
              totalCount={records.length}
              filteredCount={filteredRecords.length}
              onResetFilters={handleResetFilters}
            />

            {/* Bulk Selection Action Bar */}
            {selectedIds.length > 0 && (
              <div className="bg-indigo-900 text-white rounded-xl px-4 py-3 flex flex-wrap items-center justify-between gap-3 shadow-md animate-fade-in">
                <div className="flex items-center gap-2 text-xs">
                  <span className="font-bold font-mono bg-indigo-700 px-2 py-0.5 rounded text-white">
                    {selectedIds.length}
                  </span>
                  <span>records selected</span>
                </div>
                <div className="flex flex-wrap items-center gap-1.5 text-xs">
                  <span className="text-indigo-200 text-[11px] mr-1 hidden sm:inline">Set Stage:</span>
                  <button
                    onClick={() => handleBulkSetStage('1st')}
                    title="Mark selected as 1st Verification (Dated today)"
                    className="px-2.5 py-1 bg-blue-700 hover:bg-blue-600 text-white rounded-lg flex items-center gap-1 font-semibold transition"
                  >
                    <span>1st Ver</span>
                  </button>
                  <button
                    onClick={() => handleBulkSetStage('2nd')}
                    title="Mark selected as 2nd Verification (Dated today)"
                    className="px-2.5 py-1 bg-indigo-700 hover:bg-indigo-600 text-white rounded-lg flex items-center gap-1 font-semibold transition"
                  >
                    <span>2nd Ver</span>
                  </button>
                  <button
                    onClick={() => handleBulkSetStage('3rd')}
                    title="Mark selected as 3rd Verification / Final Approval (Dated today)"
                    className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg flex items-center gap-1 font-semibold transition"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-200" />
                    <span>3rd Ver (Final)</span>
                  </button>
                  <button
                    onClick={() => handleBulkSetStage('pending')}
                    title="Reset selected to Pending verification"
                    className="px-2.5 py-1 bg-amber-600/80 hover:bg-amber-600 text-white rounded-lg flex items-center gap-1 font-semibold transition"
                  >
                    <Clock className="w-3.5 h-3.5 text-amber-200" />
                    <span>Pending</span>
                  </button>
                  <span className="text-indigo-400 mx-1">|</span>
                  <button
                    onClick={handleBulkExport}
                    title="Export only selected records to CSV including current verification status and audit calculations"
                    className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg flex items-center gap-1.5 font-bold transition shadow-xs cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Export Selected ({selectedIds.length}) to CSV</span>
                  </button>
                  <button
                    onClick={handleBulkDelete}
                    className="px-2.5 py-1 bg-rose-600/80 hover:bg-rose-600 rounded-lg flex items-center gap-1.5 font-medium transition"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete</span>
                  </button>
                  <button
                    onClick={() => setSelectedIds([])}
                    className="p-1 text-indigo-300 hover:text-white rounded-lg transition"
                    title="Clear selection"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {/* Main High-density Data Table */}
            <AuditTable
              records={sortedRecords}
              sortField={sortField}
              sortOrder={sortOrder}
              onSort={handleSort}
              selectedIds={selectedIds}
              onToggleSelect={handleToggleSelect}
              onToggleSelectAll={handleToggleSelectAll}
              onEdit={handleEditRecord}
              onDuplicate={handleDuplicateRecord}
              onDelete={handleDeleteRecord}
              onToggleVerified={handleToggleVerified}
              onViewVoucher={handleViewVoucher}
              onShowQRCode={handleShowQRCode}
              onOpenAddModal={handleOpenAddModal}
              onClearFilters={handleResetFilters}
              isFiltered={filteredRecords.length !== records.length}
              onUpdateRecordField={handleUpdateRecordField}
              onExportSelected={handleBulkExport}
            />
          </div>
        )}

        {activeTab === 'analytics' && <AnalyticsView records={records} />}

        {activeTab === 'report' && (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-4 sm:p-6 space-y-6">
            {/* Top Report Type Switcher Tabs */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
              <div>
                <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Building2 className="w-5 h-5 text-indigo-600" />
                  <span>Audit & Departmental Verification Reports</span>
                </h2>
                <p className="text-xs text-slate-500">
                  Select report format for Accounts Office Treasury verification or Assessment reconciliation
                </p>
              </div>

              {/* Sub-tabs to choose between Accounts Office report and Form 32-A */}
              <div className="inline-flex p-1 bg-slate-100 rounded-xl border border-slate-200 text-xs font-semibold">
                <button
                  type="button"
                  onClick={() => setActiveReportSubTab('accounts')}
                  className={`px-3.5 py-1.5 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
                    activeReportSubTab === 'accounts'
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                  }`}
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Accounts Office Verification</span>
                  <span className="ml-1 text-[10px] px-1.5 py-0.2 bg-emerald-400/30 text-emerald-100 font-bold rounded">
                    DAO
                  </span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveReportSubTab('standard')}
                  className={`px-3.5 py-1.5 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
                    activeReportSubTab === 'standard'
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                  }`}
                >
                  <FileSpreadsheet className="w-4 h-4" />
                  <span>Form 32-A Special Audit</span>
                </button>
              </div>
            </div>

            {/* Sub-report 1: Accounts Office Verification Report */}
            {activeReportSubTab === 'accounts' && (
              <div className="space-y-5">
                {/* Header & Action Bar */}
                <div className="flex flex-wrap items-center justify-between gap-3 bg-indigo-50/50 p-4 rounded-xl border border-indigo-100">
                  <div>
                    <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                      <span>Accounts Office Verification Report (Treasury Schedule)</span>
                    </h3>
                    <p className="text-xs text-slate-600">
                      Reconciliation schedule for District Accounts Office (DAO) & Treasury: includes Receipt Amounts, Payment Dates, Balance Due, and verification stages.
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setIsAccountsOfficeModalOpen(true)}
                      className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold shadow-xs transition flex items-center gap-1.5 cursor-pointer"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>Open Fullscreen Printable Report</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => exportAccountsOfficeReportToCSV(accountsReportRecords)}
                      className="px-3.5 py-2 bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 rounded-lg text-xs font-semibold transition flex items-center gap-1.5 cursor-pointer shadow-2xs"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Export Accounts CSV</span>
                    </button>
                  </div>
                </div>

                {/* Accounts Office Summary Cards */}
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                  <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
                      Audit Assessment
                    </span>
                    <span className="text-sm sm:text-base font-bold font-mono text-slate-800">
                      {formatCurrency(accTotalAudit)}
                    </span>
                    <span className="text-[10px] text-slate-400 block mt-0.5">{accountsReportRecords.length} records</span>
                  </div>
                  <div className="bg-indigo-50/60 p-3 rounded-xl border border-indigo-200 shadow-2xs">
                    <span className="text-[10px] uppercase font-bold text-indigo-700 block tracking-wider">
                      Receipt Amount (Presented)
                    </span>
                    <span className="text-sm sm:text-base font-bold font-mono text-indigo-800">
                      {formatCurrency(accTotalReceipts)}
                    </span>
                    <span className="text-[10px] text-indigo-600 block mt-0.5">Matched with Challans</span>
                  </div>
                  <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
                      Total Recovered
                    </span>
                    <span className="text-sm sm:text-base font-bold font-mono text-emerald-600">
                      {formatCurrency(accTotalRecovered)}
                    </span>
                    <span className="text-[10px] text-emerald-600 block mt-0.5">Bank Credit Confirmed</span>
                  </div>
                  <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
                      Prior & Not Due
                    </span>
                    <span className="text-sm sm:text-base font-bold font-mono text-slate-700">
                      {formatCurrency(accTotalPriorAndNotDue)}
                    </span>
                    <span className="text-[10px] text-slate-400 block mt-0.5">Approved Deductions</span>
                  </div>
                  <div className="bg-rose-50/60 p-3 rounded-xl border border-rose-200 shadow-2xs">
                    <span className="text-[10px] uppercase font-bold text-rose-700 block tracking-wider">
                      Net Balance Due
                    </span>
                    <span className={`text-sm sm:text-base font-bold font-mono ${accTotalBalance > 0 ? 'text-rose-600' : 'text-slate-700'}`}>
                      {formatCurrency(accTotalBalance)}
                    </span>
                    <span className="text-[10px] text-rose-600 block mt-0.5">Unrecovered Liability</span>
                  </div>
                </div>

                {/* Filter and Search Bar for Accounts Report */}
                <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-50 p-2.5 rounded-xl border border-slate-200 text-xs">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="text-slate-500 font-medium mr-1">Filter Stage:</span>
                    {(['all', 'pending', '1st', '2nd', '3rd'] as const).map((stg) => (
                      <button
                        key={stg}
                        type="button"
                        onClick={() => setAccountsReportStageFilter(stg)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition cursor-pointer ${
                          accountsReportStageFilter === stg
                            ? 'bg-indigo-600 text-white shadow-2xs'
                            : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        {stg === 'all' && 'All Records'}
                        {stg === 'pending' && 'Pending Verification'}
                        {stg === '1st' && '1st Ver'}
                        {stg === '2nd' && '2nd Ver'}
                        {stg === '3rd' && '3rd Ver (Final Reconciled)'}
                      </button>
                    ))}
                  </div>

                  <div className="relative">
                    <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input
                      type="text"
                      value={accountsReportSearch}
                      onChange={(e) => setAccountsReportSearch(e.target.value)}
                      placeholder="Search Property, Owner, Challan..."
                      className="bg-white pl-8 pr-3 py-1 rounded-lg border border-slate-200 text-xs text-slate-800 placeholder-slate-400 w-52 sm:w-64 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                    />
                  </div>
                </div>

                {/* Frozen Header Interactive Table for Accounts Office Verification */}
                <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
                  <div className="bg-slate-100/90 px-4 py-2 border-b border-slate-200 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold text-[10px]">
                        ❄️ Top Row Frozen Active
                      </span>
                      <span className="text-slate-600 text-[11px]">
                        Accounts Office Schedule · Receipt Amount, Payment Date & Balance Columns
                      </span>
                    </div>
                    <span className="font-mono text-[11px] text-slate-500">
                      {accountsReportRecords.length} records in verification schedule
                    </span>
                  </div>

                  <div className="overflow-x-auto overflow-y-auto max-h-[480px] relative">
                    <table className="w-full text-left text-xs border-separate border-spacing-0">
                      <thead className="sticky top-0 z-20 select-none shadow-xs">
                        <tr className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px] tracking-wider">
                          <th className="py-2.5 px-2.5 sticky top-0 bg-slate-100 z-20 border-b-2 border-slate-300 text-center w-8">Sr#</th>
                          <th className="py-2.5 px-2.5 sticky top-0 bg-slate-100 z-20 border-b-2 border-slate-300 whitespace-nowrap">Audit Para No</th>
                          <th className="py-2.5 px-2.5 sticky top-0 bg-slate-100 z-20 border-b-2 border-slate-300 whitespace-nowrap">Para Name</th>
                          <th className="py-2.5 px-2.5 sticky top-0 bg-slate-100 z-20 border-b-2 border-slate-300 whitespace-nowrap">Tehsil / Circle</th>
                          <th className="py-2.5 px-2.5 sticky top-0 bg-slate-100 z-20 border-b-2 border-slate-300 whitespace-nowrap">Property No</th>
                          <th className="py-2.5 px-2.5 sticky top-0 bg-slate-100 z-20 border-b-2 border-slate-300 whitespace-nowrap">Taxpayer / Owner</th>
                          <th className="py-2.5 px-2.5 sticky top-0 bg-slate-100 z-20 border-b-2 border-slate-300 whitespace-nowrap">Challan Ref</th>
                          <th className="py-2.5 px-2.5 sticky top-0 bg-blue-100/80 z-20 border-b-2 border-slate-300 whitespace-nowrap text-blue-900 font-black">
                            Payment Date
                          </th>
                          <th className="py-2.5 px-2.5 sticky top-0 bg-slate-100 z-20 border-b-2 border-slate-300 text-right whitespace-nowrap">Audit Amt (Rs.)</th>
                          <th className="py-2.5 px-2.5 sticky top-0 bg-indigo-100/90 z-20 border-b-2 border-slate-300 text-right whitespace-nowrap font-black text-indigo-950">
                            Receipt Amount (Rs.)
                          </th>
                          <th className="py-2.5 px-2.5 sticky top-0 bg-slate-100 z-20 border-b-2 border-slate-300 text-right whitespace-nowrap">Recovered (Rs.)</th>
                          <th className="py-2.5 px-2.5 sticky top-0 bg-slate-100 z-20 border-b-2 border-slate-300 text-right whitespace-nowrap">Prior / Not Due</th>
                          <th className="py-2.5 px-2.5 sticky top-0 bg-rose-100/90 z-20 border-b-2 border-slate-300 text-right whitespace-nowrap font-black text-rose-950">
                            Balance Due (Rs.)
                          </th>
                          <th className="py-2.5 px-2.5 sticky top-0 bg-slate-100 z-20 border-b-2 border-slate-300 text-center whitespace-nowrap">1st Ver Dated</th>
                          <th className="py-2.5 px-2.5 sticky top-0 bg-slate-100 z-20 border-b-2 border-slate-300 text-center whitespace-nowrap">2nd Ver Dated</th>
                          <th className="py-2.5 px-2.5 sticky top-0 bg-slate-100 z-20 border-b-2 border-slate-300 text-center whitespace-nowrap">3rd Ver Dated</th>
                          <th className="py-2.5 px-2.5 sticky top-0 bg-slate-100 z-20 border-b-2 border-slate-300 text-center whitespace-nowrap">Accounts Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {accountsReportRecords.length === 0 ? (
                          <tr>
                            <td colSpan={17} className="py-8 text-center text-slate-500 border-b border-slate-200">
                              No records match the active Accounts Office filter.
                            </td>
                          </tr>
                        ) : (
                          accountsReportRecords.map((r, i) => {
                            const stage = r.verificationStage || (r.verified ? '3rd' : 'pending');
                            return (
                              <tr key={r.id} className={i % 2 === 1 ? 'bg-slate-50/60 hover:bg-indigo-50/30' : 'bg-white hover:bg-indigo-50/30'}>
                                <td className="py-2 px-2.5 font-mono text-center border-b border-slate-200 text-slate-600">{r.id}</td>
                                <td className="py-2 px-2.5 font-mono font-semibold text-indigo-900 border-b border-slate-200 whitespace-nowrap">
                                  {r.paraNo || 'Para-6'}
                                </td>
                                <td className="py-2 px-2.5 border-b border-slate-200 whitespace-nowrap text-slate-700">
                                  {r.details || '6-Petrol Pump'}
                                </td>
                                <td className="py-2 px-2.5 border-b border-slate-200 whitespace-nowrap">
                                  <span className="font-semibold text-slate-800">{r.tehsil}</span>
                                  <span className="text-slate-400 mx-0.5">/</span>
                                  <span className="text-slate-500">{r.circle}</span>
                                </td>
                                <td className="py-2 px-2.5 font-mono font-bold text-indigo-700 border-b border-slate-200 whitespace-nowrap">
                                  {r.propertyNo}
                                </td>
                                <td className="py-2 px-2.5 border-b border-slate-200 whitespace-nowrap text-slate-800 font-medium">
                                  {r.owner}
                                </td>
                                <td className="py-2 px-2.5 font-mono text-slate-600 border-b border-slate-200 whitespace-nowrap">
                                  {r.challanNo || `CH-${r.id}`}
                                </td>
                                {/* Payment Date column */}
                                <td className="py-2 px-2.5 font-mono border-b border-slate-200 whitespace-nowrap bg-blue-50/40 font-semibold text-blue-950">
                                  {r.date ? r.date : <span className="text-slate-400 italic">Unpaid</span>}
                                </td>
                                <td className="py-2 px-2.5 text-right font-mono border-b border-slate-200 tabular-nums text-slate-800">
                                  {formatCurrency(r.auditAmt)}
                                </td>
                                {/* Receipt Amount column */}
                                <td className="py-2 px-2.5 text-right font-mono font-black text-indigo-900 border-b border-slate-200 bg-indigo-50/60 tabular-nums">
                                  {formatCurrency(r.receiptAmt)}
                                </td>
                                <td className="py-2 px-2.5 text-right font-mono text-emerald-700 border-b border-slate-200 tabular-nums font-medium">
                                  {formatCurrency(r.recovered)}
                                </td>
                                <td className="py-2 px-2.5 text-right font-mono text-slate-600 border-b border-slate-200 tabular-nums">
                                  {(r.priorAudit || 0) + (r.notDue || 0) > 0 ? (
                                    formatCurrency((r.priorAudit || 0) + (r.notDue || 0))
                                  ) : (
                                    <span className="text-slate-300">—</span>
                                  )}
                                </td>
                                {/* Balance Column */}
                                <td className={`py-2 px-2.5 text-right font-mono font-black border-b border-slate-200 bg-rose-50/40 tabular-nums ${
                                  r.balance > 0 ? 'text-rose-600' : 'text-slate-800'
                                }`}>
                                  {formatCurrency(r.balance)}
                                </td>
                                {/* 1st Ver Dated */}
                                <td className="py-2 px-2.5 font-mono text-center border-b border-slate-200 whitespace-nowrap">
                                  {r.firstVerDate ? (
                                    <span className="text-blue-800 font-semibold">{r.firstVerDate}</span>
                                  ) : (
                                    <span className="text-slate-300">—</span>
                                  )}
                                </td>
                                {/* 2nd Ver Dated */}
                                <td className="py-2 px-2.5 font-mono text-center border-b border-slate-200 whitespace-nowrap">
                                  {r.secondVerDate ? (
                                    <span className="text-indigo-800 font-semibold">{r.secondVerDate}</span>
                                  ) : (
                                    <span className="text-slate-300">—</span>
                                  )}
                                </td>
                                {/* 3rd Ver Dated */}
                                <td className="py-2 px-2.5 font-mono text-center border-b border-slate-200 whitespace-nowrap">
                                  {r.thirdVerDate ? (
                                    <span className="text-emerald-800 font-semibold">{r.thirdVerDate}</span>
                                  ) : (
                                    <span className="text-slate-300">—</span>
                                  )}
                                </td>
                                {/* Accounts Office Status */}
                                <td className="py-2 px-2.5 text-center whitespace-nowrap border-b border-slate-200 text-[10px]">
                                  {stage === '3rd' && (
                                    <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold">
                                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                                      Reconciled
                                    </span>
                                  )}
                                  {stage === '2nd' && (
                                    <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-indigo-100 text-indigo-800 font-semibold">
                                      2nd Stage
                                    </span>
                                  )}
                                  {stage === '1st' && (
                                    <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-blue-100 text-blue-800 font-semibold">
                                      1st Stage
                                    </span>
                                  )}
                                  {stage === 'pending' && (
                                    <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 font-medium">
                                      <Clock className="w-3 h-3 text-amber-600" />
                                      Pending Scroll
                                    </span>
                                  )}
                                </td>
                              </tr>
                            );
                          })
                        )}
                      </tbody>
                      {accountsReportRecords.length > 0 && (
                        <tfoot className="sticky bottom-0 z-20 bg-slate-100/95 backdrop-blur-xs font-bold border-t-2 border-slate-300 text-xs shadow-sm">
                          <tr>
                            <td colSpan={8} className="py-2.5 px-2.5 text-right uppercase text-[10px] font-bold text-slate-700 border-b border-slate-200">
                              Grand Total for {accountsReportRecords.length} Records:
                            </td>
                            <td className="py-2.5 px-2.5 text-right font-mono border-b border-slate-200 tabular-nums">
                              {formatCurrency(accTotalAudit)}
                            </td>
                            <td className="py-2.5 px-2.5 text-right font-mono text-indigo-900 bg-indigo-100/80 border-b border-slate-200 tabular-nums font-black">
                              {formatCurrency(accTotalReceipts)}
                            </td>
                            <td className="py-2.5 px-2.5 text-right font-mono text-emerald-700 border-b border-slate-200 tabular-nums">
                              {formatCurrency(accTotalRecovered)}
                            </td>
                            <td className="py-2.5 px-2.5 text-right font-mono text-slate-700 border-b border-slate-200 tabular-nums">
                              {formatCurrency(accTotalPriorAndNotDue)}
                            </td>
                            <td className={`py-2.5 px-2.5 text-right font-mono font-black border-b border-slate-200 bg-rose-100/80 tabular-nums ${
                              accTotalBalance > 0 ? 'text-rose-600' : 'text-slate-800'
                            }`}>
                              {formatCurrency(accTotalBalance)}
                            </td>
                            <td colSpan={4} className="py-2.5 px-2.5 text-center text-[10px] text-emerald-800 font-bold border-b border-slate-200">
                              Treasury Ready · Frozen Header Active
                            </td>
                          </tr>
                        </tfoot>
                      )}
                    </table>
                  </div>
                </div>

                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-600 flex flex-col sm:flex-row items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>
                      Formal attestation: <strong>District Accounts Office (DAO) Treasury verification schedule</strong> ready for sign-off with Receipt Amounts, Payment Dates, and Balances.
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setIsAccountsOfficeModalOpen(true)}
                    className="text-indigo-600 hover:text-indigo-800 font-semibold whitespace-nowrap cursor-pointer"
                  >
                    View Official Printable Voucher Sheet →
                  </button>
                </div>
              </div>
            )}

            {/* Sub-report 2: Standard Form 32-A Special Audit Reconciliation */}
            {activeReportSubTab === 'standard' && (
              <div className="space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <div>
                    <h3 className="text-base font-bold text-slate-900">
                      Government Property Tax Audit Summary (Form 32-A)
                    </h3>
                    <p className="text-xs text-slate-500">
                      Standard departmental reconciliation sheet with assessment figures, recoveries, deductions, and signature blocks.
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setIsReportModalOpen(true)}
                      className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold shadow-xs transition cursor-pointer"
                    >
                      Open Fullscreen Form 32-A Report
                    </button>
                    <button
                      type="button"
                      onClick={() => exportRecordsToCSV(records)}
                      className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-medium transition cursor-pointer"
                    >
                      Export CSV
                    </button>
                  </div>
                </div>

                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-600 space-y-2">
                  <p className="font-semibold text-slate-800">
                    Audited District: Rawalpindi Division · {records.length} Assessed Units
                  </p>
                  <p>
                    Click "Open Fullscreen Form 32-A Report" to view and print the comprehensive departmental assessment document with inspector, circle officer, and director signatures.
                  </p>
                </div>
              </div>
            )}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="no-print mt-auto border-t border-slate-200 bg-white py-4 px-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div>
            <span>AppSheet Audit Engine</span> · Property Tax & Recovery Tracker
          </div>
          <div className="font-mono text-[11px] text-slate-400">
            Dynamic Balance Engine: Audit Amt − Recovered − Prior Audit − Not Due
          </div>
        </div>
      </footer>

      {/* Modals */}
      <RecordModal
        isOpen={isRecordModalOpen}
        onClose={() => setIsRecordModalOpen(false)}
        onSave={handleSaveRecord}
        recordToEdit={recordToEdit}
        nextId={nextId}
      />

      <CsvImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        onImport={handleImport}
        currentMaxId={nextId}
      />

      <AuditReportModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
        records={records}
        onExportCSV={() => exportRecordsToCSV(records)}
      />

      <AccountsOfficeReportModal
        isOpen={isAccountsOfficeModalOpen}
        onClose={() => setIsAccountsOfficeModalOpen(false)}
        records={records}
      />

      <ReceiptVoucherModal
        isOpen={isVoucherModalOpen}
        onClose={() => setIsVoucherModalOpen(false)}
        record={selectedVoucherRecord}
        onToggleVerified={handleToggleVerified}
      />

      <QRCodeModal
        isOpen={isQRCodeModalOpen}
        onClose={() => setIsQRCodeModalOpen(false)}
        record={selectedQRRecord}
        onOpenPublicView={handleOpenPublicView}
      />
    </div>
  );
}
